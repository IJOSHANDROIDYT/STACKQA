package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import java.nio.ByteBuffer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `verify app name and direct ByteBuffer scanline vision engine under 3ms`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("QA AutoStacker", appName)

    val width = 1080
    val height = 2400
    val rowStride = width * 4
    val buffer = ByteBuffer.allocateDirect(width * height * 4)

    val tracker = IsometricStackTracker()
    val baseY = Math.round(tracker.baseScanYNorm * height)
    val movingY = Math.round(tracker.movingScanYNorm * height)

    fun fillRowBand(y: Int, leftX: Int, rightX: Int) {
      for (dy in listOf(-3, 3)) {
        val row = (y + dy) * rowStride
        for (x in 0 until width step 2) {
          val idx = row + x * 4
          if (x in leftX..rightX) {
            buffer.put(idx, 169.toByte())
            buffer.put(idx + 1, 130.toByte())
            buffer.put(idx + 2, 175.toByte())
            buffer.put(idx + 3, 255.toByte())
          } else {
            buffer.put(idx, 223.toByte())
            buffer.put(idx + 1, 217.toByte())
            buffer.put(idx + 2, 242.toByte())
            buffer.put(idx + 3, 255.toByte())
          }
        }
      }
    }

    fillRowBand(baseY, 340, 740)
    fillRowBand(movingY, 260, 660)

    val scan = tracker.processByteBuffer(buffer, width, height, rowStride, 4, 100_000_000L)
    assertTrue(scan.validFrame)
    assertTrue(scan.baseDetected)
    assertTrue(scan.movingDetected)
    assertEquals(540.0f, scan.detectedBaseCenterX, 4.0f)
    assertEquals(460.0f, scan.movingCenterX, 4.0f)
    assertTrue("Processing time must be < 3ms", scan.processingTimeMs < 3.0f)
  }

  @Test
  fun `verify PredictiveTriggerEngine kinematic prediction and WaitAndSnap trigger`() {
    val predictor = PredictiveTriggerEngine()
    predictor.leadTimeMs = 24.0f
    predictor.centerOffsetPx = 0.0f

    val targetX = 540.0f
    // Simulate block approaching from left at 1.0 px/ms (16px per 16ms frame)
    predictor.evaluateFrame(true, 460.0f, targetX, 100_000_000L, true)
    predictor.evaluateFrame(true, 476.0f, targetX, 116_000_000L, true)
    predictor.evaluateFrame(true, 492.0f, targetX, 132_000_000L, true)
    // At x = 510, with v = 1.0 px/ms and leadTime = 24ms, predictedX = 534 -> 6ms before impact (Wait & Snap)
    val decision = predictor.evaluateFrame(true, 510.0f, targetX, 148_000_000L, true)
    assertTrue(decision.shouldFire)
  }
}
