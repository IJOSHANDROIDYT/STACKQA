package com.example;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Actividad Principal (MainActivity.java).
 * 1. Gestiona permisos de Superposición (SYSTEM_ALERT_WINDOW), Accesibilidad (TapAccessibilityService)
 *    y lanzamiento de MediaProjectionManager a 60 FPS hacia OverlayStackerService.
 * 2. Incluye un Simulador QA Isométrico 3D a 60 FPS con lectura real de ByteBuffer directo,
 *    calibrador láser interactivo y predictor cinemático "Wait & Snap" (niveles 1 a 100).
 * 3. Muestra instrucciones paso a paso de calibración milimétrica.
 */
public class MainActivity extends Activity {

    private static final int REQ_CODE_OVERLAY_PERMISSION = 2001;
    private static final int REQ_CODE_MEDIA_PROJECTION = 2002;

    private MediaProjectionManager mediaProjectionManager;
    private SharedPreferences prefs;

    private TextView txtOverlayStatus;
    private TextView txtAccessibilityStatus;
    private TextView txtServiceStatus;
    private TextView txtLiveTelemetry;
    private TextView txtLeadTimeControl;
    private TextView txtOffsetControl;

    private Button btnGrantOverlay;
    private Button btnGrantAccessibility;
    private Button btnStartOverlayProjection;
    private Button btnStopOverlayService;

    private Button btnSimAutoStack;
    private Button btnSimCalibrate;
    private Button btnSimMode;
    private Button btnSimResetTower;

    private IsometricSimArenaView simArenaView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mediaProjectionManager =
                (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        prefs = getSharedPreferences(OverlayStackerService.PREFS_NAME, Context.MODE_PRIVATE);

        setContentView(buildMainContentView());
        syncParametersFromPrefs();
        refreshPermissionBadges();
    }

    @Override
    protected void onResume() {
        super.onResume();
        syncParametersFromPrefs();
        refreshPermissionBadges();
        if (simArenaView != null) {
            simArenaView.startSimulationLoop();
        }
    }

    @Override
    protected void onPause() {
        if (simArenaView != null) {
            simArenaView.stopSimulationLoop();
        }
        super.onPause();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CODE_OVERLAY_PERMISSION) {
            refreshPermissionBadges();
            if (Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Permiso de Superposición concedido", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == REQ_CODE_MEDIA_PROJECTION) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                startOverlayStackerServiceWithProjection(resultCode, data);
            } else {
                Toast.makeText(
                        this,
                        "Captura de pantalla cancelada. Puedes usar el Overlay en modo Calibración o el Simulador QA.",
                        Toast.LENGTH_LONG).show();
            }
            refreshPermissionBadges();
        }
    }

    private View buildMainContentView() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(Color.parseColor("#0B1120"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dpToPx(14);
        root.setPadding(pad, dpToPx(36), pad, dpToPx(28));
        scrollView.addView(root);

        // Encabezado Principal
        TextView title = new TextView(this);
        title.setText("QA AUTO-STACKER 60 FPS");
        title.setTextColor(Color.parseColor("#38BDF8"));
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Visión Directa en ByteBuffer (< 1.2ms) • Predictor Cinemático + Wait & Snap");
        subtitle.setTextColor(Color.parseColor("#94A3B8"));
        subtitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        subtitle.setPadding(0, dpToPx(2), 0, dpToPx(12));
        root.addView(subtitle);

        // Tarjeta 1: Permisos y Lanzamiento de Overlay + MediaProjection
        LinearLayout permCard = createStyledCard();
        root.addView(permCard, createCardMarginParams());

        TextView permTitle = createSectionHeader("1. CONFIGURACIÓN DE PERMISOS Y MOTOR OVERLAY");
        permCard.addView(permTitle);

        txtOverlayStatus = createStatusLine();
        txtAccessibilityStatus = createStatusLine();
        txtServiceStatus = createStatusLine();
        permCard.addView(txtOverlayStatus);
        permCard.addView(txtAccessibilityStatus);
        permCard.addView(txtServiceStatus);

        LinearLayout permButtonsRow = new LinearLayout(this);
        permButtonsRow.setOrientation(LinearLayout.HORIZONTAL);
        permButtonsRow.setPadding(0, dpToPx(6), 0, dpToPx(4));

        btnGrantOverlay = createPrimaryButton("1. Superposición", Color.parseColor("#1E293B"), v -> {
            requestOverlayPermission();
        });
        btnGrantAccessibility = createPrimaryButton("2. Accesibilidad", Color.parseColor("#1E293B"), v -> {
            openAccessibilitySettings();
        });

        LinearLayout.LayoutParams halfLp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        halfLp.setMargins(dpToPx(3), dpToPx(2), dpToPx(3), dpToPx(2));
        permButtonsRow.addView(btnGrantOverlay, halfLp);
        permButtonsRow.addView(btnGrantAccessibility, halfLp);
        permCard.addView(permButtonsRow);

        LinearLayout serviceRow = new LinearLayout(this);
        serviceRow.setOrientation(LinearLayout.HORIZONTAL);

        btnStartOverlayProjection = createPrimaryButton(
                "▶ Lanzar Overlay + Captura 60 FPS",
                Color.parseColor("#0284C7"),
                v -> launchMediaProjectionOrOverlay());

        btnStopOverlayService = createPrimaryButton(
                "■ Detener",
                Color.parseColor("#475569"),
                v -> stopOverlayStackerService());

        LinearLayout.LayoutParams startLp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.6f);
        startLp.setMargins(dpToPx(3), dpToPx(4), dpToPx(3), dpToPx(2));
        LinearLayout.LayoutParams stopLp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.7f);
        stopLp.setMargins(dpToPx(3), dpToPx(4), dpToPx(3), dpToPx(2));

        serviceRow.addView(btnStartOverlayProjection, startLp);
        serviceRow.addView(btnStopOverlayService, stopLp);
        permCard.addView(serviceRow);

        // Tarjeta 2: Banco de Pruebas En Vivo (Simulador del Juego Isométrico 3D + Motor ByteBuffer)
        LinearLayout arenaCard = createStyledCard();
        root.addView(arenaCard, createCardMarginParams());

        TextView arenaHeader = createSectionHeader("2. BANCO DE PRUEBAS EN VIVO (NIVEL 1 → 100 A 60 FPS)");
        arenaCard.addView(arenaHeader);

        txtLiveTelemetry = new TextView(this);
        txtLiveTelemetry.setTextColor(Color.parseColor("#A7F3D0"));
        txtLiveTelemetry.setTypeface(Typeface.MONOSPACE);
        txtLiveTelemetry.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        txtLiveTelemetry.setPadding(0, dpToPx(2), 0, dpToPx(6));
        txtLiveTelemetry.setText("ROI ByteBuffer: 0.42 ms | Vel: 0.00 px/ms | Perfects: 0/0");
        arenaCard.addView(txtLiveTelemetry);

        simArenaView = new IsometricSimArenaView(this);
        LinearLayout.LayoutParams arenaLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpToPx(370));
        arenaLp.setMargins(0, dpToPx(4), 0, dpToPx(8));
        arenaCard.addView(simArenaView, arenaLp);

        // Controles en Vivo (idénticos al Panel Flotante del Overlay)
        LinearLayout liveRow1 = new LinearLayout(this);
        liveRow1.setOrientation(LinearLayout.HORIZONTAL);

        btnSimAutoStack = createPrimaryButton("Auto-Stack: ON", Color.parseColor("#059669"), v -> {
            simArenaView.setAutoStackEnabled(!simArenaView.isAutoStackEnabled());
            updateSimControlButtons();
        });
        btnSimCalibrate = createPrimaryButton("Calibrar Ejes", Color.parseColor("#1E293B"), v -> {
            simArenaView.setCalibrationMode(!simArenaView.isCalibrationMode());
            updateSimControlButtons();
        });
        btnSimMode = createPrimaryButton("Modo: Auto-Base", Color.parseColor("#0284C7"), v -> {
            boolean next = !simArenaView.getTracker().isAutoBaseMode();
            simArenaView.getTracker().setAutoBaseMode(next);
            saveCurrentSettings();
            updateSimControlButtons();
        });

        LinearLayout.LayoutParams thirdLp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        thirdLp.setMargins(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2));
        liveRow1.addView(btnSimAutoStack, thirdLp);
        liveRow1.addView(btnSimCalibrate, thirdLp);
        liveRow1.addView(btnSimMode, thirdLp);
        arenaCard.addView(liveRow1);

        // Ajuste fino en vivo de LEAD_TIME_MS y CENTER_OFFSET_PX
        LinearLayout leadTuneRow = new LinearLayout(this);
        leadTuneRow.setOrientation(LinearLayout.HORIZONTAL);
        leadTuneRow.setGravity(Gravity.CENTER_VERTICAL);
        leadTuneRow.setPadding(0, dpToPx(4), 0, 0);

        Button btnLeadMinus = createTuneStepButton("-2ms", v -> {
            simArenaView.getPredictor().adjustLeadTimeMs(-2.0f);
            saveCurrentSettings();
            updateSimControlButtons();
        });
        txtLeadTimeControl = new TextView(this);
        txtLeadTimeControl.setGravity(Gravity.CENTER);
        txtLeadTimeControl.setTextColor(Color.WHITE);
        txtLeadTimeControl.setTypeface(Typeface.DEFAULT_BOLD);
        txtLeadTimeControl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        Button btnLeadPlus = createTuneStepButton("+2ms", v -> {
            simArenaView.getPredictor().adjustLeadTimeMs(+2.0f);
            saveCurrentSettings();
            updateSimControlButtons();
        });

        leadTuneRow.addView(btnLeadMinus);
        leadTuneRow.addView(txtLeadTimeControl, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f));
        leadTuneRow.addView(btnLeadPlus);
        arenaCard.addView(leadTuneRow);

        LinearLayout offsetTuneRow = new LinearLayout(this);
        offsetTuneRow.setOrientation(LinearLayout.HORIZONTAL);
        offsetTuneRow.setGravity(Gravity.CENTER_VERTICAL);
        offsetTuneRow.setPadding(0, dpToPx(4), 0, dpToPx(4));

        Button btnOffLeft = createTuneStepButton("◀ -2px", v -> {
            simArenaView.getPredictor().adjustCenterOffsetPx(-2.0f);
            saveCurrentSettings();
            updateSimControlButtons();
        });
        txtOffsetControl = new TextView(this);
        txtOffsetControl.setGravity(Gravity.CENTER);
        txtOffsetControl.setTextColor(Color.WHITE);
        txtOffsetControl.setTypeface(Typeface.DEFAULT_BOLD);
        txtOffsetControl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        Button btnOffRight = createTuneStepButton("▶ +2px", v -> {
            simArenaView.getPredictor().adjustCenterOffsetPx(+2.0f);
            saveCurrentSettings();
            updateSimControlButtons();
        });

        offsetTuneRow.addView(btnOffLeft);
        offsetTuneRow.addView(txtOffsetControl, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f));
        offsetTuneRow.addView(btnOffRight);
        arenaCard.addView(offsetTuneRow);

        btnSimResetTower = createPrimaryButton(
                "↺ Reiniciar Torre (Probar 1 → 100)",
                Color.parseColor("#334155"),
                v -> simArenaView.resetGameTower());
        LinearLayout.LayoutParams resetLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        resetLp.setMargins(dpToPx(2), dpToPx(4), dpToPx(2), 0);
        arenaCard.addView(btnSimResetTower, resetLp);

        // Tarjeta 3: Instrucciones de Calibración Milimétrica
        LinearLayout guideCard = createStyledCard();
        root.addView(guideCard, createCardMarginParams());

        TextView guideTitle = createSectionHeader("3. GUÍA DE CALIBRACIÓN LÁSER Y PREDICCIÓN");
        guideCard.addView(guideTitle);

        TextView guideBody = new TextView(this);
        guideBody.setTextColor(Color.parseColor("#CBD5E1"));
        guideBody.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        guideBody.setLineSpacing(dpToPx(2), 1.1f);
        guideBody.setText(
                "• LÍNEA VERDE (BASE_SCAN_Y = 0.56): Debe cortar horizontalmente la cara superior "
                + "iluminada del último bloque estacionario. El marcador vertical indica targetCenterX.\n"
                + "• LÍNEA CIAN (MOVING_SCAN_Y = 0.48): Situada justo encima de la línea base, por donde "
                + "cruza la losa en movimiento. El círculo cian marca movingCenterX y el punto amarillo "
                + "muestra predictedX.\n"
                + "• ANTICIPACIÓN (LEAD_TIME_MS = 24ms): Compensa los 15-35ms que tarda Android en "
                + "despachar el gesto de 5ms en (0.50*W, 0.28*H). Si a alta velocidad el bloque se pasa "
                + "ligeramente, sube +2ms; si frena un poco antes, baja -2ms.\n"
                + "• SUB-FRAME WAIT & SNAP: Cuando faltan entre 1ms y 14ms para el cruce exacto, el hilo "
                + "usa LockSupport.parkNanos para disparar en el microsegundo exacto de alineación 100%.");
        guideCard.addView(guideBody);

        updateSimControlButtons();
        return scrollView;
    }

    private void syncParametersFromPrefs() {
        if (simArenaView == null || prefs == null) {
            return;
        }
        float baseY = prefs.getFloat(
                OverlayStackerService.KEY_BASE_SCAN_Y,
                IsometricStackTracker.DEFAULT_BASE_SCAN_Y_NORM);
        float movingY = prefs.getFloat(
                OverlayStackerService.KEY_MOVING_SCAN_Y,
                IsometricStackTracker.DEFAULT_MOVING_SCAN_Y_NORM);
        float targetX = prefs.getFloat(
                OverlayStackerService.KEY_TARGET_X,
                IsometricStackTracker.DEFAULT_TARGET_X_NORM);
        float leadMs = prefs.getFloat(
                OverlayStackerService.KEY_LEAD_TIME_MS,
                PredictiveTriggerEngine.DEFAULT_LEAD_TIME_MS);
        float offsetPx = prefs.getFloat(
                OverlayStackerService.KEY_CENTER_OFFSET_PX,
                PredictiveTriggerEngine.DEFAULT_CENTER_OFFSET_PX);
        boolean autoBase = prefs.getBoolean(OverlayStackerService.KEY_AUTO_BASE_MODE, true);

        simArenaView.getTracker().setBaseScanYNorm(baseY);
        simArenaView.getTracker().setMovingScanYNorm(movingY);
        simArenaView.getTracker().setManualTargetXNorm(targetX);
        simArenaView.getTracker().setAutoBaseMode(autoBase);
        simArenaView.getPredictor().setLeadTimeMs(leadMs);
        simArenaView.getPredictor().setCenterOffsetPx(offsetPx);
        updateSimControlButtons();
    }

    private void saveCurrentSettings() {
        if (simArenaView == null || prefs == null) {
            return;
        }
        prefs.edit()
                .putFloat(OverlayStackerService.KEY_BASE_SCAN_Y, simArenaView.getTracker().getBaseScanYNorm())
                .putFloat(OverlayStackerService.KEY_MOVING_SCAN_Y, simArenaView.getTracker().getMovingScanYNorm())
                .putFloat(OverlayStackerService.KEY_TARGET_X, simArenaView.getTracker().getManualTargetXNorm())
                .putFloat(OverlayStackerService.KEY_LEAD_TIME_MS, simArenaView.getPredictor().getLeadTimeMs())
                .putFloat(OverlayStackerService.KEY_CENTER_OFFSET_PX, simArenaView.getPredictor().getCenterOffsetPx())
                .putBoolean(OverlayStackerService.KEY_AUTO_BASE_MODE, simArenaView.getTracker().isAutoBaseMode())
                .apply();

        OverlayStackerService activeService = OverlayStackerService.getRunningInstance();
        if (activeService != null) {
            activeService.getStackTracker().setBaseScanYNorm(simArenaView.getTracker().getBaseScanYNorm());
            activeService.getStackTracker().setMovingScanYNorm(simArenaView.getTracker().getMovingScanYNorm());
            activeService.getStackTracker().setManualTargetXNorm(simArenaView.getTracker().getManualTargetXNorm());
            activeService.getStackTracker().setAutoBaseMode(simArenaView.getTracker().isAutoBaseMode());
            activeService.getTriggerEngine().setLeadTimeMs(simArenaView.getPredictor().getLeadTimeMs());
            activeService.getTriggerEngine().setCenterOffsetPx(simArenaView.getPredictor().getCenterOffsetPx());
        }
    }

    private void updateSimControlButtons() {
        if (simArenaView == null) {
            return;
        }
        boolean autoOn = simArenaView.isAutoStackEnabled();
        btnSimAutoStack.setText(autoOn ? "Auto-Stack: ON" : "Auto-Stack: OFF");
        styleButton(btnSimAutoStack, autoOn ? Color.parseColor("#059669") : Color.parseColor("#334155"));

        boolean calOn = simArenaView.isCalibrationMode();
        btnSimCalibrate.setText(calOn ? "Guardar Ejes ✓" : "Calibrar Ejes");
        styleButton(btnSimCalibrate, calOn ? Color.parseColor("#D97706") : Color.parseColor("#1E293B"));

        boolean autoBase = simArenaView.getTracker().isAutoBaseMode();
        btnSimMode.setText(autoBase ? "Modo: Auto-Base" : "Modo: Eje Fijo");
        styleButton(btnSimMode, autoBase ? Color.parseColor("#0284C7") : Color.parseColor("#7C3AED"));

        txtLeadTimeControl.setText(String.format(
                Locale.US,
                "Anticipación (LEAD_TIME): %.0f ms",
                simArenaView.getPredictor().getLeadTimeMs()));

        float off = simArenaView.getPredictor().getCenterOffsetPx();
        String sign = (off >= 0.0f) ? "+" : "";
        txtOffsetControl.setText(String.format(
                Locale.US,
                "Eje X (CENTER_OFFSET): %s%.0f px",
                sign,
                off));
    }

    private void refreshPermissionBadges() {
        boolean overlayGranted = Settings.canDrawOverlays(this);
        boolean accessEnabled = TapAccessibilityService.isServiceEnabled(this);
        boolean serviceRunning = (OverlayStackerService.getRunningInstance() != null);

        txtOverlayStatus.setText(overlayGranted
                ? "✓ Permiso SYSTEM_ALERT_WINDOW: CONCEDIDO"
                : "⚠ Permiso SYSTEM_ALERT_WINDOW: Pendiente (Requerido para Overlay)");
        txtOverlayStatus.setTextColor(overlayGranted
                ? Color.parseColor("#34D399")
                : Color.parseColor("#FBBF24"));

        txtAccessibilityStatus.setText(accessEnabled
                ? "✓ Servicio TapAccessibilityService (Toque 5ms): ACTIVO"
                : "⚠ Servicio TapAccessibilityService: Inactivo (Pulsa '2. Accesibilidad')");
        txtAccessibilityStatus.setTextColor(accessEnabled
                ? Color.parseColor("#34D399")
                : Color.parseColor("#FBBF24"));

        txtServiceStatus.setText(serviceRunning
                ? "✓ OverlayStackerService 60 FPS: EN EJECUCIÓN"
                : "• OverlayStackerService: Listo para iniciar");
        txtServiceStatus.setTextColor(serviceRunning
                ? Color.parseColor("#38BDF8")
                : Color.parseColor("#94A3B8"));
    }

    private void requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "El permiso de superposición ya está activo", Toast.LENGTH_SHORT).show();
            refreshPermissionBadges();
            return;
        }
        try {
            Intent intent = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQ_CODE_OVERLAY_PERMISSION);
        } catch (Exception e) {
            Toast.makeText(this, "Abre Ajustes > Mostrar sobre otras apps", Toast.LENGTH_LONG).show();
        }
    }

    private void openAccessibilitySettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivity(intent);
            Toast.makeText(
                    this,
                    "Activa 'QA AutoStacker' en Servicios Descargados",
                    Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir Ajustes de Accesibilidad", Toast.LENGTH_SHORT).show();
        }
    }

    private void launchMediaProjectionOrOverlay() {
        saveCurrentSettings();
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                    this,
                    "Primero concede el permiso '1. Superposición' para mostrar el calibrador láser",
                    Toast.LENGTH_LONG).show();
            requestOverlayPermission();
            return;
        }
        if (mediaProjectionManager != null) {
            try {
                Intent captureIntent = mediaProjectionManager.createScreenCaptureIntent();
                startActivityForResult(captureIntent, REQ_CODE_MEDIA_PROJECTION);
                return;
            } catch (Exception ignored) {
            }
        }
        startOverlayStackerServiceWithProjection(Activity.RESULT_CANCELED, null);
    }

    private void startOverlayStackerServiceWithProjection(int resultCode, Intent resultData) {
        Intent serviceIntent = new Intent(this, OverlayStackerService.class);
        serviceIntent.setAction(OverlayStackerService.ACTION_START_OVERLAY);
        serviceIntent.putExtra(OverlayStackerService.EXTRA_RESULT_CODE, resultCode);
        if (resultData != null) {
            serviceIntent.putExtra(OverlayStackerService.EXTRA_RESULT_DATA, resultData);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
        mainPostDelayedRefresh();
    }

    private void stopOverlayStackerService() {
        Intent stopIntent = new Intent(this, OverlayStackerService.class);
        stopIntent.setAction(OverlayStackerService.ACTION_STOP_OVERLAY);
        stopService(stopIntent);
        mainPostDelayedRefresh();
    }

    private void mainPostDelayedRefresh() {
        getWindow().getDecorView().postDelayed(this::refreshPermissionBadges, 250L);
    }

    private LinearLayout createStyledCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        int pad = dpToPx(12);
        card.setPadding(pad, pad, pad, pad);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#111827"));
        bg.setCornerRadius(dpToPx(14));
        bg.setStroke(dpToPx(1), Color.parseColor("#1E293B"));
        card.setBackground(bg);
        return card;
    }

    private LinearLayout.LayoutParams createCardMarginParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dpToPx(12));
        return lp;
    }

    private TextView createSectionHeader(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#F8FAFC"));
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tv.setPadding(0, 0, 0, dpToPx(6));
        return tv;
    }

    private TextView createStatusLine() {
        TextView tv = new TextView(this);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        tv.setPadding(0, dpToPx(2), 0, dpToPx(2));
        return tv;
    }

    private Button createPrimaryButton(String text, int bgColor, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        b.setPadding(dpToPx(10), dpToPx(8), dpToPx(10), dpToPx(8));
        b.setMinimumHeight(0);
        b.setMinHeight(0);
        styleButton(b, bgColor);
        b.setOnClickListener(listener);
        return b;
    }

    private Button createTuneStepButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.parseColor("#38BDF8"));
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        b.setPadding(dpToPx(12), dpToPx(6), dpToPx(12), dpToPx(6));
        b.setMinimumHeight(0);
        b.setMinHeight(0);
        b.setMinimumWidth(0);
        b.setMinWidth(0);
        styleButton(b, Color.parseColor("#0F172A"));
        b.setOnClickListener(listener);
        return b;
    }

    private void styleButton(View button, int bgColor) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(bgColor);
        bg.setCornerRadius(dpToPx(10));
        bg.setStroke(dpToPx(1), Color.argb(80, 255, 255, 255));
        button.setBackground(bg);
    }

    private int dpToPx(int dp) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp,
                getResources().getDisplayMetrics()));
    }

    /**
     * Simulador Interactivo 60 FPS de la Torre Isométrica 3D + Pipeline Real de ByteBuffer Directo.
     * Reproduce fielmente la estética y cinemática del juego objetivo (nivel 1 al 100),
     * sintetiza las franjas RGBA en un ByteBuffer directo sin crear Bitmaps y ejecuta
     * IsometricStackTracker + PredictiveTriggerEngine en cada fotograma.
     */
    private final class IsometricSimArenaView extends View implements Choreographer.FrameCallback {

        private final IsometricStackTracker tracker = new IsometricStackTracker();
        private final PredictiveTriggerEngine predictor = new PredictiveTriggerEngine();

        private ByteBuffer directRoiBuffer;
        private int bufferWidth = 0;
        private int bufferHeight = 0;

        private boolean running = false;
        private boolean autoStackEnabled = true;
        private boolean calibrationMode = false;
        private int activeDragLine = 0; // 1 = cian móvil, 2 = verde base, 3 = eje X

        private int currentLevel = 1;
        private int perfectDropCount = 0;
        private int totalDrops = 0;
        private String lastDropBanner = "PERFECT DROP! ⚡";
        private long lastDropTimeMs = 0L;

        private float baseCenterXNorm = 0.50f;
        private float baseWidthNorm = 0.42f;

        private float movingCenterXNorm = 0.18f;
        private float movingWidthNorm = 0.42f;
        private float movingDirection = 1.0f;
        private long lastFrameTimeNs = 0L;
        private long blockSpawnCooldownUntilMs = 0L;

        private final List<PlacedSlab> towerHistory = new ArrayList<>();

        private final Paint bgPaint = new Paint();
        private final Paint topFacePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint leftFacePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rightFacePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint billBadgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint laserBasePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint laserMovingPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint laserAxisPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint predictedPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint hudPillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path isoPath = new Path();
        private final RectF billRect = new RectF();

        private IsometricStackTracker.ScanResult latestScan;
        private PredictiveTriggerEngine.PredictionDecision latestDecision;

        private final class PlacedSlab {
            final float centerXNorm;
            final float widthNorm;

            PlacedSlab(float centerXNorm, float widthNorm) {
                this.centerXNorm = centerXNorm;
                this.widthNorm = widthNorm;
            }
        }

        IsometricSimArenaView(Context context) {
            super(context);
            topFacePaint.setColor(Color.parseColor("#A982AF"));
            leftFacePaint.setColor(Color.parseColor("#92689B"));
            rightFacePaint.setColor(Color.parseColor("#5D478B"));
            billBadgePaint.setColor(Color.parseColor("#2E8555"));

            textPaint.setColor(Color.WHITE);
            textPaint.setTypeface(Typeface.DEFAULT_BOLD);
            textPaint.setTextAlign(Paint.Align.CENTER);

            laserBasePaint.setColor(Color.parseColor("#00E676"));
            laserBasePaint.setStrokeWidth(dpToPx(2));
            laserBasePaint.setStyle(Paint.Style.STROKE);

            laserMovingPaint.setColor(Color.parseColor("#00E5FF"));
            laserMovingPaint.setStrokeWidth(dpToPx(2));
            laserMovingPaint.setStyle(Paint.Style.STROKE);

            laserAxisPaint.setColor(Color.parseColor("#00E676"));
            laserAxisPaint.setStrokeWidth(dpToPx(2));
            laserAxisPaint.setStyle(Paint.Style.STROKE);
            laserAxisPaint.setPathEffect(new DashPathEffect(new float[]{12f, 8f}, 0f));

            predictedPaint.setColor(Color.parseColor("#FFEA00"));
            predictedPaint.setStyle(Paint.Style.FILL);

            hudPillPaint.setColor(Color.argb(190, 15, 23, 42));
            hudPillPaint.setStyle(Paint.Style.FILL);

            resetGameTower();

            TapAccessibilityService.setLocalTapListener((tapX, tapY, timestampNs) -> {
                post(this::lockMovingSlabOnTower);
            });
        }

        IsometricStackTracker getTracker() {
            return tracker;
        }

        PredictiveTriggerEngine getPredictor() {
            return predictor;
        }

        boolean isAutoStackEnabled() {
            return autoStackEnabled;
        }

        void setAutoStackEnabled(boolean enabled) {
            this.autoStackEnabled = enabled;
            predictor.resetHistory();
        }

        boolean isCalibrationMode() {
            return calibrationMode;
        }

        void setCalibrationMode(boolean calibrationMode) {
            this.calibrationMode = calibrationMode;
            if (!calibrationMode) {
                saveCurrentSettings();
            }
            invalidate();
        }

        void resetGameTower() {
            currentLevel = 1;
            perfectDropCount = 0;
            totalDrops = 0;
            baseCenterXNorm = 0.50f;
            baseWidthNorm = 0.42f;
            movingWidthNorm = 0.42f;
            movingCenterXNorm = 0.16f;
            movingDirection = 1.0f;
            towerHistory.clear();
            towerHistory.add(new PlacedSlab(baseCenterXNorm, baseWidthNorm));
            towerHistory.add(new PlacedSlab(baseCenterXNorm, baseWidthNorm));
            towerHistory.add(new PlacedSlab(baseCenterXNorm, baseWidthNorm));
            tracker.unlockReference();
            predictor.resetStats();
            lastDropBanner = "TORRE LISTA (NIVEL 1 → 100)";
            lastDropTimeMs = SystemClock.uptimeMillis();
            invalidate();
        }

        void startSimulationLoop() {
            if (!running) {
                running = true;
                lastFrameTimeNs = System.nanoTime();
                Choreographer.getInstance().postFrameCallback(this);
            }
        }

        void stopSimulationLoop() {
            running = false;
            Choreographer.getInstance().removeFrameCallback(this);
        }

        @Override
        public void doFrame(long frameTimeNanos) {
            if (!running) {
                return;
            }
            float dtMs = (frameTimeNanos - lastFrameTimeNs) / 1_000_000.0f;
            lastFrameTimeNs = frameTimeNanos;
            if (dtMs <= 0.0f || dtMs > 60.0f) {
                dtMs = 16.66f;
            }

            updateBlockKinematics(dtMs);
            runDirectByteBufferVisionAndPrediction(frameTimeNanos);
            invalidate();

            Choreographer.getInstance().postFrameCallback(this);
        }

        private void updateBlockKinematics(float dtMs) {
            long nowMs = SystemClock.uptimeMillis();
            if (nowMs < blockSpawnCooldownUntilMs) {
                return;
            }
            // La velocidad sube progresivamente desde el nivel 1 hasta el nivel 100
            float levelProgress = (currentLevel - 1) / 99.0f;
            float speedNormPerMs = 0.00034f + (levelProgress * 0.00058f);

            // Simulamos también el tiempo real de respuesta del motor (24ms de latencia de gesto)
            movingCenterXNorm += movingDirection * speedNormPerMs * dtMs;
            if (movingCenterXNorm >= 0.82f) {
                movingCenterXNorm = 0.82f;
                movingDirection = -1.0f;
            } else if (movingCenterXNorm <= 0.18f) {
                movingCenterXNorm = 0.18f;
                movingDirection = 1.0f;
            }
        }

        /**
         * Rellena las filas de las dos Scanlines en un ByteBuffer directo (RGBA_8888)
         * y ejecuta IsometricStackTracker.processByteBuffer(...) sin crear ningún Bitmap.
         */
        private void runDirectByteBufferVisionAndPrediction(long timestampNs) {
            int w = getWidth();
            int h = getHeight();
            if (w <= 64 || h <= 64) {
                return;
            }
            ensureDirectBufferAllocated(w, h);

            int rowStride = w * 4;
            int baseY = Math.max(8, Math.min(h - 9, Math.round(tracker.getBaseScanYNorm() * h)));
            int movingY = Math.max(8, Math.min(h - 9, Math.round(tracker.getMovingScanYNorm() * h)));

            // Pintar en el ByteBuffer únicamente las filas ROI (baseY ± 3 y movingY ± 3)
            int baseLeftPx = Math.round((baseCenterXNorm - (baseWidthNorm * 0.5f)) * w);
            int baseRightPx = Math.round((baseCenterXNorm + (baseWidthNorm * 0.5f)) * w);
            writeSyntheticScanlineBand(directRoiBuffer, w, rowStride, baseY - 3, baseLeftPx, baseRightPx);
            writeSyntheticScanlineBand(directRoiBuffer, w, rowStride, baseY + 3, baseLeftPx, baseRightPx);

            long nowMs = SystemClock.uptimeMillis();
            if (nowMs >= blockSpawnCooldownUntilMs) {
                int movLeftPx = Math.round((movingCenterXNorm - (movingWidthNorm * 0.5f)) * w);
                int movRightPx = Math.round((movingCenterXNorm + (movingWidthNorm * 0.5f)) * w);
                writeSyntheticScanlineBand(directRoiBuffer, w, rowStride, movingY - 3, movLeftPx, movRightPx);
                writeSyntheticScanlineBand(directRoiBuffer, w, rowStride, movingY + 3, movLeftPx, movRightPx);
            } else {
                writeSyntheticScanlineBand(directRoiBuffer, w, rowStride, movingY - 3, -1, -1);
                writeSyntheticScanlineBand(directRoiBuffer, w, rowStride, movingY + 3, -1, -1);
            }

            latestScan = tracker.processByteBuffer(directRoiBuffer, w, h, rowStride, 4, timestampNs);
            latestDecision = predictor.evaluateFrame(
                    latestScan.movingDetected,
                    latestScan.movingCenterX,
                    latestScan.effectiveTargetCenterX,
                    timestampNs,
                    autoStackEnabled);

            OverlayStackerService runningService = OverlayStackerService.getRunningInstance();
            if (runningService != null) {
                runningService.onExternalByteBufferFrameProcessed(latestScan);
            }

            if (latestDecision.shouldFire && autoStackEnabled) {
                if (latestDecision.subFrameWaitNanos > 0L) {
                    PredictiveTriggerEngine.executeSubFrameSleepIfNeeded(latestDecision.subFrameWaitNanos);
                }
                // Aplicamos la compensación cinemática para simular la llegada del toque tras ~24ms
                float effectiveLeadSeconds = predictor.getLeadTimeMs();
                float simulatedArrivalDeltaNorm =
                        (latestDecision.velocityPxPerMs * effectiveLeadSeconds) / (float) w;
                movingCenterXNorm += simulatedArrivalDeltaNorm;
                lockMovingSlabOnTower();
            }

            if (txtLiveTelemetry != null) {
                txtLiveTelemetry.setText(String.format(
                        Locale.US,
                        "ByteBuffer ROI: %.2f ms | Vel: %+.2f px/ms | Perfects: %d/%d",
                        latestScan.processingTimeMs,
                        latestDecision.velocityPxPerMs,
                        perfectDropCount,
                        totalDrops));
            }
        }

        private void ensureDirectBufferAllocated(int w, int h) {
            if (directRoiBuffer == null || bufferWidth != w || bufferHeight != h) {
                bufferWidth = w;
                bufferHeight = h;
                directRoiBuffer = ByteBuffer.allocateDirect(w * h * 4);
            }
        }

        private void writeSyntheticScanlineBand(
                ByteBuffer buf,
                int width,
                int rowStride,
                int y,
                int blockLeftX,
                int blockRightX) {

            if (y < 0 || y >= bufferHeight) {
                return;
            }
            int rowStart = y * rowStride;
            // Color de fondo lavanda claro (#DFD9F2 -> R:223, G:217, B:242)
            byte bgR = (byte) 223;
            byte bgG = (byte) 217;
            byte bgB = (byte) 242;
            // Color de la cara superior iluminada del bloque (#A982AF -> R:169, G:130, B:175)
            byte blkR = (byte) 169;
            byte blkG = (byte) 130;
            byte blkB = (byte) 175;
            byte alpha = (byte) 255;

            for (int x = 0; x < width; x += 2) {
                int idx = rowStart + (x * 4);
                boolean inside = (blockLeftX >= 0 && x >= blockLeftX && x <= blockRightX);
                if (inside) {
                    buf.put(idx, blkR);
                    buf.put(idx + 1, blkG);
                    buf.put(idx + 2, blkB);
                    buf.put(idx + 3, alpha);
                } else {
                    buf.put(idx, bgR);
                    buf.put(idx + 1, bgG);
                    buf.put(idx + 2, bgB);
                    buf.put(idx + 3, alpha);
                }
            }
        }

        private void lockMovingSlabOnTower() {
            int w = Math.max(1, getWidth());
            float errorPx = Math.abs((movingCenterXNorm - baseCenterXNorm) * w);
            totalDrops++;

            if (errorPx <= 8.5f) {
                // Perfect Drop! Mantiene el ancho intacto y alinea al milímetro
                movingCenterXNorm = baseCenterXNorm;
                perfectDropCount++;
                lastDropBanner = String.format(
                        Locale.US,
                        "PERFECT DROP #%d! (Error: %.1f px)",
                        currentLevel,
                        errorPx);
            } else {
                // Recorte del sobrante como en el juego real
                float prevLeft = baseCenterXNorm - (baseWidthNorm * 0.5f);
                float prevRight = baseCenterXNorm + (baseWidthNorm * 0.5f);
                float movLeft = movingCenterXNorm - (movingWidthNorm * 0.5f);
                float movRight = movingCenterXNorm + (movingWidthNorm * 0.5f);

                float overlapLeft = Math.max(prevLeft, movLeft);
                float overlapRight = Math.min(prevRight, movRight);
                if (overlapRight - overlapLeft > 0.08f) {
                    baseWidthNorm = overlapRight - overlapLeft;
                    baseCenterXNorm = (overlapLeft + overlapRight) * 0.5f;
                    movingWidthNorm = baseWidthNorm;
                    lastDropBanner = String.format(
                            Locale.US,
                            "RECORTE (Desvío: %.1f px) - Ajusta Anticipación",
                            errorPx);
                } else {
                    // Restaurar ancho mínimo para continuar el banco de pruebas
                    baseWidthNorm = 0.42f;
                    baseCenterXNorm = 0.50f;
                    movingWidthNorm = 0.42f;
                }
            }

            towerHistory.add(new PlacedSlab(baseCenterXNorm, baseWidthNorm));
            if (towerHistory.size() > 5) {
                towerHistory.remove(0);
            }

            if (currentLevel < 100) {
                currentLevel++;
            } else {
                lastDropBanner = "🏆 ¡NIVEL 100 COMPLETADO CON PRECISIÓN QA!";
                currentLevel = 1;
            }

            // Alternar esquina de salida para el siguiente bloque
            movingDirection = (currentLevel % 2 == 0) ? -1.0f : 1.0f;
            movingCenterXNorm = (movingDirection > 0.0f) ? 0.18f : 0.82f;
            blockSpawnCooldownUntilMs = SystemClock.uptimeMillis() + 220L;
            lastDropTimeMs = SystemClock.uptimeMillis();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) {
                return;
            }

            // 1. Fondo degradado idéntico a la captura del juego
            bgPaint.setShader(new LinearGradient(
                    0, 0, 0, h,
                    new int[]{
                            Color.parseColor("#D8ECFA"),
                            Color.parseColor("#E6DFF7"),
                            Color.parseColor("#B5AEB9")
                    },
                    new float[]{0.0f, 0.46f, 1.0f},
                    Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, bgPaint);

            // 2. Insignia superior "$100 GUARANTEED" + Contador de Nivel (1 a 100)
            float billW = w * 0.42f;
            float billH = h * 0.11f;
            billRect.set((w - billW) * 0.5f, h * 0.04f, (w + billW) * 0.5f, h * 0.04f + billH);
            canvas.drawRoundRect(billRect, dpToPx(10), dpToPx(10), billBadgePaint);

            textPaint.setColor(Color.WHITE);
            textPaint.setTextSize(dpToPx(16));
            canvas.drawText("$100 QA TARGET", w * 0.5f, billRect.centerY() + dpToPx(5), textPaint);

            textPaint.setTextSize(dpToPx(32));
            canvas.drawText(String.valueOf(currentLevel), w * 0.5f, h * 0.28f, textPaint);

            // 3. Dibujar la Torre Isométrica 3D en torno a BASE_SCAN_Y_NORM
            float baseScanY = tracker.getBaseScanYNorm() * h;
            float movingScanY = tracker.getMovingScanYNorm() * h;
            float slabThickness = h * 0.055f;

            int count = towerHistory.size();
            for (int i = 0; i < count; i++) {
                PlacedSlab slab = towerHistory.get(i);
                int stepsFromTop = (count - 1) - i;
                float centerY = baseScanY + (stepsFromTop * slabThickness * 0.85f);
                drawIsometricBlock(
                        canvas,
                        slab.centerXNorm * w,
                        centerY,
                        slab.widthNorm * w,
                        slabThickness);
            }

            // 4. Dibujar el Bloque en Movimiento cruzando por MOVING_SCAN_Y_NORM
            if (SystemClock.uptimeMillis() >= blockSpawnCooldownUntilMs) {
                drawIsometricBlock(
                        canvas,
                        movingCenterXNorm * w,
                        movingScanY,
                        movingWidthNorm * w,
                        slabThickness);
            }

            // 5. Dibujar las Líneas Láser de Calibración y Predicción Cinemática
            float startX = 0.12f * w;
            float endX = 0.88f * w;
            float targetX = (latestScan != null && latestScan.effectiveTargetCenterX > 0)
                    ? latestScan.effectiveTargetCenterX
                    : (baseCenterXNorm * w);
            float adjustedTargetX = targetX - predictor.getCenterOffsetPx();

            // Eje central vertical de encaje
            canvas.drawLine(
                    adjustedTargetX,
                    movingScanY - dpToPx(36),
                    adjustedTargetX,
                    baseScanY + dpToPx(36),
                    laserAxisPaint);

            // Línea Verde (BASE_SCAN_Y)
            canvas.drawLine(startX, baseScanY, endX, baseScanY, laserBasePaint);
            if (latestScan != null && latestScan.baseDetected) {
                canvas.drawLine(
                        latestScan.baseLeftX, baseScanY - dpToPx(8),
                        latestScan.baseLeftX, baseScanY + dpToPx(8), laserBasePaint);
                canvas.drawLine(
                        latestScan.baseRightX, baseScanY - dpToPx(8),
                        latestScan.baseRightX, baseScanY + dpToPx(8), laserBasePaint);
            }
            canvas.drawCircle(targetX, baseScanY, dpToPx(5), laserBasePaint);

            // Línea Cian (MOVING_SCAN_Y) + Punto Amarillo (predictedX)
            canvas.drawLine(startX, movingScanY, endX, movingScanY, laserMovingPaint);
            if (latestScan != null && latestScan.movingDetected) {
                canvas.drawLine(
                        latestScan.movingLeftX, movingScanY - dpToPx(8),
                        latestScan.movingLeftX, movingScanY + dpToPx(8), laserMovingPaint);
                canvas.drawLine(
                        latestScan.movingRightX, movingScanY - dpToPx(8),
                        latestScan.movingRightX, movingScanY + dpToPx(8), laserMovingPaint);
                canvas.drawCircle(latestScan.movingCenterX, movingScanY, dpToPx(5), laserMovingPaint);

                if (latestDecision != null) {
                    float predX = Math.max(startX, Math.min(endX, latestDecision.predictedX));
                    canvas.drawLine(latestScan.movingCenterX, movingScanY, predX, movingScanY, predictedPaint);
                    canvas.drawCircle(predX, movingScanY, dpToPx(6), predictedPaint);
                }
            }

            // 6. Banner inferior de estado / resultado del último disparo
            billRect.set(w * 0.08f, h * 0.88f, w * 0.92f, h * 0.97f);
            canvas.drawRoundRect(billRect, dpToPx(14), dpToPx(14), hudPillPaint);
            textPaint.setTextSize(dpToPx(11));
            textPaint.setColor(Color.parseColor("#38BDF8"));
            String footerText = calibrationMode
                    ? "MODO CALIBRAR: Arrastra la Línea Cian (Móvil), Verde (Base) o Eje X"
                    : lastDropBanner;
            canvas.drawText(footerText, w * 0.5f, billRect.centerY() + dpToPx(4), textPaint);
        }

        private void drawIsometricBlock(
                Canvas canvas,
                float centerX,
                float centerY,
                float totalWidth,
                float wallHeight) {

            float halfW = totalWidth * 0.5f;
            float halfH = totalWidth * 0.24f;

            float topX = centerX;
            float topY = centerY - halfH;
            float rightX = centerX + halfW;
            float rightY = centerY;
            float bottomX = centerX;
            float bottomY = centerY + halfH;
            float leftX = centerX - halfW;
            float leftY = centerY;

            // Cara superior iluminada
            isoPath.reset();
            isoPath.moveTo(topX, topY);
            isoPath.lineTo(rightX, rightY);
            isoPath.lineTo(bottomX, bottomY);
            isoPath.lineTo(leftX, leftY);
            isoPath.close();
            canvas.drawPath(isoPath, topFacePaint);

            // Cara lateral izquierda (tono medio)
            isoPath.reset();
            isoPath.moveTo(leftX, leftY);
            isoPath.lineTo(bottomX, bottomY);
            isoPath.lineTo(bottomX, bottomY + wallHeight);
            isoPath.lineTo(leftX, leftY + wallHeight);
            isoPath.close();
            canvas.drawPath(isoPath, leftFacePaint);

            // Cara lateral derecha (tono oscuro)
            isoPath.reset();
            isoPath.moveTo(bottomX, bottomY);
            isoPath.lineTo(rightX, rightY);
            isoPath.lineTo(rightX, rightY + wallHeight);
            isoPath.lineTo(bottomX, bottomY + wallHeight);
            isoPath.close();
            canvas.drawPath(isoPath, rightFacePaint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) {
                return false;
            }
            if (!calibrationMode) {
                if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    lockMovingSlabOnTower();
                    return true;
                }
                return super.onTouchEvent(event);
            }

            float x = event.getX();
            float y = event.getY();
            float movingY = tracker.getMovingScanYNorm() * h;
            float baseY = tracker.getBaseScanYNorm() * h;
            float targetX = tracker.getManualTargetXNorm() * w;

            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (Math.abs(y - movingY) <= dpToPx(28)) {
                        activeDragLine = 1;
                    } else if (Math.abs(y - baseY) <= dpToPx(28)) {
                        activeDragLine = 2;
                    } else if (Math.abs(x - targetX) <= dpToPx(32)) {
                        activeDragLine = 3;
                    } else {
                        activeDragLine = (Math.abs(y - movingY) < Math.abs(y - baseY)) ? 1 : 2;
                    }
                    updateDraggedAxis(x, y, w, h);
                    return true;

                case MotionEvent.ACTION_MOVE:
                    updateDraggedAxis(x, y, w, h);
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    activeDragLine = 0;
                    saveCurrentSettings();
                    return true;

                default:
                    return false;
            }
        }

        private void updateDraggedAxis(float x, float y, int w, int h) {
            if (activeDragLine == 1) {
                tracker.setMovingScanYNorm(y / (float) h);
            } else if (activeDragLine == 2) {
                tracker.setBaseScanYNorm(y / (float) h);
            } else if (activeDragLine == 3) {
                tracker.setManualTargetXNorm(x / (float) w);
                tracker.setAutoBaseMode(false);
                updateSimControlButtons();
            }
            invalidate();
        }
    }
}
