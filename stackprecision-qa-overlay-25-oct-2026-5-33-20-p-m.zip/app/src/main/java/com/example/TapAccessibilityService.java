package com.example;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.ComponentName;
import android.content.Context;
import android.graphics.Path;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;

/**
 * Ejecutor de Toques Ultra-Rápido en Zona Segura Superior (TapAccessibilityService).
 * Realiza el clic por defecto en (0.50f * screenWidth, 0.28f * screenHeight) con una
 * duración de 5ms para que el motor del juego registre ACTION_DOWN de forma instantánea.
 */
public final class TapAccessibilityService extends AccessibilityService {

    public static final float DEFAULT_SAFE_TAP_X_NORM = 0.50f;
    public static final float DEFAULT_SAFE_TAP_Y_NORM = 0.28f;
    public static final long ULTRA_FAST_TAP_DURATION_MS = 5L;

    private static volatile TapAccessibilityService instance;
    private static volatile LocalTapListener localTapListener;

    public interface LocalTapListener {
        void onFastTapDispatched(float tapX, float tapY, long timestampNs);
    }

    public static TapAccessibilityService getInstance() {
        return instance;
    }

    public static void setLocalTapListener(LocalTapListener listener) {
        localTapListener = listener;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // No se procesan eventos de accesibilidad de árbol UI para mantener latencia cero
    }

    @Override
    public void onInterrupt() {
        // Requerido por AccessibilityService
    }

    @Override
    public void onDestroy() {
        if (instance == this) {
            instance = null;
        }
        super.onDestroy();
    }

    /**
     * Ejecuta un toque rápido de 5ms en la zona segura superior (0.50f * W, 0.28f * H).
     */
    public boolean performSafeUpperTap(int screenWidth, int screenHeight) {
        float tapX = DEFAULT_SAFE_TAP_X_NORM * screenWidth;
        float tapY = DEFAULT_SAFE_TAP_Y_NORM * screenHeight;
        return performUltraFastTap(tapX, tapY);
    }

    /**
     * Ejecuta un GestureDescription de 5ms en las coordenadas indicadas.
     */
    public boolean performUltraFastTap(float x, float y) {
        long nowNs = System.nanoTime();
        LocalTapListener listener = localTapListener;
        if (listener != null) {
            listener.onFastTapDispatched(x, y, nowNs);
        }

        DisplayMetrics dm = getResources().getDisplayMetrics();
        float safeX = Math.max(10.0f, Math.min(x, dm.widthPixels - 10.0f));
        float safeY = Math.max(10.0f, Math.min(y, dm.heightPixels - 10.0f));

        Path tapPath = new Path();
        tapPath.moveTo(safeX, safeY);

        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(tapPath, 0L, ULTRA_FAST_TAP_DURATION_MS);

        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(stroke)
                .build();

        return dispatchGesture(gesture, null, null);
    }

    /**
     * Dispara el toque tanto en el servicio de accesibilidad del sistema (si está activo)
     * como en el simulador QA integrado (si está abierto).
     */
    public static boolean dispatchGlobalOrLocalSafeTap(int screenWidth, int screenHeight) {
        float tapX = DEFAULT_SAFE_TAP_X_NORM * screenWidth;
        float tapY = DEFAULT_SAFE_TAP_Y_NORM * screenHeight;

        TapAccessibilityService service = instance;
        if (service != null) {
            return service.performUltraFastTap(tapX, tapY);
        }

        LocalTapListener listener = localTapListener;
        if (listener != null) {
            listener.onFastTapDispatched(tapX, tapY, System.nanoTime());
            return true;
        }
        return false;
    }

    /**
     * Comprueba si TapAccessibilityService se encuentra habilitado en Ajustes de Accesibilidad.
     */
    public static boolean isServiceEnabled(Context context) {
        if (instance != null) {
            return true;
        }
        if (context == null) {
            return false;
        }
        ComponentName expectedComponent = new ComponentName(context, TapAccessibilityService.class);
        String enabledServices = Settings.Secure.getString(
                context.getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabledServices)) {
            return false;
        }
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabledServices);
        while (splitter.hasNext()) {
            String componentStr = splitter.next();
            ComponentName enabledComponent = ComponentName.unflattenFromString(componentStr);
            if (enabledComponent != null && enabledComponent.equals(expectedComponent)) {
                return true;
            }
        }
        return false;
    }
}
