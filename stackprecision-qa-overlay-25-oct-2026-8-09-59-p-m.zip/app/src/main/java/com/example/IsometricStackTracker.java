package com.example;

import android.media.Image;
import android.os.SystemClock;
import java.nio.ByteBuffer;
import java.util.Arrays;

/**
 * Motor de Visión por Computadora a 60 FPS con:
 * 1. Detector de Cruce de Arista / Borde Delantero (Leading-Edge Match):
 *    - Mide con exactitud milimétrica baseLeftEdgeX y baseRightEdgeX de la cara superior iluminada
 *      del último bloque estacionario, además de su vértice superior (topY) y vértice frontal (frontX, frontY).
 *    - En cada fotograma a 60 FPS extrae el borde delantero visible de la losa en movimiento:
 *      * movingRightEdgeX (100% visible cuando la pieza entra desde la izquierda, vx > 0).
 *      * movingLeftEdgeX (100% visible cuando la pieza entra desde la derecha, vx < 0).
 *      Esto lo hace 100% inmune a los recortes cuando mitad de la losa aún está fuera de la pantalla.
 * 2. Auto-Subida tras cada bloque colocado (280ms):
 *    - Tras cada disparo, espera 280ms a que la pieza aterrice y pase el destello de "PERFECT!",
 *      escanea unos píxeles más arriba y actualiza baseLeftEdgeX, baseRightEdgeX y la nueva altura
 *      de la cima de la torre.
 * 3. Auto-Ejes sobre la Cara Superior Iluminada (X entre 0.25f y 0.75f, Y entre 0.40f y 0.68f):
 *    - Detecta automáticamente topY, frontX, frontY, leftEdgeX y rightEdgeX para encajar la guía
 *      isométrica verde sobre el bloque actual.
 * 4. Protección contra Anuncios a pantalla completa (isGameScreenValid).
 */
public final class IsometricStackTracker {

    public static final float DEFAULT_MOVING_Y_NORM = 0.545f;
    public static final float DEFAULT_BASE_Y_NORM = 0.590f;
    public static final float DEFAULT_FIXED_AXIS_X_NORM = 0.500f;
    public static final float DEFAULT_HALF_WIDTH_NORM = 0.265f;

    public static final float DEFAULT_MOVING_SCAN_Y_NORM = DEFAULT_MOVING_Y_NORM;
    public static final float DEFAULT_BASE_SCAN_Y_NORM = DEFAULT_BASE_Y_NORM;
    public static final float DEFAULT_TARGET_X_NORM = DEFAULT_FIXED_AXIS_X_NORM;

    public static final float MIN_VALID_SCAN_Y_NORM = 0.34f;
    public static final float MAX_VALID_SCAN_Y_NORM = 0.72f;
    public static final float MIN_SCANLINE_SEPARATION_NORM = 0.02f;

    public static final long POST_SHOT_SETTLE_DELAY_MS = 280L;

    // Región 2D de la torre a analizar
    public static final float TOWER_SCAN_TOP_Y_NORM = 0.34f;
    public static final float TOWER_SCAN_BOTTOM_Y_NORM = 0.74f;
    public static final float TOWER_SCAN_LEFT_X_NORM = 0.03f;
    public static final float TOWER_SCAN_RIGHT_X_NORM = 0.97f;

    // Región central para Auto-Ejes (X entre 0.25f y 0.75f, Y entre 0.40f y 0.68f)
    public static final float AUTO_AXES_MIN_X_NORM = 0.25f;
    public static final float AUTO_AXES_MAX_X_NORM = 0.75f;
    public static final float AUTO_AXES_MIN_Y_NORM = 0.40f;
    public static final float AUTO_AXES_MAX_Y_NORM = 0.68f;

    // Zona de validación del juego (Cartel Verde superior "$100 GUARANTEED")
    private static final float BANNER_TOP_Y_NORM = 0.02f;
    private static final float BANNER_BOTTOM_Y_NORM = 0.22f;
    private static final float BANNER_LEFT_X_NORM = 0.30f;
    private static final float BANNER_RIGHT_X_NORM = 0.70f;

    private static final int GRID_COLS = 96;
    private static final int GRID_ROWS = 68;
    private static final int GRID_CELLS = GRID_COLS * GRID_ROWS;

    private static final int DEFAULT_BG_DIFF_THRESHOLD = 38;
    private static final int TEMPORAL_DIFF_THRESHOLD = 22;
    private static final int MIN_SLAB_WIDTH_PX_REF = 45;

    private int colorDiffThreshold = DEFAULT_BG_DIFF_THRESHOLD;

    private volatile float movingScanYNorm = DEFAULT_MOVING_Y_NORM;
    private volatile float baseScanYNorm = DEFAULT_BASE_Y_NORM;
    private volatile float manualTargetXNorm = DEFAULT_FIXED_AXIS_X_NORM;
    private volatile float manualHalfWidthNorm = DEFAULT_HALF_WIDTH_NORM;
    private volatile boolean autoBaseMode = true;
    private volatile boolean referenceLockActive = false;
    private volatile float lockedTargetCenterX = -1.0f;

    // Geometría 2D rastreada del Rombo Superior de la Base Estacionaria
    private volatile float trackedBaseLeftEdgeX = -1.0f;
    private volatile float trackedBaseRightEdgeX = -1.0f;
    private volatile float trackedBaseCenterX = -1.0f;
    private volatile float trackedBaseWidth = -1.0f;
    private volatile int trackedBaseCrownY = -1;
    private volatile int trackedTowerTopY = -1;
    private volatile float trackedBaseFrontX = -1.0f;
    private volatile int trackedBaseFrontY = -1;

    private volatile boolean needsBaseRecapture = true;
    private volatile boolean pendingAutoAxesSnap = false;
    private volatile boolean pendingPostShotClimb = false;
    private volatile long settleUntilUptimeMs = -10_000L;

    // Historial temporal para |I_t - I_prev|
    private final short[] gridRgbCurrent = new short[GRID_CELLS * 3];
    private final short[] gridRgbPrev = new short[GRID_CELLS * 3];

    private final boolean[] rowHasMovement = new boolean[GRID_ROWS];
    private final float[] rowBlockMinX = new float[GRID_ROWS];
    private final float[] rowBlockMaxX = new float[GRID_ROWS];
    private final float[] rowMovingMinX = new float[GRID_ROWS];
    private final float[] rowMovingMaxX = new float[GRID_ROWS];
    private final int[] rowMeanR = new int[GRID_ROWS];
    private final int[] rowMeanG = new int[GRID_ROWS];
    private final int[] rowMeanB = new int[GRID_ROWS];
    private final int[] rowLum = new int[GRID_ROWS];

    private int capturedFrames = 0;
    private int lastFrameWidth = 0;
    private int lastFrameHeight = 0;

    private final ScanResult reusableResult = new ScanResult();

    public static final class ScanResult {
        public boolean validFrame;
        public boolean isGameScreenValid;
        public int frameWidth;
        public int frameHeight;
        public long timestampNs;
        public float processingTimeMs;

        // Geometría del Rombo Superior de la Base Estacionaria
        public int towerTopY;
        public int baseScanY;
        public int baseCrownY;
        public float baseFrontX;
        public int baseFrontY;
        public boolean baseDetected;

        public float baseLeftEdgeX;
        public float baseRightEdgeX;
        public float baseMinX;
        public float baseMaxX;
        public float baseLeftX;
        public float baseRightX;
        public float baseCenterX;
        public float detectedBaseCenterX;
        public float baseWidth;

        // Losa en Movimiento (Bordes Delanteros Visibles)
        public int movingScanY;
        public int movingCrownY;
        public boolean movingDetected;
        public float movingLeftEdgeX;
        public float movingRightEdgeX;
        public float movingMinX;
        public float movingMaxX;
        public float movingLeftX;
        public float movingRightX;
        public float movingCenterX;
        public float movingWidth;

        // Objetivos efectivos y errores de borde
        public float centerErrorPx;
        public float leftEdgeDeltaPx;
        public float rightEdgeDeltaPx;
        public float effectiveTargetCenterX;
        public float effectiveTargetLeftEdgeX;
        public float effectiveTargetRightEdgeX;
        public boolean isReferenceLocked;

        // Detección de botón de inicio
        public boolean tapToPlayButtonDetected;
        public float tapToPlayCenterX;
        public float tapToPlayCenterY;

        public void reset() {
            validFrame = false;
            isGameScreenValid = true;
            baseDetected = false;
            movingDetected = false;
            tapToPlayButtonDetected = false;
            centerErrorPx = 0.0f;
            leftEdgeDeltaPx = 0.0f;
            rightEdgeDeltaPx = 0.0f;
            processingTimeMs = 0.0f;
        }
    }

    public IsometricStackTracker() {
        resetAxesToFactoryDefaults();
    }

    public synchronized void resetAxesToFactoryDefaults() {
        this.movingScanYNorm = DEFAULT_MOVING_Y_NORM;
        this.baseScanYNorm = DEFAULT_BASE_Y_NORM;
        this.manualTargetXNorm = DEFAULT_FIXED_AXIS_X_NORM;
        this.manualHalfWidthNorm = DEFAULT_HALF_WIDTH_NORM;
        this.autoBaseMode = true;
        this.referenceLockActive = false;
        this.lockedTargetCenterX = -1.0f;

        this.trackedBaseLeftEdgeX = -1.0f;
        this.trackedBaseRightEdgeX = -1.0f;
        this.trackedBaseCenterX = -1.0f;
        this.trackedBaseWidth = -1.0f;
        this.trackedBaseCrownY = -1;
        this.trackedTowerTopY = -1;
        this.trackedBaseFrontX = -1.0f;
        this.trackedBaseFrontY = -1;

        this.needsBaseRecapture = true;
        this.pendingAutoAxesSnap = true;
        this.pendingPostShotClimb = false;
        this.capturedFrames = 0;
    }

    /**
     * Solicita que en el próximo fotograma se escanee automáticamente la cara superior iluminada
     * del bloque central (X en [0.25f, 0.75f], Y en [0.40f, 0.68f]) y se encaje la guía verde.
     */
    public synchronized void requestAutoAxesSnap() {
        this.autoBaseMode = true;
        this.referenceLockActive = false;
        this.lockedTargetCenterX = -1.0f;
        this.needsBaseRecapture = true;
        this.pendingAutoAxesSnap = true;
        this.settleUntilUptimeMs = -10_000L;
    }

    /**
     * Notifica que se ha disparado un toque para detener un bloque.
     * Espera 280ms a que el bloque aterrice y termine el destello de "PERFECT!",
     * y luego escanea unos píxeles más arriba para actualizar baseLeftEdgeX, baseRightEdgeX y la cima.
     */
    public void notifyShotFired(long settleDelayMs) {
        long delay = Math.max(POST_SHOT_SETTLE_DELAY_MS, settleDelayMs);
        this.settleUntilUptimeMs = SystemClock.uptimeMillis() + delay;
        this.needsBaseRecapture = true;
        this.pendingPostShotClimb = true;
    }

    public boolean isInPostShotSettleWindow() {
        return SystemClock.uptimeMillis() < settleUntilUptimeMs;
    }

    public static boolean areSavedAxesValid(float savedMovingY, float savedBaseY) {
        if (Float.isNaN(savedMovingY) || Float.isNaN(savedBaseY)) {
            return false;
        }
        if (savedMovingY < MIN_VALID_SCAN_Y_NORM || savedMovingY > MAX_VALID_SCAN_Y_NORM) {
            return false;
        }
        if (savedBaseY < MIN_VALID_SCAN_Y_NORM || savedBaseY > MAX_VALID_SCAN_Y_NORM) {
            return false;
        }
        return savedMovingY <= (savedBaseY - MIN_SCANLINE_SEPARATION_NORM);
    }

    public synchronized void enforceAntiInversionRule() {
        float mov = clamp(this.movingScanYNorm, MIN_VALID_SCAN_Y_NORM, MAX_VALID_SCAN_Y_NORM - 0.03f);
        float base = clamp(this.baseScanYNorm, MIN_VALID_SCAN_Y_NORM + 0.03f, MAX_VALID_SCAN_Y_NORM);
        if (mov >= base - MIN_SCANLINE_SEPARATION_NORM) {
            this.movingScanYNorm = Math.max(MIN_VALID_SCAN_Y_NORM, base - 0.045f);
            this.baseScanYNorm = base;
        } else {
            this.movingScanYNorm = mov;
            this.baseScanYNorm = base;
        }
    }

    public synchronized void setMovingScanYNorm(float normY) {
        float clampedY = clamp(normY, MIN_VALID_SCAN_Y_NORM, MAX_VALID_SCAN_Y_NORM - 0.03f);
        float maxAllowed = this.baseScanYNorm - MIN_SCANLINE_SEPARATION_NORM;
        this.movingScanYNorm = Math.min(clampedY, maxAllowed);
    }

    public float getMovingScanYNorm() {
        return movingScanYNorm;
    }

    public synchronized void setBaseScanYNorm(float normY) {
        float clampedY = clamp(normY, MIN_VALID_SCAN_Y_NORM + 0.03f, MAX_VALID_SCAN_Y_NORM);
        float minAllowed = this.movingScanYNorm + MIN_SCANLINE_SEPARATION_NORM;
        this.baseScanYNorm = Math.max(clampedY, minAllowed);
        if (lastFrameHeight > 64) {
            int newCrownY = Math.round(this.baseScanYNorm * lastFrameHeight);
            int halfRhombusH = Math.round(this.manualHalfWidthNorm * lastFrameWidth * 0.46f);
            this.trackedBaseCrownY = newCrownY;
            this.trackedTowerTopY = Math.max(8, newCrownY - halfRhombusH);
            this.trackedBaseFrontY = Math.min(lastFrameHeight - 8, newCrownY + halfRhombusH);
        }
    }

    public float getBaseScanYNorm() {
        return baseScanYNorm;
    }

    public synchronized void setManualTargetXNorm(float normX) {
        this.manualTargetXNorm = clamp(normX, 0.20f, 0.80f);
        this.lockedTargetCenterX = -1.0f;
        if (lastFrameWidth > 64) {
            float centerPx = this.manualTargetXNorm * lastFrameWidth;
            float halfW = this.manualHalfWidthNorm * lastFrameWidth;
            this.trackedBaseCenterX = centerPx;
            this.trackedBaseFrontX = centerPx;
            this.trackedBaseLeftEdgeX = Math.max(8.0f, centerPx - halfW);
            this.trackedBaseRightEdgeX = Math.min(lastFrameWidth - 8.0f, centerPx + halfW);
            this.trackedBaseWidth = this.trackedBaseRightEdgeX - this.trackedBaseLeftEdgeX;
        }
    }

    public float getManualTargetXNorm() {
        return manualTargetXNorm;
    }

    public synchronized void setManualHalfWidthNorm(float halfWidthNorm) {
        this.manualHalfWidthNorm = clamp(halfWidthNorm, 0.07f, 0.44f);
        if (lastFrameWidth > 64) {
            float centerPx = (trackedBaseCenterX > 0.0f) ? trackedBaseCenterX : (manualTargetXNorm * lastFrameWidth);
            float halfW = this.manualHalfWidthNorm * lastFrameWidth;
            this.trackedBaseLeftEdgeX = Math.max(8.0f, centerPx - halfW);
            this.trackedBaseRightEdgeX = Math.min(lastFrameWidth - 8.0f, centerPx + halfW);
            this.trackedBaseWidth = this.trackedBaseRightEdgeX - this.trackedBaseLeftEdgeX;
        }
    }

    public float getManualHalfWidthNorm() {
        return manualHalfWidthNorm;
    }

    /**
     * Permite ajustar directamente desde las miras (⊕) del calibrador los bordes izquierdo y derecho
     * y el centro del rombo guía sobre el bloque base.
     */
    public synchronized void setManualRhombusEdgesNorm(float leftEdgeNorm, float rightEdgeNorm, float crownYNorm) {
        float clampedLeft = clamp(leftEdgeNorm, 0.06f, 0.80f);
        float clampedRight = clamp(rightEdgeNorm, clampedLeft + 0.14f, 0.94f);
        float centerNorm = (clampedLeft + clampedRight) * 0.5f;
        float halfW = (clampedRight - clampedLeft) * 0.5f;

        this.manualTargetXNorm = clamp(centerNorm, 0.20f, 0.80f);
        this.manualHalfWidthNorm = clamp(halfW, 0.07f, 0.44f);
        setBaseScanYNorm(crownYNorm);
        setMovingScanYNorm(this.baseScanYNorm - 0.045f);

        if (lastFrameWidth > 64 && lastFrameHeight > 64) {
            this.trackedBaseLeftEdgeX = clampedLeft * lastFrameWidth;
            this.trackedBaseRightEdgeX = clampedRight * lastFrameWidth;
            this.trackedBaseCenterX = this.manualTargetXNorm * lastFrameWidth;
            this.trackedBaseWidth = this.trackedBaseRightEdgeX - this.trackedBaseLeftEdgeX;
            this.trackedBaseCrownY = Math.round(this.baseScanYNorm * lastFrameHeight);
            int halfRhombusH = Math.round(this.trackedBaseWidth * 0.24f);
            this.trackedTowerTopY = Math.max(8, this.trackedBaseCrownY - halfRhombusH);
            this.trackedBaseFrontX = this.trackedBaseCenterX;
            this.trackedBaseFrontY = Math.min(lastFrameHeight - 8, this.trackedBaseCrownY + halfRhombusH);
        }
    }

    public void setAutoBaseMode(boolean autoBase) {
        this.autoBaseMode = autoBase;
    }

    public boolean isAutoBaseMode() {
        return autoBaseMode;
    }

    public void setColorDiffThreshold(int threshold) {
        this.colorDiffThreshold = Math.max(20, Math.min(110, threshold));
    }

    public int getColorDiffThreshold() {
        return colorDiffThreshold;
    }

    public void lockCurrentReference(float currentTargetX) {
        if (currentTargetX > 0.0f) {
            this.lockedTargetCenterX = currentTargetX;
            this.referenceLockActive = true;
        }
    }

    public void unlockReference() {
        this.referenceLockActive = false;
        this.lockedTargetCenterX = -1.0f;
        this.needsBaseRecapture = true;
    }

    public boolean isReferenceLockActive() {
        return referenceLockActive;
    }

    public ScanResult processImage(Image image) {
        try {
            if (image == null) {
                reusableResult.reset();
                return reusableResult;
            }
            Image.Plane[] planes = image.getPlanes();
            if (planes == null || planes.length == 0 || planes[0].getBuffer() == null) {
                reusableResult.reset();
                return reusableResult;
            }
            Image.Plane plane = planes[0];
            ByteBuffer buffer = plane.getBuffer();
            int width = image.getWidth();
            int height = image.getHeight();
            int rowStride = plane.getRowStride();
            int pixelStride = plane.getPixelStride();
            long timestampNs = image.getTimestamp();
            if (timestampNs <= 0L) {
                timestampNs = System.nanoTime();
            }
            return processByteBuffer(buffer, width, height, rowStride, pixelStride, timestampNs);
        } catch (Throwable t) {
            reusableResult.reset();
            return reusableResult;
        }
    }

    /**
     * Procesa directamente el ByteBuffer RGBA a 60 FPS:
     * 1. Valida que la pantalla sea del juego y no un anuncio blanco externo.
     * 2. Si se pulsó Auto-Ejes o terminó la ventana de 280ms tras colocar un bloque,
     *    escanea la cara superior iluminada de la torre para actualizar:
     *    topY, frontX, frontY, baseLeftEdgeX y baseRightEdgeX.
     * 3. Extrae en cada frame los bordes delanteros visibles de la nueva losa:
     *    movingLeftEdgeX y movingRightEdgeX (100% inmunes a recortes en los bordes de pantalla).
     */
    public ScanResult processByteBuffer(
            ByteBuffer buffer,
            int width,
            int height,
            int rowStride,
            int pixelStride,
            long timestampNs) {

        long startNs = System.nanoTime();
        reusableResult.reset();

        try {
            if (buffer == null || width <= 64 || height <= 64 || pixelStride < 4) {
                return reusableResult;
            }

            if (width != lastFrameWidth || height != lastFrameHeight) {
                lastFrameWidth = width;
                lastFrameHeight = height;
                capturedFrames = 0;
                needsBaseRecapture = true;
            }

            int bufferLimit = buffer.limit();
            reusableResult.validFrame = true;
            reusableResult.frameWidth = width;
            reusableResult.frameHeight = height;
            reusableResult.timestampNs = timestampNs;

            // 1. Verificación de Pantalla de Juego vs Anuncio Publicitario
            boolean gameValid = verifyGameScreenActive(buffer, bufferLimit, width, height, rowStride, pixelStride);
            reusableResult.isGameScreenValid = gameValid;
            if (!gameValid) {
                reusableResult.processingTimeMs = (System.nanoTime() - startNs) / 1_000_000.0f;
                return reusableResult;
            }

            if (capturedFrames >= 1) {
                System.arraycopy(gridRgbCurrent, 0, gridRgbPrev, 0, gridRgbCurrent.length);
            }

            int roiTopY = clampInt(Math.round(TOWER_SCAN_TOP_Y_NORM * height), 8, height - 16);
            int roiBottomY = clampInt(Math.round(TOWER_SCAN_BOTTOM_Y_NORM * height), roiTopY + 32, height - 8);
            int scanStartX = (clampInt(Math.round(TOWER_SCAN_LEFT_X_NORM * width), 6, width - 12) / 2) * 2;
            int scanEndX = (clampInt(Math.round(TOWER_SCAN_RIGHT_X_NORM * width), scanStartX + 32, width - 6) / 2) * 2;

            int skyLeftX = (clampInt(Math.round(0.015f * width), 2, scanStartX - 2) / 2) * 2;
            int skyRightX = (clampInt(Math.round(0.985f * width), scanEndX + 2, width - 4) / 2) * 2;

            float minSlabWidthPx = Math.max(28.0f, (MIN_SLAB_WIDTH_PX_REF / 1080.0f) * width);
            boolean hasHistory = (capturedFrames >= 1);

            Arrays.fill(rowHasMovement, false);
            Arrays.fill(rowBlockMinX, -1.0f);
            Arrays.fill(rowBlockMaxX, -1.0f);
            Arrays.fill(rowMovingMinX, -1.0f);
            Arrays.fill(rowMovingMaxX, -1.0f);
            Arrays.fill(rowLum, 0);

            // 2. Muestreo 2D de la zona de la torre
            for (int rIdx = 0; rIdx < GRID_ROWS; rIdx++) {
                float normRow = rIdx / (float) (GRID_ROWS - 1);
                int y = roiTopY + Math.round(normRow * (roiBottomY - roiTopY));
                int rowOffset = y * rowStride;
                if (rowOffset < 0 || rowOffset + (skyRightX * pixelStride) + 3 >= bufferLimit) {
                    continue;
                }

                int bgLIdx = rowOffset + (skyLeftX * pixelStride);
                int bgRIdx = rowOffset + (skyRightX * pixelStride);
                int bgLR = buffer.get(bgLIdx) & 0xFF;
                int bgLG = buffer.get(bgLIdx + 1) & 0xFF;
                int bgLB = buffer.get(bgLIdx + 2) & 0xFF;

                int bgRR = buffer.get(bgRIdx) & 0xFF;
                int bgRG = buffer.get(bgRIdx + 1) & 0xFF;
                int bgRB = buffer.get(bgRIdx + 2) & 0xFF;

                float rowMin = Float.MAX_VALUE;
                float rowMax = -1.0f;
                float movMin = Float.MAX_VALUE;
                float movMax = -1.0f;
                int movCount = 0;
                int sumR = 0, sumG = 0, sumB = 0, blockCount = 0;

                for (int cIdx = 0; cIdx < GRID_COLS; cIdx++) {
                    float normCol = cIdx / (float) (GRID_COLS - 1);
                    int x = scanStartX + Math.round(normCol * (scanEndX - scanStartX));
                    int pxIdx = rowOffset + (x * pixelStride);

                    int r = buffer.get(pxIdx) & 0xFF;
                    int g = buffer.get(pxIdx + 1) & 0xFF;
                    int b = buffer.get(pxIdx + 2) & 0xFF;

                    int cellBase = ((rIdx * GRID_COLS) + cIdx) * 3;
                    gridRgbCurrent[cellBase] = (short) r;
                    gridRgbCurrent[cellBase + 1] = (short) g;
                    gridRgbCurrent[cellBase + 2] = (short) b;

                    boolean isTopFaceOrBlock = isIlluminatedTopFacePixel(
                            r, g, b, bgLR, bgLG, bgLB, bgRR, bgRG, bgRB, colorDiffThreshold);

                    if (isTopFaceOrBlock) {
                        if (x < rowMin) rowMin = x;
                        if (x > rowMax) rowMax = x;
                        sumR += r;
                        sumG += g;
                        sumB += b;
                        blockCount++;

                        if (hasHistory) {
                            int pr = gridRgbPrev[cellBase];
                            int pg = gridRgbPrev[cellBase + 1];
                            int pb = gridRgbPrev[cellBase + 2];
                            int tempDiff = Math.abs(r - pr) + Math.abs(g - pg) + Math.abs(b - pb);
                            if (tempDiff >= TEMPORAL_DIFF_THRESHOLD) {
                                if (x < movMin) movMin = x;
                                if (x > movMax) movMax = x;
                                movCount++;
                            }
                        }
                    }
                }

                if (blockCount >= 3 && (rowMax - rowMin) >= minSlabWidthPx) {
                    rowBlockMinX[rIdx] = rowMin;
                    rowBlockMaxX[rIdx] = rowMax;
                    int meanR = sumR / blockCount;
                    int meanG = sumG / blockCount;
                    int meanB = sumB / blockCount;
                    rowMeanR[rIdx] = meanR;
                    rowMeanG[rIdx] = meanG;
                    rowMeanB[rIdx] = meanB;
                    rowLum[rIdx] = (meanR * 77 + meanG * 150 + meanB * 29) >> 8;

                    if (movCount >= 2 && (movMax - movMin) >= (minSlabWidthPx * 0.35f)) {
                        rowHasMovement[rIdx] = true;
                        rowMovingMinX[rIdx] = movMin;
                        rowMovingMaxX[rIdx] = movMax;
                    }
                }
            }

            capturedFrames++;

            long nowUptime = SystemClock.uptimeMillis();
            boolean inSettleWindow = (nowUptime < settleUntilUptimeMs);

            // 3. Auto-Detección de la Cara Superior Iluminada (Rombo Isométrico: topY, leftEdgeX, rightEdgeX, frontX, frontY)
            // Se ejecuta cuando:
            // - El usuario pulsa Auto-Ejes (pendingAutoAxesSnap)
            // - Terminó la espera de 280ms tras colocar un bloque (auto-subida de cima)
            // - La base aún no ha sido adquirida
            if ((!inSettleWindow && (needsBaseRecapture || pendingAutoAxesSnap || pendingPostShotClimb))
                    || trackedBaseCenterX < 0.0f) {

                updateStationaryTopRhombusFromGrid(
                        buffer, bufferLimit, width, height, rowStride, pixelStride,
                        roiTopY, roiBottomY, scanStartX, scanEndX, skyLeftX, skyRightX,
                        minSlabWidthPx, inSettleWindow);
            }

            // Muestreo fino en la fila de baseScanYNorm para máxima precisión horizontal (paso de 2px)
            int exactBaseY = clampInt(
                    (trackedBaseCrownY > 0 && autoBaseMode) ? trackedBaseCrownY : Math.round(baseScanYNorm * height),
                    8,
                    height - 9);
            int exactMovingY = clampInt(Math.round(movingScanYNorm * height), 8, exactBaseY - 4);

            float[] directBaseEdges = scanSingleRowEdges(
                    buffer, bufferLimit, rowStride, pixelStride,
                    exactBaseY, scanStartX, scanEndX, skyLeftX, skyRightX);

            if (directBaseEdges != null && (directBaseEdges[1] - directBaseEdges[0]) >= minSlabWidthPx) {
                float center = (directBaseEdges[0] + directBaseEdges[1]) * 0.5f;
                float span = directBaseEdges[1] - directBaseEdges[0];
                if (center >= width * 0.22f && center <= width * 0.78f && span >= width * 0.12f) {
                    if (autoBaseMode || trackedBaseCenterX < 0.0f || pendingAutoAxesSnap) {
                        trackedBaseLeftEdgeX = directBaseEdges[0];
                        trackedBaseRightEdgeX = directBaseEdges[1];
                        trackedBaseCenterX = center;
                        trackedBaseWidth = span;
                        trackedBaseCrownY = exactBaseY;
                        int halfRhombusH = Math.round(span * 0.24f);
                        if (trackedTowerTopY <= 0) {
                            trackedTowerTopY = Math.max(8, exactBaseY - halfRhombusH);
                        }
                        trackedBaseFrontX = center;
                        trackedBaseFrontY = Math.min(height - 8, exactBaseY + halfRhombusH);
                        manualTargetXNorm = clamp(center / (float) width, 0.20f, 0.80f);
                        manualHalfWidthNorm = clamp((span * 0.5f) / (float) width, 0.07f, 0.44f);
                        pendingAutoAxesSnap = false;
                    }
                }
            }

            // Fallback de fábrica seguro si no se detectó bloque aún
            if (trackedBaseCenterX < 0.0f) {
                float centerPx = manualTargetXNorm * width;
                float halfW = manualHalfWidthNorm * width;
                trackedBaseLeftEdgeX = Math.max(12.0f, centerPx - halfW);
                trackedBaseRightEdgeX = Math.min(width - 12.0f, centerPx + halfW);
                trackedBaseCenterX = centerPx;
                trackedBaseWidth = trackedBaseRightEdgeX - trackedBaseLeftEdgeX;
                trackedBaseCrownY = exactBaseY;
                int halfRhombusH = Math.round(trackedBaseWidth * 0.24f);
                trackedTowerTopY = Math.max(8, exactBaseY - halfRhombusH);
                trackedBaseFrontX = centerPx;
                trackedBaseFrontY = Math.min(height - 8, exactBaseY + halfRhombusH);
            }

            reusableResult.baseDetected = true;
            reusableResult.towerTopY = trackedTowerTopY;
            reusableResult.baseCrownY = trackedBaseCrownY;
            reusableResult.baseScanY = trackedBaseCrownY;
            reusableResult.baseFrontX = trackedBaseFrontX;
            reusableResult.baseFrontY = trackedBaseFrontY;
            reusableResult.baseLeftEdgeX = trackedBaseLeftEdgeX;
            reusableResult.baseRightEdgeX = trackedBaseRightEdgeX;
            reusableResult.baseMinX = trackedBaseLeftEdgeX;
            reusableResult.baseMaxX = trackedBaseRightEdgeX;
            reusableResult.baseLeftX = trackedBaseLeftEdgeX;
            reusableResult.baseRightX = trackedBaseRightEdgeX;
            reusableResult.baseWidth = trackedBaseWidth;
            reusableResult.baseCenterX = trackedBaseCenterX;
            reusableResult.detectedBaseCenterX = trackedBaseCenterX;

            // 4. Extracción Milimétrica del Borde Delantero Visible (Leading Edge) de la Losa en Movimiento
            // Escanea por encima de la cima de la base (y filas con movimiento temporal) para obtener
            // movingLeftEdgeX y movingRightEdgeX sin importar si el extremo opuesto está cortado por la pantalla.
            float movingLeftEdge = Float.MAX_VALUE;
            float movingRightEdge = -1.0f;
            int movRowCount = 0;
            int movRowYSum = 0;

            for (int rIdx = 0; rIdx < GRID_ROWS; rIdx++) {
                if (rowBlockMinX[rIdx] <= 0.0f) {
                    continue;
                }
                float normRow = rIdx / (float) (GRID_ROWS - 1);
                int y = roiTopY + Math.round(normRow * (roiBottomY - roiTopY));

                // La losa móvil se encuentra por encima de baseCrownY o presenta movimiento temporal
                if (y > trackedBaseCrownY + 8) {
                    continue;
                }

                boolean isAboveTowerTop = (trackedTowerTopY > 0 && y < trackedTowerTopY - 4);
                boolean hasTempMove = rowHasMovement[rIdx];
                boolean extendsOutsideBase = (rowBlockMinX[rIdx] < trackedBaseLeftEdgeX - 8.0f)
                        || (rowBlockMaxX[rIdx] > trackedBaseRightEdgeX + 8.0f);

                if (hasTempMove || isAboveTowerTop || (y < trackedBaseCrownY - 4 && extendsOutsideBase)) {
                    float leftCandidate = hasTempMove && rowMovingMinX[rIdx] > 0.0f
                            ? Math.min(rowMovingMinX[rIdx], rowBlockMinX[rIdx])
                            : rowBlockMinX[rIdx];
                    float rightCandidate = hasTempMove && rowMovingMaxX[rIdx] > 0.0f
                            ? Math.max(rowMovingMaxX[rIdx], rowBlockMaxX[rIdx])
                            : rowBlockMaxX[rIdx];

                    // Si la fila se solapa en Y con la parte superior de la base, aislar el lado que sobresale
                    if (!isAboveTowerTop && y >= trackedTowerTopY - 4) {
                        boolean protrudesLeft = (leftCandidate < trackedBaseLeftEdgeX - 6.0f);
                        boolean protrudesRight = (rightCandidate > trackedBaseRightEdgeX + 6.0f);
                        if (protrudesLeft && !protrudesRight && trackedBaseWidth > minSlabWidthPx) {
                            rightCandidate = Math.min(rightCandidate, leftCandidate + trackedBaseWidth);
                        } else if (protrudesRight && !protrudesLeft && trackedBaseWidth > minSlabWidthPx) {
                            leftCandidate = Math.max(leftCandidate, rightCandidate - trackedBaseWidth);
                        }
                    }

                    if (leftCandidate < movingLeftEdge) movingLeftEdge = leftCandidate;
                    if (rightCandidate > movingRightEdge) movingRightEdge = rightCandidate;
                    movRowYSum += y;
                    movRowCount++;
                }
            }

            if (movRowCount > 0 && movingRightEdge > movingLeftEdge
                    && (movingRightEdge - movingLeftEdge) >= (minSlabWidthPx * 0.45f)) {

                int movY = movRowYSum / movRowCount;
                // Refinar con paso de 2px en la fila central del bloque móvil para precisión milimétrica
                float[] refinedMovEdges = scanSingleRowEdges(
                        buffer, bufferLimit, rowStride, pixelStride,
                        movY, scanStartX, scanEndX, skyLeftX, skyRightX);
                if (refinedMovEdges != null && (refinedMovEdges[1] - refinedMovEdges[0]) >= (minSlabWidthPx * 0.45f)) {
                    movingLeftEdge = Math.min(movingLeftEdge, refinedMovEdges[0]);
                    movingRightEdge = Math.max(movingRightEdge, refinedMovEdges[1]);
                }

                // Si el bloque viene entrando cortado por el borde izquierdo o derecho de la pantalla:
                // - Si está pegado al borde izquierdo (movingLeftEdge <= scanStartX + 10),
                //   su borde delantero derecho (movingRightEdge) es 100% exacto; reconstruimos su centro real
                //   usando el ancho de la base (trackedBaseWidth).
                // - Si está pegado al borde derecho (movingRightEdge >= scanEndX - 10),
                //   su borde delantero izquierdo (movingLeftEdge) es 100% exacto; reconstruimos su centro real
                //   usando el ancho de la base (trackedBaseWidth).
                boolean clippedOnLeft = (movingLeftEdge <= scanStartX + 12);
                boolean clippedOnRight = (movingRightEdge >= scanEndX - 12);
                float effectiveMovCenter;
                float effectiveMovWidth = movingRightEdge - movingLeftEdge;

                if (clippedOnLeft && !clippedOnRight && trackedBaseWidth > minSlabWidthPx) {
                    effectiveMovCenter = movingRightEdge - (trackedBaseWidth * 0.5f);
                    effectiveMovWidth = trackedBaseWidth;
                } else if (clippedOnRight && !clippedOnLeft && trackedBaseWidth > minSlabWidthPx) {
                    effectiveMovCenter = movingLeftEdge + (trackedBaseWidth * 0.5f);
                    effectiveMovWidth = trackedBaseWidth;
                } else {
                    effectiveMovCenter = (movingLeftEdge + movingRightEdge) * 0.5f;
                }

                reusableResult.movingDetected = true;
                reusableResult.movingCrownY = movY;
                reusableResult.movingScanY = movY;
                reusableResult.movingLeftEdgeX = movingLeftEdge;
                reusableResult.movingRightEdgeX = movingRightEdge;
                reusableResult.movingMinX = movingLeftEdge;
                reusableResult.movingMaxX = movingRightEdge;
                reusableResult.movingLeftX = movingLeftEdge;
                reusableResult.movingRightX = movingRightEdge;
                reusableResult.movingWidth = effectiveMovWidth;
                reusableResult.movingCenterX = effectiveMovCenter;
            }

            // Fallback directo sobre exactMovingY (para tests sintéticos o calibración de línea)
            if (!reusableResult.movingDetected) {
                float[] directMov = scanSingleRowEdges(
                        buffer, bufferLimit, rowStride, pixelStride,
                        exactMovingY, scanStartX, scanEndX, skyLeftX, skyRightX);
                if (directMov != null && (directMov[1] - directMov[0]) >= minSlabWidthPx) {
                    reusableResult.movingDetected = true;
                    reusableResult.movingCrownY = exactMovingY;
                    reusableResult.movingScanY = exactMovingY;
                    reusableResult.movingLeftEdgeX = directMov[0];
                    reusableResult.movingRightEdgeX = directMov[1];
                    reusableResult.movingMinX = directMov[0];
                    reusableResult.movingMaxX = directMov[1];
                    reusableResult.movingLeftX = directMov[0];
                    reusableResult.movingRightX = directMov[1];
                    reusableResult.movingWidth = directMov[1] - directMov[0];
                    reusableResult.movingCenterX = (directMov[0] + directMov[1]) * 0.5f;
                }
            }

            // 5. Configurar Objetivos de Borde Izquierdo, Borde Derecho y Centro
            if (!autoBaseMode) {
                float manualCenterPx = manualTargetXNorm * width;
                float manualHalfW = manualHalfWidthNorm * width;
                reusableResult.effectiveTargetCenterX = manualCenterPx;
                reusableResult.effectiveTargetLeftEdgeX = manualCenterPx - manualHalfW;
                reusableResult.effectiveTargetRightEdgeX = manualCenterPx + manualHalfW;
                reusableResult.isReferenceLocked = true;
            } else if (referenceLockActive && lockedTargetCenterX > 0.0f) {
                float halfW = reusableResult.baseWidth * 0.5f;
                reusableResult.effectiveTargetCenterX = lockedTargetCenterX;
                reusableResult.effectiveTargetLeftEdgeX = lockedTargetCenterX - halfW;
                reusableResult.effectiveTargetRightEdgeX = lockedTargetCenterX + halfW;
                reusableResult.isReferenceLocked = true;
            } else {
                reusableResult.effectiveTargetCenterX = reusableResult.baseCenterX;
                reusableResult.effectiveTargetLeftEdgeX = reusableResult.baseLeftEdgeX;
                reusableResult.effectiveTargetRightEdgeX = reusableResult.baseRightEdgeX;
                reusableResult.isReferenceLocked = false;
            }

            if (reusableResult.movingDetected && reusableResult.baseDetected) {
                reusableResult.centerErrorPx = reusableResult.movingCenterX - reusableResult.effectiveTargetCenterX;
                reusableResult.leftEdgeDeltaPx = reusableResult.movingLeftEdgeX - reusableResult.effectiveTargetLeftEdgeX;
                reusableResult.rightEdgeDeltaPx = reusableResult.movingRightEdgeX - reusableResult.effectiveTargetRightEdgeX;
            }

            // 6. Detectar botón "Tap to play" si no hay losa moviéndose
            if (!reusableResult.movingDetected) {
                detectTapToPlayButtonSafe(buffer, bufferLimit, width, height, rowStride, pixelStride, reusableResult);
            }

        } catch (Throwable t) {
            reusableResult.reset();
        }

        reusableResult.processingTimeMs = (System.nanoTime() - startNs) / 1_000_000.0f;
        return reusableResult;
    }

    /**
     * Escanea la región central de la torre (X entre 0.25f y 0.75f, Y entre 0.38f y 0.68f)
     * para encontrar la cara superior iluminada del último bloque estacionario:
     * - Vértice superior: topY
     * - Bordes laterales máximos del rombo: baseLeftEdgeX, baseRightEdgeX en baseCrownY
     * - Vértice frontal inferior: frontX, frontY
     */
    private void updateStationaryTopRhombusFromGrid(
            ByteBuffer buffer,
            int bufferLimit,
            int width,
            int height,
            int rowStride,
            int pixelStride,
            int roiTopY,
            int roiBottomY,
            int scanStartX,
            int scanEndX,
            int skyLeftX,
            int skyRightX,
            float minSlabWidthPx,
            boolean inSettleWindow) {

        int stationaryTopRow = -1;
        for (int rIdx = 0; rIdx < GRID_ROWS - 1; rIdx++) {
            float normRow = rIdx / (float) (GRID_ROWS - 1);
            int y = roiTopY + Math.round(normRow * (roiBottomY - roiTopY));
            float yNorm = y / (float) height;

            // Si es Auto-Ejes, priorizar el rango [0.38f, 0.68f]
            if (pendingAutoAxesSnap && (yNorm < 0.38f || yNorm > 0.68f)) {
                continue;
            }

            if (rowBlockMinX[rIdx] > 0.0f && !rowHasMovement[rIdx]
                    && rowBlockMinX[rIdx + 1] > 0.0f && !rowHasMovement[rIdx + 1]) {
                float rowCenter = (rowBlockMinX[rIdx] + rowBlockMaxX[rIdx]) * 0.5f;
                if (rowCenter >= width * AUTO_AXES_MIN_X_NORM && rowCenter <= width * AUTO_AXES_MAX_X_NORM) {
                    stationaryTopRow = rIdx;
                    break;
                }
            }
        }

        if (stationaryTopRow < 0) {
            return;
        }

        int crownRow = stationaryTopRow;
        float maxCrownSpan = rowBlockMaxX[stationaryTopRow] - rowBlockMinX[stationaryTopRow];
        int topR = rowMeanR[stationaryTopRow];
        int topG = rowMeanG[stationaryTopRow];
        int topB = rowMeanB[stationaryTopRow];
        int topLum = rowLum[stationaryTopRow];
        int bottomRhombusRow = stationaryTopRow;

        // Recorrer las filas de la cara superior iluminada del bloque (mismo color claro que topRow)
        int searchLimitRow = Math.min(GRID_ROWS - 1, stationaryTopRow + 15);
        for (int rIdx = stationaryTopRow + 1; rIdx <= searchLimitRow; rIdx++) {
            if (rowBlockMinX[rIdx] <= 0.0f || rowHasMovement[rIdx]) {
                continue;
            }
            int colorDelta = Math.abs(rowMeanR[rIdx] - topR)
                    + Math.abs(rowMeanG[rIdx] - topG)
                    + Math.abs(rowMeanB[rIdx] - topB);
            int lumDelta = topLum - rowLum[rIdx];

            // Cuando entramos en las paredes laterales más oscuras del bloque, la luminancia cae
            if (colorDelta > 75 || lumDelta > 28) {
                break;
            }

            bottomRhombusRow = rIdx;
            float span = rowBlockMaxX[rIdx] - rowBlockMinX[rIdx];
            if (span >= maxCrownSpan - 4.0f) {
                maxCrownSpan = span;
                crownRow = rIdx;
            }
        }

        int topY = roiTopY + Math.round((stationaryTopRow / (float) (GRID_ROWS - 1)) * (roiBottomY - roiTopY));
        int crownY = roiTopY + Math.round((crownRow / (float) (GRID_ROWS - 1)) * (roiBottomY - roiTopY));
        int frontY = roiTopY + Math.round((bottomRhombusRow / (float) (GRID_ROWS - 1)) * (roiBottomY - roiTopY));

        // Refinar bordes izquierdo y derecho con escaneo de 2px en crownY
        float exactLeftX = rowBlockMinX[crownRow];
        float exactRightX = rowBlockMaxX[crownRow];
        float[] fineEdges = scanSingleRowEdges(
                buffer, bufferLimit, rowStride, pixelStride,
                crownY, scanStartX, scanEndX, skyLeftX, skyRightX);
        if (fineEdges != null && (fineEdges[1] - fineEdges[0]) >= minSlabWidthPx) {
            exactLeftX = fineEdges[0];
            exactRightX = fineEdges[1];
        }

        float exactWidth = exactRightX - exactLeftX;
        float exactCenter = (exactLeftX + exactRightX) * 0.5f;

        // Candado de seguridad: Centro dentro de [0.25f * W, 0.75f * W] y ancho >= 0.12f * W
        boolean validCentralBlock = (exactWidth >= width * 0.12f)
                && (exactCenter >= width * AUTO_AXES_MIN_X_NORM)
                && (exactCenter <= width * AUTO_AXES_MAX_X_NORM);

        if (!validCentralBlock) {
            return;
        }

        int geometricHalfH = Math.max(12, Math.round(exactWidth * 0.24f));
        if (frontY <= crownY + 6) {
            frontY = Math.min(height - 12, crownY + geometricHalfH);
        }
        if (topY >= crownY - 6) {
            topY = Math.max(12, crownY - geometricHalfH);
        }

        trackedBaseLeftEdgeX = exactLeftX;
        trackedBaseRightEdgeX = exactRightX;
        trackedBaseCenterX = exactCenter;
        trackedBaseWidth = exactWidth;
        trackedBaseCrownY = crownY;
        trackedTowerTopY = topY;
        trackedBaseFrontX = exactCenter;
        trackedBaseFrontY = frontY;

        baseScanYNorm = clamp(crownY / (float) height, MIN_VALID_SCAN_Y_NORM + 0.03f, MAX_VALID_SCAN_Y_NORM);
        movingScanYNorm = clamp(baseScanYNorm - 0.045f, MIN_VALID_SCAN_Y_NORM, baseScanYNorm - 0.02f);
        manualTargetXNorm = clamp(exactCenter / (float) width, 0.20f, 0.80f);
        manualHalfWidthNorm = clamp((exactWidth * 0.5f) / (float) width, 0.07f, 0.44f);

        if (!inSettleWindow) {
            needsBaseRecapture = false;
            pendingAutoAxesSnap = false;
            pendingPostShotClimb = false;
        }
    }

    /**
     * Valida que la pantalla pertenezca al juego activo y no sea un anuncio blanco a pantalla completa.
     */
    private boolean verifyGameScreenActive(
            ByteBuffer buffer,
            int bufferLimit,
            int width,
            int height,
            int rowStride,
            int pixelStride) {

        try {
            int topY = Math.round(BANNER_TOP_Y_NORM * height);
            int bottomY = Math.round(BANNER_BOTTOM_Y_NORM * height);
            int startX = Math.round(BANNER_LEFT_X_NORM * width);
            int endX = Math.round(BANNER_RIGHT_X_NORM * width);

            int greenCount = 0;
            int whiteAdCount = 0;
            int sampleCount = 0;

            for (int y = topY; y <= bottomY; y += 12) {
                int rowOffset = y * rowStride;
                if (rowOffset < 0 || rowOffset + (endX * pixelStride) + 3 >= bufferLimit) {
                    continue;
                }
                for (int x = startX; x <= endX; x += 16) {
                    int idx = rowOffset + (x * pixelStride);
                    int r = buffer.get(idx) & 0xFF;
                    int g = buffer.get(idx + 1) & 0xFF;
                    int b = buffer.get(idx + 2) & 0xFF;

                    sampleCount++;
                    if (g > r + 25 && g > b + 20) {
                        greenCount++;
                    }
                    if (r > 240 && g > 240 && b > 240) {
                        whiteAdCount++;
                    }
                }
            }

            if (sampleCount > 10 && whiteAdCount >= (sampleCount * 0.88f)) {
                return false;
            }
            if (greenCount >= 4) {
                return true;
            }
            return true;
        } catch (Throwable t) {
            return true;
        }
    }

    /**
     * Clasifica si un píxel pertenece a la cara superior iluminada de un bloque 3D:
     * - Descarta el suelo gris neutro y nubes (chroma < 18).
     * - Descarta blancos puros de anuncios (min > 235).
     * - Descarta la pared lateral derecha oscura (max < 140 y r < 128).
     * - Exige diferencia de color contra el cielo lateral o saturación propia del bloque.
     */
    private static boolean isIlluminatedTopFacePixel(
            int r, int g, int b,
            int bgLR, int bgLG, int bgLB,
            int bgRR, int bgRG, int bgRB,
            int threshold) {

        int max = Math.max(r, Math.max(g, b));
        int min = Math.min(r, Math.min(g, b));
        int chroma = max - min;

        // 1. Ignorar suelo gris neutro o fondos desaturados
        if (chroma < 18) {
            return false;
        }

        // 2. Ignorar blancos puros
        if (min > 235) {
            return false;
        }

        // 3. Ignorar la cara lateral derecha oscura del bloque (ej. R=108, G=73, B=138)
        if (max < 142 && r < 130) {
            return false;
        }

        // 4. Comparar contra el color de fondo del cielo muestreado en los bordes de la misma fila Y
        int diffL = Math.abs(r - bgLR) + Math.abs(g - bgLG) + Math.abs(b - bgLB);
        int diffR = Math.abs(r - bgRR) + Math.abs(g - bgRG) + Math.abs(b - bgRB);
        int minDiff = Math.min(diffL, diffR);

        return minDiff >= threshold || chroma >= 36;
    }

    private void detectTapToPlayButtonSafe(
            ByteBuffer buffer,
            int bufferLimit,
            int width,
            int height,
            int rowStride,
            int pixelStride,
            ScanResult outResult) {

        try {
            int btnY = Math.round(TapAccessibilityService.getTapYNorm() * height);
            int rowOffset = btnY * rowStride;
            int centerX = Math.round(TapAccessibilityService.getTapXNorm() * width);
            if (rowOffset < 0 || rowOffset + ((centerX + 40) * pixelStride) + 3 >= bufferLimit) {
                return;
            }

            int purpleCount = 0;
            for (int dx = -40; dx <= 40; dx += 10) {
                int idx = rowOffset + ((centerX + dx) * pixelStride);
                int r = buffer.get(idx) & 0xFF;
                int g = buffer.get(idx + 1) & 0xFF;
                int b = buffer.get(idx + 2) & 0xFF;
                if (b > 140 && r > 90 && g < 110 && (b - g) > 45) {
                    purpleCount++;
                }
            }
            if (purpleCount >= 6) {
                outResult.tapToPlayButtonDetected = true;
                outResult.tapToPlayCenterX = centerX;
                outResult.tapToPlayCenterY = btnY;
            }
        } catch (Throwable ignored) {
        }
    }

    private static float[] scanSingleRowEdges(
            ByteBuffer buffer,
            int bufferLimit,
            int rowStride,
            int pixelStride,
            int y,
            int startX,
            int endX,
            int skyLeftX,
            int skyRightX) {

        for (int dy : new int[]{0, -3, 3, -1, 1, -2, 2}) {
            int sampleY = y + dy;
            int rowOffset = sampleY * rowStride;
            if (rowOffset < 0 || rowOffset + (skyRightX * pixelStride) + 3 >= bufferLimit) {
                continue;
            }

            int bgLIdx = rowOffset + (skyLeftX * pixelStride);
            int bgRIdx = rowOffset + (skyRightX * pixelStride);
            int bgLR = buffer.get(bgLIdx) & 0xFF;
            int bgLG = buffer.get(bgLIdx + 1) & 0xFF;
            int bgLB = buffer.get(bgLIdx + 2) & 0xFF;

            int bgRR = buffer.get(bgRIdx) & 0xFF;
            int bgRG = buffer.get(bgRIdx + 1) & 0xFF;
            int bgRB = buffer.get(bgRIdx + 2) & 0xFF;

            int foundLeft = -1;
            int runLeft = 0;
            for (int x = startX; x <= endX; x += 2) {
                int idx = rowOffset + (x * pixelStride);
                int r = buffer.get(idx) & 0xFF;
                int g = buffer.get(idx + 1) & 0xFF;
                int b = buffer.get(idx + 2) & 0xFF;
                if (isIlluminatedTopFacePixel(r, g, b, bgLR, bgLG, bgLB, bgRR, bgRG, bgRB, DEFAULT_BG_DIFF_THRESHOLD)) {
                    runLeft += 2;
                    if (runLeft >= 8) {
                        foundLeft = x - runLeft + 2;
                        break;
                    }
                } else {
                    runLeft = 0;
                }
            }
            if (foundLeft < 0) {
                continue;
            }

            int foundRight = -1;
            int runRight = 0;
            for (int x = endX; x >= foundLeft; x -= 2) {
                int idx = rowOffset + (x * pixelStride);
                int r = buffer.get(idx) & 0xFF;
                int g = buffer.get(idx + 1) & 0xFF;
                int b = buffer.get(idx + 2) & 0xFF;
                if (isIlluminatedTopFacePixel(r, g, b, bgLR, bgLG, bgLB, bgRR, bgRG, bgRB, DEFAULT_BG_DIFF_THRESHOLD)) {
                    runRight += 2;
                    if (runRight >= 8) {
                        foundRight = x + runRight - 2;
                        break;
                    }
                } else {
                    runRight = 0;
                }
            }
            if (foundRight > foundLeft) {
                return new float[]{foundLeft, foundRight};
            }
        }
        return null;
    }

    private static float clamp(float val, float min, float max) {
        return Math.max(min, Math.min(max, val));
    }

    private static int clampInt(int val, int min, int max) {
        return Math.max(min, Math.min(max, val));
    }
}
