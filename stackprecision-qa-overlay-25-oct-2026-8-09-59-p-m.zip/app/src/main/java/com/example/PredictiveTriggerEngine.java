package com.example;

import android.os.SystemClock;
import java.util.Arrays;
import java.util.concurrent.locks.LockSupport;

/**
 * Predictor Cinemático Milimétrico por Cruce de Borde Delantero (Leading-Edge Match):
 * 1. Cuando la nueva losa viene desde la IZQUIERDA hacia la derecha (vx > 0):
 *    - Su borde delantero derecho (movingRightEdgeX) SIEMPRE está 100% visible dentro de la pantalla.
 *    - Calcula predictedRightX = movingRightEdgeX + (vx * LEAD_TIME_MS) + CENTER_OFFSET_PX y dispara
 *      en el microsegundo exacto en que predictedRightX >= baseRightEdgeX (usando LockSupport.parkNanos
 *      si faltan menos de 14ms).
 * 2. Cuando la nueva losa viene desde la DERECHA hacia la izquierda (vx < 0):
 *    - Su borde delantero izquierdo (movingLeftEdgeX) SIEMPRE está 100% visible dentro de la pantalla.
 *    - Calcula predictedLeftX = movingLeftEdgeX + (vx * LEAD_TIME_MS) + CENTER_OFFSET_PX y dispara
 *      en el microsegundo exacto en que predictedLeftX <= baseLeftEdgeX (usando LockSupport.parkNanos
 *      si faltan menos de 14ms).
 * 3. Filtro de mediana de velocidad sobre 3 frames y enfriamiento de 280ms tras cada disparo.
 */
public final class PredictiveTriggerEngine {

    public static final float DEFAULT_LEAD_TIME_MS = 22.0f;
    public static final float DEFAULT_CENTER_OFFSET_PX = 0.0f;
    public static final float DEFAULT_TOLERANCE_PX = 2.0f;
    public static final long DEFAULT_COOLDOWN_MS = 280L;

    public static final float MIN_VALID_VELOCITY_PX_PER_MS = 0.15f;
    public static final float MAX_VALID_VELOCITY_PX_PER_MS = 3.80f;

    private static final int HISTORY_CAPACITY = 3;
    private static final float MAX_FRAME_GAP_MS = 110.0f;
    private static final float SUB_FRAME_MAX_WAIT_MS = 14.0f;

    private final long[] historyTimestampNs = new long[HISTORY_CAPACITY];
    private final float[] historyLeftEdgeX = new float[HISTORY_CAPACITY];
    private final float[] historyRightEdgeX = new float[HISTORY_CAPACITY];
    private final float[] historyCenterX = new float[HISTORY_CAPACITY];
    private final float[] velocityScratch = new float[HISTORY_CAPACITY];
    private int historyCount = 0;

    private int consecutiveSameDirectionCount = 0;
    private float lastObservedDirectionSign = 0.0f;

    private volatile float leadTimeMs = DEFAULT_LEAD_TIME_MS;
    private volatile float centerOffsetPx = DEFAULT_CENTER_OFFSET_PX;
    private volatile float tolerancePx = DEFAULT_TOLERANCE_PX;
    private volatile long cooldownMs = DEFAULT_COOLDOWN_MS;
    private volatile boolean waitAndSnapEnabled = true;

    private float lastPredictedLeadingEdgeX = -1.0f;
    private float currentVelocityPxPerMs = 0.0f;
    private long lastTriggerUptimeMs = -10_000L;
    private int totalShotsFired = 0;

    private final PredictionDecision reusableDecision = new PredictionDecision();

    public enum TriggerState {
        COOLDOWN,
        SEARCHING,
        TRACKING,
        WAIT_AND_SNAP_FIRED,
        IMMEDIATE_FIRED
    }

    public static final class PredictionDecision {
        public TriggerState state = TriggerState.SEARCHING;
        public boolean shouldFire = false;
        public long subFrameWaitNanos = 0L;
        public float velocityPxPerMs = 0.0f;

        // Valores de centro y borde delantero activo
        public float predictedX = 0.0f;
        public float targetCenterX = 0.0f;
        public float centerErrorPx = 0.0f;

        // Telemetría específica de Borde Delantero (Leading Edge)
        public boolean trackingRightLeadingEdge = true;
        public float activeLeadingEdgeX = 0.0f;
        public float predictedLeadingEdgeX = 0.0f;
        public float targetLeadingEdgeX = 0.0f;
        public float leadingEdgeErrorPx = 0.0f;
        public float timeToImpactMs = -1.0f;
    }

    public PredictiveTriggerEngine() {
    }

    public void setLeadTimeMs(float leadTimeMs) {
        this.leadTimeMs = clamp(leadTimeMs, 0.0f, 80.0f);
    }

    public float getLeadTimeMs() {
        return leadTimeMs;
    }

    public void adjustLeadTimeMs(float deltaMs) {
        setLeadTimeMs(this.leadTimeMs + deltaMs);
    }

    public void setCenterOffsetPx(float offsetPx) {
        this.centerOffsetPx = clamp(offsetPx, -40.0f, 40.0f);
    }

    public float getCenterOffsetPx() {
        return centerOffsetPx;
    }

    public void adjustCenterOffsetPx(float deltaPx) {
        setCenterOffsetPx(this.centerOffsetPx + deltaPx);
    }

    public void setTolerancePx(float tolerancePx) {
        this.tolerancePx = clamp(tolerancePx, 1.0f, 24.0f);
    }

    public float getTolerancePx() {
        return tolerancePx;
    }

    public void setCooldownMs(long cooldownMs) {
        this.cooldownMs = Math.max(120L, Math.min(1200L, cooldownMs));
    }

    public long getCooldownMs() {
        return cooldownMs;
    }

    public void setWaitAndSnapEnabled(boolean enabled) {
        this.waitAndSnapEnabled = enabled;
    }

    public boolean isWaitAndSnapEnabled() {
        return waitAndSnapEnabled;
    }

    public int getTotalShotsFired() {
        return totalShotsFired;
    }

    public void resetHistory() {
        historyCount = 0;
        lastPredictedLeadingEdgeX = -1.0f;
        currentVelocityPxPerMs = 0.0f;
        consecutiveSameDirectionCount = 0;
        lastObservedDirectionSign = 0.0f;
    }

    public void resetStats() {
        resetHistory();
        totalShotsFired = 0;
        lastTriggerUptimeMs = -10_000L;
    }

    /**
     * Sobrecarga directa para ScanResult completo que aplica el detector de Borde Delantero
     * (movingRightEdgeX -> baseRightEdgeX cuando vx > 0; movingLeftEdgeX -> baseLeftEdgeX cuando vx < 0).
     */
    public PredictionDecision evaluateScanResult(
            IsometricStackTracker.ScanResult scan,
            boolean autoStackEnabled) {
        if (scan == null || !scan.validFrame) {
            resetHistory();
            reusableDecision.shouldFire = false;
            reusableDecision.state = TriggerState.SEARCHING;
            return reusableDecision;
        }
        return evaluateLeadingEdgeFrame(
                scan.movingDetected,
                scan.movingLeftEdgeX,
                scan.movingRightEdgeX,
                scan.movingCenterX,
                scan.effectiveTargetLeftEdgeX,
                scan.effectiveTargetRightEdgeX,
                scan.effectiveTargetCenterX,
                scan.timestampNs,
                autoStackEnabled);
    }

    /**
     * Sobrecarga compatible de 5 argumentos para evaluación basada en una sola coordenada X
     * (cuando leftEdge == rightEdge == centerX, la matemática de borde delantero equivale al cruce central).
     */
    public PredictionDecision evaluateFrame(
            boolean movingDetected,
            float movingCenterX,
            float baseCenterX,
            long frameTimestampNs,
            boolean autoStackEnabled) {
        return evaluateLeadingEdgeFrame(
                movingDetected,
                movingCenterX,
                movingCenterX,
                movingCenterX,
                baseCenterX,
                baseCenterX,
                baseCenterX,
                frameTimestampNs,
                autoStackEnabled);
    }

    /**
     * Algoritmo Milimétrico de Cruce de Borde Delantero (Leading-Edge Match):
     * - Si viene por la IZQUIERDA (vx > 0): rastrea movingRightEdgeX hacia baseRightEdgeX.
     *   predictedRightX = movingRightEdgeX + (vx * LEAD_TIME_MS) + CENTER_OFFSET_PX
     *   Dispara cuando predictedRightX >= baseRightEdgeX (o con parkNanos si faltan < 14ms).
     * - Si viene por la DERECHA (vx < 0): rastrea movingLeftEdgeX hacia baseLeftEdgeX.
     *   predictedLeftX = movingLeftEdgeX + (vx * LEAD_TIME_MS) + CENTER_OFFSET_PX
     *   Dispara cuando predictedLeftX <= baseLeftEdgeX (o con parkNanos si faltan < 14ms).
     */
    public PredictionDecision evaluateLeadingEdgeFrame(
            boolean movingDetected,
            float movingLeftEdgeX,
            float movingRightEdgeX,
            float movingCenterX,
            float baseLeftEdgeX,
            float baseRightEdgeX,
            float baseCenterX,
            long frameTimestampNs,
            boolean autoStackEnabled) {

        try {
            reusableDecision.shouldFire = false;
            reusableDecision.subFrameWaitNanos = 0L;
            reusableDecision.targetCenterX = baseCenterX;
            reusableDecision.centerErrorPx = movingCenterX - baseCenterX;
            reusableDecision.timeToImpactMs = -1.0f;

            long nowUptimeMs = SystemClock.uptimeMillis();
            if (nowUptimeMs - lastTriggerUptimeMs < cooldownMs) {
                reusableDecision.state = TriggerState.COOLDOWN;
                reusableDecision.velocityPxPerMs = 0.0f;
                reusableDecision.predictedX = baseCenterX;
                reusableDecision.predictedLeadingEdgeX = baseCenterX;
                return reusableDecision;
            }

            if (!movingDetected || (movingRightEdgeX <= 0.0f && movingLeftEdgeX <= 0.0f)) {
                resetHistory();
                reusableDecision.state = TriggerState.SEARCHING;
                reusableDecision.velocityPxPerMs = 0.0f;
                reusableDecision.predictedX = baseCenterX;
                reusableDecision.predictedLeadingEdgeX = baseCenterX;
                return reusableDecision;
            }

            if (historyCount > 0) {
                long prevTimeNs = historyTimestampNs[historyCount - 1];
                float deltaMs = (frameTimestampNs - prevTimeNs) / 1_000_000.0f;
                if (deltaMs <= 0.1f || deltaMs > MAX_FRAME_GAP_MS) {
                    resetHistory();
                } else {
                    float jumpLeft = Math.abs(movingLeftEdgeX - historyLeftEdgeX[historyCount - 1]);
                    float jumpRight = Math.abs(movingRightEdgeX - historyRightEdgeX[historyCount - 1]);
                    if (Math.min(jumpLeft, jumpRight) > 220.0f) {
                        resetHistory();
                    }
                }
            }

            if (historyCount < HISTORY_CAPACITY) {
                historyTimestampNs[historyCount] = frameTimestampNs;
                historyLeftEdgeX[historyCount] = movingLeftEdgeX;
                historyRightEdgeX[historyCount] = movingRightEdgeX;
                historyCenterX[historyCount] = movingCenterX;
                historyCount++;
            } else {
                historyTimestampNs[0] = historyTimestampNs[1];
                historyLeftEdgeX[0] = historyLeftEdgeX[1];
                historyRightEdgeX[0] = historyRightEdgeX[1];
                historyCenterX[0] = historyCenterX[1];

                historyTimestampNs[1] = historyTimestampNs[2];
                historyLeftEdgeX[1] = historyLeftEdgeX[2];
                historyRightEdgeX[1] = historyRightEdgeX[2];
                historyCenterX[1] = historyCenterX[2];

                historyTimestampNs[2] = frameTimestampNs;
                historyLeftEdgeX[2] = movingLeftEdgeX;
                historyRightEdgeX[2] = movingRightEdgeX;
                historyCenterX[2] = movingCenterX;
            }

            if (historyCount < 2) {
                reusableDecision.state = TriggerState.TRACKING;
                reusableDecision.velocityPxPerMs = 0.0f;
                reusableDecision.predictedX = movingCenterX + centerOffsetPx;
                reusableDecision.predictedLeadingEdgeX = movingRightEdgeX + centerOffsetPx;
                lastPredictedLeadingEdgeX = -1.0f;
                return reusableDecision;
            }

            // Calcular velocidades de ambos bordes con filtro de mediana
            float vxRight = computeFilteredEdgeVelocity(historyRightEdgeX);
            float vxLeft = computeFilteredEdgeVelocity(historyLeftEdgeX);
            float vxCenter = computeFilteredEdgeVelocity(historyCenterX);

            // Determinar dirección real y seleccionar el Borde Delantero 100% visible:
            // - Si la pieza entra desde la IZQUIERDA (vxRight > 0), su borde derecho se mueve hacia la derecha
            //   incluso cuando su borde izquierdo sigue pegado al borde de la pantalla (vxLeft ~ 0).
            // - Si la pieza entra desde la DERECHA (vxLeft < 0), su borde izquierdo se mueve hacia la izquierda
            //   incluso cuando su borde derecho sigue pegado al borde derecho de la pantalla (vxRight ~ 0).
            float vx;
            boolean comingFromLeft;
            if (vxRight >= MIN_VALID_VELOCITY_PX_PER_MS && vxRight >= Math.abs(vxLeft) - 0.04f) {
                comingFromLeft = true;
                vx = vxRight;
            } else if (vxLeft <= -MIN_VALID_VELOCITY_PX_PER_MS && Math.abs(vxLeft) >= vxRight - 0.04f) {
                comingFromLeft = false;
                vx = vxLeft;
            } else {
                comingFromLeft = (vxCenter >= 0.0f);
                vx = vxCenter;
            }

            this.currentVelocityPxPerMs = vx;
            float absVx = Math.abs(vx);

            // Seleccionar borde delantero activo y borde objetivo de la base
            float activeLeadingEdgeX = comingFromLeft ? movingRightEdgeX : movingLeftEdgeX;
            float targetLeadingEdgeX = comingFromLeft ? baseRightEdgeX : baseLeftEdgeX;
            float predictedLeadingEdgeX = activeLeadingEdgeX + (vx * leadTimeMs) + centerOffsetPx;
            float predictedCenterX = movingCenterX + (vx * leadTimeMs) + centerOffsetPx;

            reusableDecision.velocityPxPerMs = vx;
            reusableDecision.predictedX = predictedCenterX;
            reusableDecision.trackingRightLeadingEdge = comingFromLeft;
            reusableDecision.activeLeadingEdgeX = activeLeadingEdgeX;
            reusableDecision.predictedLeadingEdgeX = predictedLeadingEdgeX;
            reusableDecision.targetLeadingEdgeX = targetLeadingEdgeX;
            reusableDecision.leadingEdgeErrorPx = activeLeadingEdgeX - targetLeadingEdgeX;
            reusableDecision.state = TriggerState.TRACKING;

            // Validar dirección consistente
            float currentSign = Math.signum(vx);
            if (absVx >= MIN_VALID_VELOCITY_PX_PER_MS && currentSign == lastObservedDirectionSign) {
                consecutiveSameDirectionCount++;
            } else if (absVx >= MIN_VALID_VELOCITY_PX_PER_MS) {
                consecutiveSameDirectionCount = 1;
                lastObservedDirectionSign = currentSign;
            } else {
                consecutiveSameDirectionCount = 0;
            }

            boolean validDirectionConfidence = (consecutiveSameDirectionCount >= 2);
            if (!autoStackEnabled
                    || absVx < MIN_VALID_VELOCITY_PX_PER_MS
                    || absVx > MAX_VALID_VELOCITY_PX_PER_MS
                    || !validDirectionConfidence) {
                lastPredictedLeadingEdgeX = predictedLeadingEdgeX;
                return reusableDecision;
            }

            float impactTolerancePx = Math.max(tolerancePx, Math.min(16.0f, absVx * 12.0f));

            // 1. Losa viniendo por la IZQUIERDA (vx > 0):
            //    Rastrea movingRightEdgeX y dispara en el microsegundo en que predictedRightX >= baseRightEdgeX
            if (comingFromLeft && vx > MIN_VALID_VELOCITY_PX_PER_MS) {
                float distanceToTargetRightPx = (baseRightEdgeX - centerOffsetPx) - movingRightEdgeX;
                // Solo disparar cuando el borde delantero derecho está llegando a baseRightEdgeX
                if (movingRightEdgeX <= (baseRightEdgeX - centerOffsetPx + 18.0f)
                        && distanceToTargetRightPx <= 160.0f) {

                    // Disparo inmediato si predictedRightX >= baseRightEdgeX
                    if (predictedLeadingEdgeX >= (baseRightEdgeX - impactTolerancePx)
                            && (lastPredictedLeadingEdgeX < 0.0f || lastPredictedLeadingEdgeX <= baseRightEdgeX + 28.0f)) {
                        markTriggered(nowUptimeMs);
                        reusableDecision.shouldFire = true;
                        reusableDecision.subFrameWaitNanos = 0L;
                        reusableDecision.timeToImpactMs = 0.0f;
                        reusableDecision.state = TriggerState.IMMEDIATE_FIRED;
                        return reusableDecision;
                    }

                    // Espera sub-fotograma con LockSupport.parkNanos si faltan menos de 14ms
                    float timeToImpactMs = (distanceToTargetRightPx / vx) - leadTimeMs;
                    reusableDecision.timeToImpactMs = timeToImpactMs;
                    if (waitAndSnapEnabled && timeToImpactMs > 0.0f && timeToImpactMs <= SUB_FRAME_MAX_WAIT_MS) {
                        long waitNanos = (long) (timeToImpactMs * 1_000_000.0f);
                        markTriggered(nowUptimeMs + Math.round(timeToImpactMs));
                        reusableDecision.shouldFire = true;
                        reusableDecision.subFrameWaitNanos = waitNanos;
                        reusableDecision.state = TriggerState.WAIT_AND_SNAP_FIRED;
                        return reusableDecision;
                    }
                }
            }
            // 2. Losa viniendo por la DERECHA (vx < 0):
            //    Rastrea movingLeftEdgeX y dispara en el microsegundo en que predictedLeftX <= baseLeftEdgeX
            else if (!comingFromLeft && vx < -MIN_VALID_VELOCITY_PX_PER_MS) {
                float distanceToTargetLeftPx = (baseLeftEdgeX - centerOffsetPx) - movingLeftEdgeX;
                // distanceToTargetLeftPx es negativo o ~0 cuando movingLeftEdgeX se acerca desde la derecha
                if (movingLeftEdgeX >= (baseLeftEdgeX - centerOffsetPx - 18.0f)
                        && Math.abs(distanceToTargetLeftPx) <= 160.0f) {

                    // Disparo inmediato si predictedLeftX <= baseLeftEdgeX
                    if (predictedLeadingEdgeX <= (baseLeftEdgeX + impactTolerancePx)
                            && (lastPredictedLeadingEdgeX < 0.0f || lastPredictedLeadingEdgeX >= baseLeftEdgeX - 28.0f)) {
                        markTriggered(nowUptimeMs);
                        reusableDecision.shouldFire = true;
                        reusableDecision.subFrameWaitNanos = 0L;
                        reusableDecision.timeToImpactMs = 0.0f;
                        reusableDecision.state = TriggerState.IMMEDIATE_FIRED;
                        return reusableDecision;
                    }

                    // Espera sub-fotograma con LockSupport.parkNanos si faltan menos de 14ms
                    float timeToImpactMs = (distanceToTargetLeftPx / vx) - leadTimeMs;
                    reusableDecision.timeToImpactMs = timeToImpactMs;
                    if (waitAndSnapEnabled && timeToImpactMs > 0.0f && timeToImpactMs <= SUB_FRAME_MAX_WAIT_MS) {
                        long waitNanos = (long) (timeToImpactMs * 1_000_000.0f);
                        markTriggered(nowUptimeMs + Math.round(timeToImpactMs));
                        reusableDecision.shouldFire = true;
                        reusableDecision.subFrameWaitNanos = waitNanos;
                        reusableDecision.state = TriggerState.WAIT_AND_SNAP_FIRED;
                        return reusableDecision;
                    }
                }
            }

            lastPredictedLeadingEdgeX = predictedLeadingEdgeX;
            return reusableDecision;
        } catch (Throwable t) {
            reusableDecision.shouldFire = false;
            return reusableDecision;
        }
    }

    private float computeFilteredEdgeVelocity(float[] edgeHistory) {
        if (historyCount < 2) {
            return 0.0f;
        }
        int last = historyCount - 1;
        float dtLast = (historyTimestampNs[last] - historyTimestampNs[last - 1]) / 1_000_000.0f;
        float vLast = (dtLast > 0.1f) ? (edgeHistory[last] - edgeHistory[last - 1]) / dtLast : 0.0f;

        if (historyCount < 3) {
            return vLast;
        }

        float dt1 = (historyTimestampNs[1] - historyTimestampNs[0]) / 1_000_000.0f;
        float dtTotal = (historyTimestampNs[2] - historyTimestampNs[0]) / 1_000_000.0f;
        float v1 = (dt1 > 0.1f) ? (edgeHistory[1] - edgeHistory[0]) / dt1 : vLast;
        float vAvg = (dtTotal > 0.2f) ? (edgeHistory[2] - edgeHistory[0]) / dtTotal : vLast;

        velocityScratch[0] = v1;
        velocityScratch[1] = vLast;
        velocityScratch[2] = vAvg;
        Arrays.sort(velocityScratch);
        return velocityScratch[1];
    }

    /**
     * Espera de alta precisión sub-fotograma (< 14ms) combinando LockSupport.parkNanos
     * con spin-wait en los últimos 150 microsegundos.
     */
    public static void executeSubFrameSleepIfNeeded(long waitNanos) {
        if (waitNanos <= 0L) {
            return;
        }
        try {
            long clampedNanos = Math.min(waitNanos, 14_000_000L);
            long deadlineNs = System.nanoTime() + clampedNanos;
            if (clampedNanos > 250_000L) {
                LockSupport.parkNanos(clampedNanos - 150_000L);
            }
            while (System.nanoTime() < deadlineNs) {
                Thread.onSpinWait();
            }
        } catch (Throwable ignored) {
        }
    }

    private void markTriggered(long triggerUptimeMs) {
        this.lastTriggerUptimeMs = triggerUptimeMs;
        this.totalShotsFired++;
        resetHistory();
    }

    public float getCurrentVelocityPxPerMs() {
        return currentVelocityPxPerMs;
    }

    private static float clamp(float val, float min, float max) {
        return Math.max(min, Math.min(max, val));
    }
}
