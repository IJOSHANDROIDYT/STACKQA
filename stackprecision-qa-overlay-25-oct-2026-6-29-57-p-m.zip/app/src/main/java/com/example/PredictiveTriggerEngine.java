package com.example;

import android.os.SystemClock;
import java.util.concurrent.locks.LockSupport;

/**
 * Predictor Cinemático de Disparo con Modo "Auto-Base" Inteligente por Defecto.
 * - Mantiene el historial de los últimos 4 fotogramas (timestampNs, movingCenterX).
 * - Exige velocidad horizontal válida: 0.15f <= Math.abs(velocityPxPerMs) <= 3.50f
 *   para evitar disparos falsos en menús, texto estático o zoom de cámara.
 * - Dispara cuando predictedCenterX coincide con baseCenterX (o mediante espera Sub-Frame
 *   "Wait & Snap" con LockSupport.parkNanos).
 */
public final class PredictiveTriggerEngine {

    public static final float DEFAULT_LEAD_TIME_MS = 24.0f;
    public static final float DEFAULT_CENTER_OFFSET_PX = 0.0f;
    public static final float DEFAULT_TOLERANCE_PX = 6.0f;
    public static final long DEFAULT_COOLDOWN_MS = 320L;

    // Rango estricto de velocidad real permitido para disparar (evita disparos falsos en menú o zoom)
    public static final float MIN_VALID_VELOCITY_PX_PER_MS = 0.15f;
    public static final float MAX_VALID_VELOCITY_PX_PER_MS = 3.50f;

    private static final int HISTORY_CAPACITY = 4;
    private static final float MAX_FRAME_GAP_MS = 110.0f;
    private static final float SUB_FRAME_MAX_WAIT_MS = 14.0f;

    private final long[] historyTimestampNs = new long[HISTORY_CAPACITY];
    private final float[] historyCenterX = new float[HISTORY_CAPACITY];
    private int historyCount = 0;

    private volatile float leadTimeMs = DEFAULT_LEAD_TIME_MS;
    private volatile float centerOffsetPx = DEFAULT_CENTER_OFFSET_PX;
    private volatile float tolerancePx = DEFAULT_TOLERANCE_PX;
    private volatile long cooldownMs = DEFAULT_COOLDOWN_MS;
    private volatile boolean waitAndSnapEnabled = true;

    private float lastPredictedX = -1.0f;
    private float currentVelocityPxPerMs = 0.0f;
    private long lastTriggerUptimeMs = -10_000L;
    private int totalShotsFired = 0;

    private final PredictionDecision reusableDecision = new PredictionDecision();

    public enum TriggerState {
        COOLDOWN,
        SEARCHING,
        TRACKING,
        WAIT_AND_SNAP_FIRED,
        IMMEDIATE_FIRED
    }

    public static final class PredictionDecision {
        public TriggerState state = TriggerState.SEARCHING;
        public boolean shouldFire = false;
        public long subFrameWaitNanos = 0L;
        public float velocityPxPerMs = 0.0f;
        public float predictedX = 0.0f;
        public float targetCenterX = 0.0f;
        public float timeToImpactMs = -1.0f;
    }

    public PredictiveTriggerEngine() {
    }

    public void setLeadTimeMs(float leadTimeMs) {
        this.leadTimeMs = clamp(leadTimeMs, 0.0f, 80.0f);
    }

    public float getLeadTimeMs() {
        return leadTimeMs;
    }

    public void adjustLeadTimeMs(float deltaMs) {
        setLeadTimeMs(this.leadTimeMs + deltaMs);
    }

    public void setCenterOffsetPx(float offsetPx) {
        this.centerOffsetPx = clamp(offsetPx, -40.0f, 40.0f);
    }

    public float getCenterOffsetPx() {
        return centerOffsetPx;
    }

    public void adjustCenterOffsetPx(float deltaPx) {
        setCenterOffsetPx(this.centerOffsetPx + deltaPx);
    }

    public void setTolerancePx(float tolerancePx) {
        this.tolerancePx = clamp(tolerancePx, 1.5f, 24.0f);
    }

    public float getTolerancePx() {
        return tolerancePx;
    }

    public void setCooldownMs(long cooldownMs) {
        this.cooldownMs = Math.max(120L, Math.min(1200L, cooldownMs));
    }

    public long getCooldownMs() {
        return cooldownMs;
    }

    public void setWaitAndSnapEnabled(boolean enabled) {
        this.waitAndSnapEnabled = enabled;
    }

    public boolean isWaitAndSnapEnabled() {
        return waitAndSnapEnabled;
    }

    public int getTotalShotsFired() {
        return totalShotsFired;
    }

    public void resetHistory() {
        historyCount = 0;
        lastPredictedX = -1.0f;
        currentVelocityPxPerMs = 0.0f;
    }

    public void resetStats() {
        resetHistory();
        totalShotsFired = 0;
        lastTriggerUptimeMs = -10_000L;
    }

    /**
     * Evalúa el fotograma actual comparando la posición predicha de la losa móvil (en 0.545f)
     * con el centro del bloque base en 0.590f (targetCenterX = baseCenterX).
     * Solo habilita el disparo cuando 0.15f <= Math.abs(velocityPxPerMs) <= 3.50f.
     */
    public PredictionDecision evaluateFrame(
            boolean movingDetected,
            float movingCenterX,
            float targetCenterX,
            long frameTimestampNs,
            boolean autoStackEnabled) {

        reusableDecision.shouldFire = false;
        reusableDecision.subFrameWaitNanos = 0L;
        reusableDecision.targetCenterX = targetCenterX;
        reusableDecision.timeToImpactMs = -1.0f;

        long nowUptimeMs = SystemClock.uptimeMillis();
        if (nowUptimeMs - lastTriggerUptimeMs < cooldownMs) {
            reusableDecision.state = TriggerState.COOLDOWN;
            reusableDecision.velocityPxPerMs = 0.0f;
            reusableDecision.predictedX = targetCenterX;
            return reusableDecision;
        }

        if (!movingDetected || movingCenterX <= 0.0f) {
            resetHistory();
            reusableDecision.state = TriggerState.SEARCHING;
            reusableDecision.velocityPxPerMs = 0.0f;
            reusableDecision.predictedX = targetCenterX;
            return reusableDecision;
        }

        if (historyCount > 0) {
            long prevTimeNs = historyTimestampNs[historyCount - 1];
            float deltaMs = (frameTimestampNs - prevTimeNs) / 1_000_000.0f;
            if (deltaMs <= 0.1f || deltaMs > MAX_FRAME_GAP_MS) {
                resetHistory();
            } else {
                float jumpPx = Math.abs(movingCenterX - historyCenterX[historyCount - 1]);
                if (jumpPx > 200.0f) {
                    resetHistory();
                }
            }
        }

        if (historyCount < HISTORY_CAPACITY) {
            historyTimestampNs[historyCount] = frameTimestampNs;
            historyCenterX[historyCount] = movingCenterX;
            historyCount++;
        } else {
            for (int i = 1; i < HISTORY_CAPACITY; i++) {
                historyTimestampNs[i - 1] = historyTimestampNs[i];
                historyCenterX[i - 1] = historyCenterX[i];
            }
            historyTimestampNs[HISTORY_CAPACITY - 1] = frameTimestampNs;
            historyCenterX[HISTORY_CAPACITY - 1] = movingCenterX;
        }

        if (historyCount < 2) {
            reusableDecision.state = TriggerState.TRACKING;
            reusableDecision.velocityPxPerMs = 0.0f;
            reusableDecision.predictedX = movingCenterX + centerOffsetPx;
            lastPredictedX = reusableDecision.predictedX;
            return reusableDecision;
        }

        int lastIdx = historyCount - 1;
        float immediateDtMs = (historyTimestampNs[lastIdx] - historyTimestampNs[lastIdx - 1]) / 1_000_000.0f;
        float immediateVel = (immediateDtMs > 0.1f)
                ? ((historyCenterX[lastIdx] - historyCenterX[lastIdx - 1]) / immediateDtMs)
                : 0.0f;

        float spanDtMs = (historyTimestampNs[lastIdx] - historyTimestampNs[0]) / 1_000_000.0f;
        float spanVel = (spanDtMs > 0.2f)
                ? ((historyCenterX[lastIdx] - historyCenterX[0]) / spanDtMs)
                : immediateVel;

        float velocityPxPerMs = (spanVel * 0.65f) + (immediateVel * 0.35f);
        this.currentVelocityPxPerMs = velocityPxPerMs;

        float absVel = Math.abs(velocityPxPerMs);
        float predictedCenterX = movingCenterX + (velocityPxPerMs * leadTimeMs) + centerOffsetPx;

        reusableDecision.velocityPxPerMs = velocityPxPerMs;
        reusableDecision.predictedX = predictedCenterX;
        reusableDecision.state = TriggerState.TRACKING;

        // Filtro estricto de velocidad: 0.15f <= |velocityPxPerMs| <= 3.50f
        if (!autoStackEnabled
                || absVel < MIN_VALID_VELOCITY_PX_PER_MS
                || absVel > MAX_VALID_VELOCITY_PX_PER_MS) {
            lastPredictedX = predictedCenterX;
            return reusableDecision;
        }

        // Centro objetivo de la base (con ajuste fino de CENTER_OFFSET_PX)
        float adjustedBaseCenterX = targetCenterX - centerOffsetPx;
        float distanceToBaseCenterPx = adjustedBaseCenterX - movingCenterX;

        // Verificar que el bloque realmente se está acercando hacia baseCenterX
        boolean approachingFromLeft = (velocityPxPerMs > 0.0f && movingCenterX <= adjustedBaseCenterX + tolerancePx);
        boolean approachingFromRight = (velocityPxPerMs < 0.0f && movingCenterX >= adjustedBaseCenterX - tolerancePx);

        if (!approachingFromLeft && !approachingFromRight) {
            lastPredictedX = predictedCenterX;
            return reusableDecision;
        }

        // 1. Condición de Disparo Milimétrico Inmediato cuando predictedCenterX coincide o cruza baseCenterX
        boolean withinTolerance = Math.abs(predictedCenterX - targetCenterX) <= tolerancePx;
        boolean crossedBaseCenter = false;
        if (lastPredictedX > 0.0f) {
            if (velocityPxPerMs > 0.0f && lastPredictedX < targetCenterX && predictedCenterX >= targetCenterX) {
                crossedBaseCenter = true;
            } else if (velocityPxPerMs < 0.0f && lastPredictedX > targetCenterX && predictedCenterX <= targetCenterX) {
                crossedBaseCenter = true;
            }
        }

        if (withinTolerance || crossedBaseCenter) {
            markTriggered(nowUptimeMs);
            reusableDecision.shouldFire = true;
            reusableDecision.subFrameWaitNanos = 0L;
            reusableDecision.timeToImpactMs = 0.0f;
            reusableDecision.state = TriggerState.IMMEDIATE_FIRED;
            return reusableDecision;
        }

        // 2. Modo "Wait & Snap" (Sub-Frame Sleep con LockSupport.parkNanos)
        float timeToImpactMs = (distanceToBaseCenterPx / velocityPxPerMs) - leadTimeMs;
        reusableDecision.timeToImpactMs = timeToImpactMs;

        if (waitAndSnapEnabled && timeToImpactMs >= 0.5f && timeToImpactMs <= SUB_FRAME_MAX_WAIT_MS) {
            long waitNanos = (long) (timeToImpactMs * 1_000_000.0f);
            markTriggered(nowUptimeMs + Math.round(timeToImpactMs));
            reusableDecision.shouldFire = true;
            reusableDecision.subFrameWaitNanos = waitNanos;
            reusableDecision.state = TriggerState.WAIT_AND_SNAP_FIRED;
            return reusableDecision;
        }

        lastPredictedX = predictedCenterX;
        return reusableDecision;
    }

    /**
     * Duerme el número exacto de nanosegundos restantes hasta la alineación perfecta.
     */
    public static void executeSubFrameSleepIfNeeded(long waitNanos) {
        if (waitNanos <= 0L) {
            return;
        }
        long clampedNanos = Math.min(waitNanos, 15_000_000L);
        long deadlineNs = System.nanoTime() + clampedNanos;
        if (clampedNanos > 250_000L) {
            LockSupport.parkNanos(clampedNanos - 150_000L);
        }
        while (System.nanoTime() < deadlineNs) {
            Thread.onSpinWait();
        }
    }

    private void markTriggered(long triggerUptimeMs) {
        this.lastTriggerUptimeMs = triggerUptimeMs;
        this.totalShotsFired++;
        resetHistory();
    }

    public float getCurrentVelocityPxPerMs() {
        return currentVelocityPxPerMs;
    }

    private static float clamp(float val, float min, float max) {
        return Math.max(min, Math.min(max, val));
    }
}
