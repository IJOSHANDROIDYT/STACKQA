package com.example;

import android.media.Image;
import java.nio.ByteBuffer;

/**
 * Motor de Visión por Computadora de Ultra-Baja Latencia (60 FPS).
 * Analiza directamente el ByteBuffer RGBA_8888 de Image.Plane en dos franjas horizontales
 * calibradas de fábrica (MOVING_Y = 0.545f y BASE_Y = 0.590f), aislando exclusivamente
 * la cara superior iluminada del bloque isométrico 3D e ignorando el suelo gris neutro
 * y las paredes laterales oscuras.
 */
public final class IsometricStackTracker {

    // Coordenadas por defecto de fábrica medidas exactamente sobre la torre real del juego
    public static final float DEFAULT_MOVING_Y_NORM = 0.545f;
    public static final float DEFAULT_BASE_Y_NORM = 0.590f;
    public static final float DEFAULT_FIXED_AXIS_X_NORM = 0.500f;

    // Alias de compatibilidad
    public static final float DEFAULT_MOVING_SCAN_Y_NORM = DEFAULT_MOVING_Y_NORM;
    public static final float DEFAULT_BASE_SCAN_Y_NORM = DEFAULT_BASE_Y_NORM;
    public static final float DEFAULT_TARGET_X_NORM = DEFAULT_FIXED_AXIS_X_NORM;

    // Límites de validación anti-inversión
    public static final float MIN_VALID_SCAN_Y_NORM = 0.48f;
    public static final float MAX_VALID_SCAN_Y_NORM = 0.66f;
    public static final float MIN_SCANLINE_SEPARATION_NORM = 0.02f;

    private static final float SCAN_START_X_NORM = 0.12f;
    private static final float SCAN_END_X_NORM = 0.88f;
    private static final float BG_SAMPLE_LEFT_X_NORM = 0.05f;
    private static final float BG_SAMPLE_RIGHT_X_NORM = 0.95f;

    // Criterios cromáticos para aislar la cara SUPERIOR iluminada del bloque (R≈181, G≈140, B≈190)
    // frente al suelo gris neutro (R≈180, G≈172, B≈180, croma < 16) y la pared derecha oscura (max < 138)
    private static final int MIN_TOP_FACE_CHROMA = 26;
    private static final int MIN_TOP_FACE_BRIGHTNESS = 135;
    private static final int MAX_SKY_MIN_CHANNEL = 198;

    private static final int MIN_CONSECUTIVE_EDGE_PX = 6;
    private static final int MIN_BLOCK_WIDTH_PX = 28;

    private int colorDiffThreshold = 26;

    private volatile float movingScanYNorm = DEFAULT_MOVING_Y_NORM;
    private volatile float baseScanYNorm = DEFAULT_BASE_Y_NORM;
    private volatile float manualTargetXNorm = DEFAULT_FIXED_AXIS_X_NORM;

    // Modo Auto-Base activo por defecto para adaptarse a recortes de bloques previos
    private volatile boolean autoBaseMode = true;
    private volatile boolean referenceLockActive = false;
    private volatile float lockedTargetCenterX = -1.0f;
    private volatile float smoothedBaseCenterX = -1.0f;
    private volatile float smoothedBaseLeftX = -1.0f;
    private volatile float smoothedBaseRightX = -1.0f;
    private volatile float lastKnownBaseWidth = -1.0f;
    private volatile boolean requestImmediateAutoCenter = false;

    // Resultado pre-asignado para cero recolecciones de basura (GC) a 60 FPS
    private final ScanResult reusableResult = new ScanResult();

    public static final class ScanResult {
        public boolean validFrame;
        public int frameWidth;
        public int frameHeight;
        public long timestampNs;
        public float processingTimeMs;

        public int baseScanY;
        public boolean baseDetected;
        public float baseLeftX;
        public float baseRightX;
        public float detectedBaseCenterX;
        public float baseWidth;

        public int movingScanY;
        public boolean movingDetected;
        public float movingLeftX;
        public float movingRightX;
        public float movingCenterX;
        public float movingWidth;

        // Diferencia de alineación de bordes entre MOVING_Y (0.545f) y BASE_Y (0.590f)
        public float leftEdgeDeltaPx;
        public float rightEdgeDeltaPx;
        public float edgeAlignmentCenterX;

        public float effectiveTargetCenterX;
        public boolean isReferenceLocked;

        public void reset() {
            validFrame = false;
            baseDetected = false;
            movingDetected = false;
            leftEdgeDeltaPx = 0.0f;
            rightEdgeDeltaPx = 0.0f;
            edgeAlignmentCenterX = 0.0f;
            processingTimeMs = 0.0f;
        }
    }

    public IsometricStackTracker() {
        resetAxesToFactoryDefaults();
    }

    /**
     * Restaura las coordenadas de fábrica exactas (MOVING_Y = 0.545f, BASE_Y = 0.590f, X = 0.500f)
     * y solicita re-centrado automático sobre la cara superior del bloque actual.
     */
    public synchronized void resetAxesToFactoryDefaults() {
        this.movingScanYNorm = DEFAULT_MOVING_Y_NORM;
        this.baseScanYNorm = DEFAULT_BASE_Y_NORM;
        this.manualTargetXNorm = DEFAULT_FIXED_AXIS_X_NORM;
        this.autoBaseMode = true;
        this.referenceLockActive = false;
        this.lockedTargetCenterX = -1.0f;
        this.smoothedBaseCenterX = -1.0f;
        this.smoothedBaseLeftX = -1.0f;
        this.smoothedBaseRightX = -1.0f;
        this.lastKnownBaseWidth = -1.0f;
        this.requestImmediateAutoCenter = true;
    }

    /**
     * Verifica si dos coordenadas Y guardadas en SharedPreferences son válidas y no están invertidas.
     */
    public static boolean areSavedAxesValid(float savedMovingY, float savedBaseY) {
        if (Float.isNaN(savedMovingY) || Float.isNaN(savedBaseY)) {
            return false;
        }
        if (savedMovingY < MIN_VALID_SCAN_Y_NORM || savedMovingY > MAX_VALID_SCAN_Y_NORM) {
            return false;
        }
        if (savedBaseY < MIN_VALID_SCAN_Y_NORM || savedBaseY > MAX_VALID_SCAN_Y_NORM) {
            return false;
        }
        return savedMovingY <= (savedBaseY - MIN_SCANLINE_SEPARATION_NORM);
    }

    /**
     * Regla Anti-Inversión: garantiza siempre que MOVING_SCAN_Y_NORM < BASE_SCAN_Y_NORM - 0.02f.
     */
    public synchronized void enforceAntiInversionRule() {
        float mov = clamp(this.movingScanYNorm, 0.35f, 0.72f);
        float base = clamp(this.baseScanYNorm, 0.38f, 0.75f);

        if (mov >= base - MIN_SCANLINE_SEPARATION_NORM) {
            // Si se cruzan o invierten, restauramos la separación mínima o valores de fábrica
            if (!areSavedAxesValid(mov, base)) {
                this.movingScanYNorm = DEFAULT_MOVING_Y_NORM;
                this.baseScanYNorm = DEFAULT_BASE_Y_NORM;
            } else {
                this.movingScanYNorm = Math.max(0.35f, base - MIN_SCANLINE_SEPARATION_NORM);
            }
        } else {
            this.movingScanYNorm = mov;
            this.baseScanYNorm = base;
        }
    }

    public synchronized void setMovingScanYNorm(float normY) {
        float clampedY = clamp(normY, 0.35f, 0.72f);
        float maxAllowedMovingY = this.baseScanYNorm - MIN_SCANLINE_SEPARATION_NORM;
        this.movingScanYNorm = Math.min(clampedY, maxAllowedMovingY);
    }

    public float getMovingScanYNorm() {
        return movingScanYNorm;
    }

    public synchronized void setBaseScanYNorm(float normY) {
        float clampedY = clamp(normY, 0.38f, 0.75f);
        float minAllowedBaseY = this.movingScanYNorm + MIN_SCANLINE_SEPARATION_NORM;
        this.baseScanYNorm = Math.max(clampedY, minAllowedBaseY);
    }

    public float getBaseScanYNorm() {
        return baseScanYNorm;
    }

    public void setManualTargetXNorm(float normX) {
        this.manualTargetXNorm = clamp(normX, 0.20f, 0.80f);
        this.lockedTargetCenterX = -1.0f;
    }

    public float getManualTargetXNorm() {
        return manualTargetXNorm;
    }

    public void setAutoBaseMode(boolean autoBase) {
        this.autoBaseMode = autoBase;
    }

    public boolean isAutoBaseMode() {
        return autoBaseMode;
    }

    public void setColorDiffThreshold(int threshold) {
        this.colorDiffThreshold = Math.max(16, Math.min(110, threshold));
    }

    public int getColorDiffThreshold() {
        return colorDiffThreshold;
    }

    public void lockCurrentReference(float currentTargetX) {
        if (currentTargetX > 0.0f) {
            this.lockedTargetCenterX = currentTargetX;
            this.referenceLockActive = true;
        }
    }

    public void unlockReference() {
        this.referenceLockActive = false;
        this.lockedTargetCenterX = -1.0f;
        this.smoothedBaseCenterX = -1.0f;
        this.smoothedBaseLeftX = -1.0f;
        this.smoothedBaseRightX = -1.0f;
    }

    public boolean isReferenceLockActive() {
        return referenceLockActive;
    }

    /**
     * Procesa un objeto Image de ImageReader directamente desde su ByteBuffer RGBA_8888.
     */
    public ScanResult processImage(Image image) {
        if (image == null) {
            reusableResult.reset();
            return reusableResult;
        }
        Image.Plane[] planes = image.getPlanes();
        if (planes == null || planes.length == 0 || planes[0].getBuffer() == null) {
            reusableResult.reset();
            return reusableResult;
        }
        Image.Plane plane = planes[0];
        ByteBuffer buffer = plane.getBuffer();
        int width = image.getWidth();
        int height = image.getHeight();
        int rowStride = plane.getRowStride();
        int pixelStride = plane.getPixelStride();
        long timestampNs = image.getTimestamp();
        if (timestampNs <= 0L) {
            timestampNs = System.nanoTime();
        }
        return processByteBuffer(buffer, width, height, rowStride, pixelStride, timestampNs);
    }

    /**
     * Escaneo directo sobre ByteBuffer en MOVING_Y (0.545f) y BASE_Y (0.590f).
     * Detecta exclusivamente la cara superior iluminada del bloque (croma >= 26 y max >= 135)
     * y calcula tanto el centro como la alineación de bordes izquierdo y derecho.
     */
    public ScanResult processByteBuffer(
            ByteBuffer buffer,
            int width,
            int height,
            int rowStride,
            int pixelStride,
            long timestampNs) {

        long startNs = System.nanoTime();
        reusableResult.reset();

        if (buffer == null || width <= 64 || height <= 64 || pixelStride < 4) {
            return reusableResult;
        }

        enforceAntiInversionRule();

        int bufferLimit = buffer.limit();
        int movingY = clampInt(Math.round(movingScanYNorm * height), 8, height - 12);
        int baseY = clampInt(Math.round(baseScanYNorm * height), movingY + 6, height - 9);

        reusableResult.validFrame = true;
        reusableResult.frameWidth = width;
        reusableResult.frameHeight = height;
        reusableResult.timestampNs = timestampNs;
        reusableResult.movingScanY = movingY;
        reusableResult.baseScanY = baseY;

        int scanStartX = clampInt(Math.round(SCAN_START_X_NORM * width), 4, width - 5);
        int scanEndX = clampInt(Math.round(SCAN_END_X_NORM * width), scanStartX + 16, width - 4);
        int bgLeftX = clampInt(Math.round(BG_SAMPLE_LEFT_X_NORM * width), 2, scanStartX - 1);
        int bgRightX = clampInt(Math.round(BG_SAMPLE_RIGHT_X_NORM * width), scanEndX + 1, width - 3);

        // 1. Escanear Línea Base (BASE_Y = 0.590f) aislando la cara superior iluminada
        boolean baseFound = scanIlluminatedTopFaceLine(
                buffer, bufferLimit, rowStride, pixelStride,
                baseY, scanStartX, scanEndX, bgLeftX, bgRightX,
                true, reusableResult);

        // Si en los primeros bloques la plataforma está ligeramente más arriba/abajo, micro-búsqueda
        if (!baseFound && baseY > 24 && baseY < height - 24) {
            int altBaseY = Math.max(movingY + 6, baseY - Math.round(0.018f * height));
            baseFound = scanIlluminatedTopFaceLine(
                    buffer, bufferLimit, rowStride, pixelStride,
                    altBaseY, scanStartX, scanEndX, bgLeftX, bgRightX,
                    true, reusableResult);
        }

        // 2. Escanear Línea Móvil (MOVING_Y = 0.545f) aislando la cara superior iluminada
        scanIlluminatedTopFaceLine(
                buffer, bufferLimit, rowStride, pixelStride,
                movingY, scanStartX, scanEndX, bgLeftX, bgRightX,
                false, reusableResult);

        // 3. Actualizar referencia del bloque base y calcular alineación de bordes (Left & Right)
        float fallbackCenter = manualTargetXNorm * width;

        if (reusableResult.baseDetected) {
            float detCenter = reusableResult.detectedBaseCenterX;
            float detLeft = reusableResult.baseLeftX;
            float detRight = reusableResult.baseRightX;
            float detWidth = reusableResult.baseWidth;

            if (requestImmediateAutoCenter || smoothedBaseCenterX < 0.0f) {
                smoothedBaseCenterX = detCenter;
                smoothedBaseLeftX = detLeft;
                smoothedBaseRightX = detRight;
                lastKnownBaseWidth = detWidth;
                manualTargetXNorm = clamp(detCenter / (float) width, 0.20f, 0.80f);
                requestImmediateAutoCenter = false;
            } else {
                // Solo actualizar cuando la losa móvil no está solapando asimétricamente la línea base
                boolean cleanBaseRead = !reusableResult.movingDetected
                        || Math.abs(reusableResult.movingCenterX - smoothedBaseCenterX) > (detWidth * 0.25f)
                        || Math.abs(detWidth - lastKnownBaseWidth) < (lastKnownBaseWidth * 0.18f);

                if (!referenceLockActive && cleanBaseRead) {
                    smoothedBaseCenterX = (smoothedBaseCenterX * 0.72f) + (detCenter * 0.28f);
                    smoothedBaseLeftX = (smoothedBaseLeftX * 0.72f) + (detLeft * 0.28f);
                    smoothedBaseRightX = (smoothedBaseRightX * 0.72f) + (detRight * 0.28f);
                    lastKnownBaseWidth = (lastKnownBaseWidth * 0.72f) + (detWidth * 0.28f);
                }
            }
        }

        // Resolver effectiveTargetCenterX según Modo Auto-Base (por defecto) o Eje Fijo
        if (!autoBaseMode) {
            reusableResult.effectiveTargetCenterX = fallbackCenter;
            reusableResult.isReferenceLocked = true;
        } else if (referenceLockActive && lockedTargetCenterX > 0.0f) {
            reusableResult.effectiveTargetCenterX = lockedTargetCenterX;
            reusableResult.isReferenceLocked = true;
        } else if (smoothedBaseCenterX > 0.0f) {
            reusableResult.effectiveTargetCenterX = smoothedBaseCenterX;
            reusableResult.isReferenceLocked = false;
        } else if (reusableResult.baseDetected) {
            reusableResult.effectiveTargetCenterX = reusableResult.detectedBaseCenterX;
            reusableResult.isReferenceLocked = false;
        } else {
            reusableResult.effectiveTargetCenterX = fallbackCenter;
            reusableResult.isReferenceLocked = false;
        }

        // 4. Medir diferencia de alineación de bordes izquierdo y derecho entre MOVING_Y y BASE_Y
        if (reusableResult.movingDetected && (reusableResult.baseDetected || smoothedBaseLeftX > 0.0f)) {
            float refLeft = (smoothedBaseLeftX > 0.0f) ? smoothedBaseLeftX : reusableResult.baseLeftX;
            float refRight = (smoothedBaseRightX > 0.0f) ? smoothedBaseRightX : reusableResult.baseRightX;

            reusableResult.leftEdgeDeltaPx = reusableResult.movingLeftX - refLeft;
            reusableResult.rightEdgeDeltaPx = reusableResult.movingRightX - refRight;
            reusableResult.edgeAlignmentCenterX = (refLeft + refRight) * 0.5f;

            if (autoBaseMode && !referenceLockActive && reusableResult.edgeAlignmentCenterX > 0.0f) {
                reusableResult.effectiveTargetCenterX = reusableResult.edgeAlignmentCenterX;
            }
        }

        long elapsedNs = System.nanoTime() - startNs;
        reusableResult.processingTimeMs = elapsedNs / 1_000_000.0f;
        return reusableResult;
    }

    /**
     * Escanea una línea horizontal detectando exclusivamente píxeles de la cara superior iluminada
     * del bloque 3D:
     * - Rechaza el suelo gris neutro (R≈180, G≈172, B≈180 -> max - min < 16).
     * - Rechaza la cara lateral derecha oscura (R≈108, G≈73, B≈138 -> max < 135).
     * - Acepta la cara superior iluminada (R≈181, G≈140, B≈190 -> croma >= 26 y max >= 135).
     */
    private boolean scanIlluminatedTopFaceLine(
            ByteBuffer buffer,
            int bufferLimit,
            int rowStride,
            int pixelStride,
            int y,
            int startX,
            int endX,
            int bgLeftX,
            int bgRightX,
            boolean isBaseLine,
            ScanResult outResult) {

        int sampleY1 = Math.max(2, y - 3);
        int sampleY2 = y + 3;

        int rowOffset1 = sampleY1 * rowStride;
        int rowOffset2 = sampleY2 * rowStride;
        if (rowOffset2 + (bgRightX * pixelStride) + 3 >= bufferLimit) {
            rowOffset2 = rowOffset1;
        }

        int bgLeftIdx = rowOffset1 + (bgLeftX * pixelStride);
        int bgRightIdx = rowOffset1 + (bgRightX * pixelStride);
        if (bgLeftIdx < 0 || bgRightIdx + 3 >= bufferLimit) {
            return false;
        }

        int bgLeftR = buffer.get(bgLeftIdx) & 0xFF;
        int bgLeftG = buffer.get(bgLeftIdx + 1) & 0xFF;
        int bgLeftB = buffer.get(bgLeftIdx + 2) & 0xFF;

        int bgRightR = buffer.get(bgRightIdx) & 0xFF;
        int bgRightG = buffer.get(bgRightIdx + 1) & 0xFF;
        int bgRightB = buffer.get(bgRightIdx + 2) & 0xFF;

        // 1. Buscar borde izquierdo (movingLeftX o baseLeftX)
        int foundLeftX = -1;
        int consecutiveLeft = 0;
        for (int x = startX; x <= endX; x += 2) {
            int idx1 = rowOffset1 + (x * pixelStride);
            int idx2 = rowOffset2 + (x * pixelStride);

            int r1 = buffer.get(idx1) & 0xFF;
            int g1 = buffer.get(idx1 + 1) & 0xFF;
            int b1 = buffer.get(idx1 + 2) & 0xFF;

            int r2 = buffer.get(idx2) & 0xFF;
            int g2 = buffer.get(idx2 + 1) & 0xFF;
            int b2 = buffer.get(idx2 + 2) & 0xFF;

            boolean match1 = isTopFaceBlockPixel(r1, g1, b1, bgLeftR, bgLeftG, bgLeftB, bgRightR, bgRightG, bgRightB);
            boolean match2 = isTopFaceBlockPixel(r2, g2, b2, bgLeftR, bgLeftG, bgLeftB, bgRightR, bgRightG, bgRightB);

            if (match1 || match2) {
                consecutiveLeft += 2;
                if (consecutiveLeft >= MIN_CONSECUTIVE_EDGE_PX) {
                    foundLeftX = x - consecutiveLeft + 2;
                    break;
                }
            } else {
                consecutiveLeft = 0;
            }
        }

        if (foundLeftX < 0) {
            return false;
        }

        // 2. Buscar borde derecho (movingRightX o baseRightX) excluyendo la pared derecha oscura
        int foundRightX = -1;
        int consecutiveRight = 0;
        for (int x = endX; x >= foundLeftX; x -= 2) {
            int idx1 = rowOffset1 + (x * pixelStride);
            int idx2 = rowOffset2 + (x * pixelStride);

            int r1 = buffer.get(idx1) & 0xFF;
            int g1 = buffer.get(idx1 + 1) & 0xFF;
            int b1 = buffer.get(idx1 + 2) & 0xFF;

            int r2 = buffer.get(idx2) & 0xFF;
            int g2 = buffer.get(idx2 + 1) & 0xFF;
            int b2 = buffer.get(idx2 + 2) & 0xFF;

            boolean match1 = isTopFaceBlockPixel(r1, g1, b1, bgLeftR, bgLeftG, bgLeftB, bgRightR, bgRightG, bgRightB);
            boolean match2 = isTopFaceBlockPixel(r2, g2, b2, bgLeftR, bgLeftG, bgLeftB, bgRightR, bgRightG, bgRightB);

            if (match1 || match2) {
                consecutiveRight += 2;
                if (consecutiveRight >= MIN_CONSECUTIVE_EDGE_PX) {
                    foundRightX = x + consecutiveRight - 2;
                    break;
                }
            } else {
                consecutiveRight = 0;
            }
        }

        if (foundRightX < 0 || (foundRightX - foundLeftX) < MIN_BLOCK_WIDTH_PX) {
            return false;
        }

        // Refinamiento sub-píxel de 1px en ambos extremos
        if (foundLeftX > startX) {
            int prevIdx = rowOffset1 + ((foundLeftX - 1) * pixelStride);
            int r = buffer.get(prevIdx) & 0xFF;
            int g = buffer.get(prevIdx + 1) & 0xFF;
            int b = buffer.get(prevIdx + 2) & 0xFF;
            if (isTopFaceBlockPixel(r, g, b, bgLeftR, bgLeftG, bgLeftB, bgRightR, bgRightG, bgRightB)) {
                foundLeftX -= 1;
            }
        }
        if (foundRightX < endX) {
            int nextIdx = rowOffset1 + ((foundRightX + 1) * pixelStride);
            int r = buffer.get(nextIdx) & 0xFF;
            int g = buffer.get(nextIdx + 1) & 0xFF;
            int b = buffer.get(nextIdx + 2) & 0xFF;
            if (isTopFaceBlockPixel(r, g, b, bgLeftR, bgLeftG, bgLeftB, bgRightR, bgRightG, bgRightB)) {
                foundRightX += 1;
            }
        }

        float widthPx = (float) (foundRightX - foundLeftX);
        float centerPx = (foundLeftX + foundRightX) * 0.5f;

        if (isBaseLine) {
            outResult.baseDetected = true;
            outResult.baseLeftX = foundLeftX;
            outResult.baseRightX = foundRightX;
            outResult.baseWidth = widthPx;
            outResult.detectedBaseCenterX = centerPx;
        } else {
            outResult.movingDetected = true;
            outResult.movingLeftX = foundLeftX;
            outResult.movingRightX = foundRightX;
            outResult.movingWidth = widthPx;
            outResult.movingCenterX = centerPx;
        }
        return true;
    }

    /**
     * Evalúa si un píxel pertenece a la cara superior iluminada del bloque isométrico 3D:
     * - Ignora colores del propio overlay láser (verde #00E676, cian #00E5FF, amarillo #FFEA00).
     * - Exige croma (max - min >= 26) para ignorar el suelo gris neutro (R≈180, G≈172, B≈180).
     * - Exige brillo alto (max >= 135) y filtra la cara lateral derecha oscura (R≈108, G≈73, B≈138).
     */
    private boolean isTopFaceBlockPixel(
            int r, int g, int b,
            int bgLeftR, int bgLeftG, int bgLeftB,
            int bgRightR, int bgRightG, int bgRightB) {

        // 1. Descartar trazos neón del propio overlay (verde, cian o punto amarillo)
        if (g > 210 && r < 40 && (b < 140 || b > 230)) {
            return false;
        }
        if (r > 235 && g > 215 && b < 45) {
            return false;
        }

        int max = Math.max(r, Math.max(g, b));
        int min = Math.min(r, Math.min(g, b));
        int chroma = max - min;

        // 2. Exigir croma >= 26 y brillo max >= 135 (descarta el suelo gris neutro S < 0.08 y la pared derecha oscura)
        if (chroma < MIN_TOP_FACE_CHROMA || max < MIN_TOP_FACE_BRIGHTNESS) {
            return false;
        }

        // 3. Descartar la pared lateral derecha oscura (donde R < 132 y B domina sobre un tono oscuro)
        if (max < 148 && r < 132) {
            return false;
        }

        // 4. Descartar el fondo claro/blanco superior si tuviera leve tinte lavanda
        if (min > MAX_SKY_MIN_CHANNEL) {
            return false;
        }

        // 5. Verificar contraste respecto al fondo lateral muestreado en x=0.05f y x=0.95f
        int diffLeft = Math.abs(r - bgLeftR) + Math.abs(g - bgLeftG) + Math.abs(b - bgLeftB);
        int diffRight = Math.abs(r - bgRightR) + Math.abs(g - bgRightG) + Math.abs(b - bgRightB);
        int minDiff = Math.min(diffLeft, diffRight);

        return minDiff >= colorDiffThreshold;
    }

    private static float clamp(float val, float min, float max) {
        return Math.max(min, Math.min(max, val));
    }

    private static int clampInt(int val, int min, int max) {
        return Math.max(min, Math.min(max, val));
    }
}
