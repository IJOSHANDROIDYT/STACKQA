package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import java.nio.ByteBuffer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `verify factory coordinates anti-inversion and top-face chroma detector`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("QA AutoStacker", appName)

    val tracker = IsometricStackTracker()
    assertEquals(0.545f, tracker.movingScanYNorm, 0.0001f)
    assertEquals(0.590f, tracker.baseScanYNorm, 0.0001f)
    assertTrue(tracker.isAutoBaseMode)

    // Verify anti-inversion rule prevents MOVING_Y from crossing below BASE_Y - 0.02f
    assertFalse(IsometricStackTracker.areSavedAxesValid(0.62f, 0.46f))
    tracker.movingScanYNorm = 0.65f
    assertTrue(tracker.movingScanYNorm <= tracker.baseScanYNorm - 0.02f + 0.0001f)
    tracker.resetAxesToFactoryDefaults()

    val width = 1080
    val height = 2400
    val rowStride = width * 4
    val buffer = ByteBuffer.allocateDirect(width * height * 4)

    val baseY = Math.round(tracker.baseScanYNorm * height)
    val movingY = Math.round(tracker.movingScanYNorm * height)

    fun fillRowBandWithRealisticColors(y: Int, topLeftX: Int, topRightX: Int, darkRightWallEndX: Int) {
      for (dy in listOf(-3, 3)) {
        val row = (y + dy) * rowStride
        for (x in 0 until width step 2) {
          val idx = row + x * 4
          when {
            x in topLeftX..topRightX -> {
              // Illuminated top face: R=181, G=140, B=190 (chroma=50 >= 26, max=190 >= 135)
              buffer.put(idx, 181.toByte())
              buffer.put(idx + 1, 140.toByte())
              buffer.put(idx + 2, 190.toByte())
              buffer.put(idx + 3, 255.toByte())
            }
            x in (topRightX + 1)..darkRightWallEndX -> {
              // Dark right lateral face: R=108, G=73, B=138 (must be ignored!)
              buffer.put(idx, 108.toByte())
              buffer.put(idx + 1, 73.toByte())
              buffer.put(idx + 2, 138.toByte())
              buffer.put(idx + 3, 255.toByte())
            }
            else -> {
              // Neutral grey floor around tower: R=180, G=172, B=180 (chroma=8 < 26, must be ignored!)
              buffer.put(idx, 180.toByte())
              buffer.put(idx + 1, 172.toByte())
              buffer.put(idx + 2, 180.toByte())
              buffer.put(idx + 3, 255.toByte())
            }
          }
        }
      }
    }

    fillRowBandWithRealisticColors(baseY, 340, 740, 820)
    fillRowBandWithRealisticColors(movingY, 260, 660, 740)

    val scan = tracker.processByteBuffer(buffer, width, height, rowStride, 4, 100_000_000L)
    assertTrue(scan.validFrame)
    assertTrue(scan.baseDetected)
    assertTrue(scan.movingDetected)
    // Verify dark right wall (741..820) and grey floor were ignored, centering strictly on [340..740] -> 540
    assertEquals(540.0f, scan.detectedBaseCenterX, 4.0f)
    assertEquals(460.0f, scan.movingCenterX, 4.0f)
    assertTrue("Processing time must be < 3ms", scan.processingTimeMs < 3.0f)
  }

  @Test
  fun `verify PredictiveTriggerEngine velocity filter and Auto-Base trigger`() {
    val predictor = PredictiveTriggerEngine()
    predictor.leadTimeMs = 24.0f
    predictor.centerOffsetPx = 0.0f

    val targetX = 540.0f

    // 1. Slow/static noise (0.04 px/ms < 0.15 px/ms) must NOT fire even on target
    predictor.evaluateFrame(true, 539.0f, targetX, 100_000_000L, true)
    val slowDecision = predictor.evaluateFrame(true, 539.6f, targetX, 116_000_000L, true)
    assertFalse(slowDecision.shouldFire)

    // 2. Real block approaching at 1.0 px/ms (within [0.15, 3.50] px/ms) MUST fire
    predictor.resetStats()
    predictor.evaluateFrame(true, 460.0f, targetX, 200_000_000L, true)
    predictor.evaluateFrame(true, 476.0f, targetX, 216_000_000L, true)
    predictor.evaluateFrame(true, 492.0f, targetX, 232_000_000L, true)
    val validDecision = predictor.evaluateFrame(true, 510.0f, targetX, 248_000_000L, true)
    assertTrue(validDecision.shouldFire)
  }
}
