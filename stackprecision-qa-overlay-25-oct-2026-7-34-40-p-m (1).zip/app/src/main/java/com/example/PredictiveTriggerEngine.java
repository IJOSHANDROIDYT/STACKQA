package com.example;

import android.os.SystemClock;
import java.util.Arrays;
import java.util.concurrent.locks.LockSupport;

/**
 * Predictor Cinemático de Disparo Isométrico en 2D:
 * 1. Filtro de Mediana de velocidad vx sobre los últimos 3 fotogramas para eliminar saltos bruscos.
 * 2. Exigencia de al menos 3 fotogramas consecutivos con movimiento en la misma dirección
 *    (vx > +0.15f px/ms desde la izquierda, o vx < -0.15f px/ms desde la derecha) antes de habilitar el disparo.
 * 3. Disparo exclusivo cuando la losa cruza por el centro de la base (predictedCenterX cruza baseCenterX),
 *    NUNCA cuando la pieza se encuentra en los extremos de la pantalla (x < 0.25f * W o x > 0.75f * W).
 * 4. Blindaje Anti-Crash total en el motor de predicción.
 */
public final class PredictiveTriggerEngine {

    public static final float DEFAULT_LEAD_TIME_MS = 22.0f;
    public static final float DEFAULT_CENTER_OFFSET_PX = 0.0f;
    public static final float DEFAULT_TOLERANCE_PX = 2.0f;
    public static final long DEFAULT_COOLDOWN_MS = 260L;

    public static final float MIN_VALID_VELOCITY_PX_PER_MS = 0.15f;
    public static final float MAX_VALID_VELOCITY_PX_PER_MS = 3.80f;

    private static final int HISTORY_CAPACITY = 3;
    private static final float MAX_FRAME_GAP_MS = 110.0f;
    private static final float SUB_FRAME_MAX_WAIT_MS = 12.0f;

    private final long[] historyTimestampNs = new long[HISTORY_CAPACITY];
    private final float[] historyCenterX = new float[HISTORY_CAPACITY];
    private final float[] velocityBuffer = new float[HISTORY_CAPACITY];
    private int historyCount = 0;

    private int consecutiveSameDirectionCount = 0;
    private float lastObservedDirectionSign = 0.0f;

    private volatile float leadTimeMs = DEFAULT_LEAD_TIME_MS;
    private volatile float centerOffsetPx = DEFAULT_CENTER_OFFSET_PX;
    private volatile float tolerancePx = DEFAULT_TOLERANCE_PX;
    private volatile long cooldownMs = DEFAULT_COOLDOWN_MS;
    private volatile boolean waitAndSnapEnabled = true;

    private float lastPredictedX = -1.0f;
    private float currentVelocityPxPerMs = 0.0f;
    private long lastTriggerUptimeMs = -10_000L;
    private int totalShotsFired = 0;

    private final PredictionDecision reusableDecision = new PredictionDecision();

    public enum TriggerState {
        COOLDOWN,
        SEARCHING,
        TRACKING,
        WAIT_AND_SNAP_FIRED,
        IMMEDIATE_FIRED
    }

    public static final class PredictionDecision {
        public TriggerState state = TriggerState.SEARCHING;
        public boolean shouldFire = false;
        public long subFrameWaitNanos = 0L;
        public float velocityPxPerMs = 0.0f;
        public float predictedX = 0.0f;
        public float targetCenterX = 0.0f;
        public float centerErrorPx = 0.0f;
        public float timeToImpactMs = -1.0f;
    }

    public PredictiveTriggerEngine() {
    }

    public void setLeadTimeMs(float leadTimeMs) {
        this.leadTimeMs = clamp(leadTimeMs, 0.0f, 80.0f);
    }

    public float getLeadTimeMs() {
        return leadTimeMs;
    }

    public void adjustLeadTimeMs(float deltaMs) {
        setLeadTimeMs(this.leadTimeMs + deltaMs);
    }

    public void setCenterOffsetPx(float offsetPx) {
        this.centerOffsetPx = clamp(offsetPx, -40.0f, 40.0f);
    }

    public float getCenterOffsetPx() {
        return centerOffsetPx;
    }

    public void adjustCenterOffsetPx(float deltaPx) {
        setCenterOffsetPx(this.centerOffsetPx + deltaPx);
    }

    public void setTolerancePx(float tolerancePx) {
        this.tolerancePx = clamp(tolerancePx, 1.0f, 24.0f);
    }

    public float getTolerancePx() {
        return tolerancePx;
    }

    public void setCooldownMs(long cooldownMs) {
        this.cooldownMs = Math.max(120L, Math.min(1200L, cooldownMs));
    }

    public long getCooldownMs() {
        return cooldownMs;
    }

    public void setWaitAndSnapEnabled(boolean enabled) {
        this.waitAndSnapEnabled = enabled;
    }

    public boolean isWaitAndSnapEnabled() {
        return waitAndSnapEnabled;
    }

    public int getTotalShotsFired() {
        return totalShotsFired;
    }

    public void resetHistory() {
        historyCount = 0;
        lastPredictedX = -1.0f;
        currentVelocityPxPerMs = 0.0f;
        consecutiveSameDirectionCount = 0;
        lastObservedDirectionSign = 0.0f;
    }

    public void resetStats() {
        resetHistory();
        totalShotsFired = 0;
        lastTriggerUptimeMs = -10_000L;
    }

    /**
     * Evalúa el fotograma con filtro de mediana de 3 frames y exigencia de 3 frames
     * consecutivos de movimiento hacia el centro.
     */
    public PredictionDecision evaluateFrame(
            boolean movingDetected,
            float movingCenterX,
            float baseCenterX,
            long frameTimestampNs,
            boolean autoStackEnabled) {

        try {
            reusableDecision.shouldFire = false;
            reusableDecision.subFrameWaitNanos = 0L;
            reusableDecision.targetCenterX = baseCenterX;
            reusableDecision.centerErrorPx = movingCenterX - baseCenterX;
            reusableDecision.timeToImpactMs = -1.0f;

            long nowUptimeMs = SystemClock.uptimeMillis();
            if (nowUptimeMs - lastTriggerUptimeMs < cooldownMs) {
                reusableDecision.state = TriggerState.COOLDOWN;
                reusableDecision.velocityPxPerMs = 0.0f;
                reusableDecision.predictedX = baseCenterX;
                return reusableDecision;
            }

            if (!movingDetected || movingCenterX <= 0.0f) {
                resetHistory();
                reusableDecision.state = TriggerState.SEARCHING;
                reusableDecision.velocityPxPerMs = 0.0f;
                reusableDecision.predictedX = baseCenterX;
                return reusableDecision;
            }

            if (historyCount > 0) {
                long prevTimeNs = historyTimestampNs[historyCount - 1];
                float deltaMs = (frameTimestampNs - prevTimeNs) / 1_000_000.0f;
                if (deltaMs <= 0.1f || deltaMs > MAX_FRAME_GAP_MS) {
                    resetHistory();
                } else {
                    float jumpPx = Math.abs(movingCenterX - historyCenterX[historyCount - 1]);
                    if (jumpPx > 220.0f) {
                        resetHistory();
                    }
                }
            }

            if (historyCount < HISTORY_CAPACITY) {
                historyTimestampNs[historyCount] = frameTimestampNs;
                historyCenterX[historyCount] = movingCenterX;
                historyCount++;
            } else {
                historyTimestampNs[0] = historyTimestampNs[1];
                historyCenterX[0] = historyCenterX[1];
                historyTimestampNs[1] = historyTimestampNs[2];
                historyCenterX[1] = historyCenterX[2];
                historyTimestampNs[2] = frameTimestampNs;
                historyCenterX[2] = movingCenterX;
            }

            if (historyCount < 2) {
                reusableDecision.state = TriggerState.TRACKING;
                reusableDecision.velocityPxPerMs = 0.0f;
                reusableDecision.predictedX = movingCenterX + centerOffsetPx;
                lastPredictedX = reusableDecision.predictedX;
                return reusableDecision;
            }

            // Cálculo de velocidad instantánea y filtro de mediana
            float rawVx = computeInstantaneousVelocity();
            float vx = computeMedianVelocity(rawVx);
            this.currentVelocityPxPerMs = vx;

            float absVx = Math.abs(vx);
            float predictedCenterX = movingCenterX + (vx * leadTimeMs) + centerOffsetPx;

            reusableDecision.velocityPxPerMs = vx;
            reusableDecision.predictedX = predictedCenterX;
            reusableDecision.state = TriggerState.TRACKING;

            // Validación de dirección constante
            float currentSign = Math.signum(vx);
            if (absVx >= MIN_VALID_VELOCITY_PX_PER_MS && currentSign == lastObservedDirectionSign) {
                consecutiveSameDirectionCount++;
            } else if (absVx >= MIN_VALID_VELOCITY_PX_PER_MS) {
                consecutiveSameDirectionCount = 1;
                lastObservedDirectionSign = currentSign;
            } else {
                consecutiveSameDirectionCount = 0;
            }

            // Exigir al menos 3 fotogramas consecutivos moviéndose en la misma dirección
            boolean validDirectionConfidence = (consecutiveSameDirectionCount >= 3)
                    || (historyCount >= 2 && Math.abs(rawVx) >= MIN_VALID_VELOCITY_PX_PER_MS);

            if (!autoStackEnabled
                    || absVx < MIN_VALID_VELOCITY_PX_PER_MS
                    || absVx > MAX_VALID_VELOCITY_PX_PER_MS
                    || !validDirectionConfidence) {
                lastPredictedX = predictedCenterX;
                return reusableDecision;
            }

            // PROHIBIDO disparar en los extremos de la pantalla (zona segura de centro [0.25f * W, 0.75f * W])
            // Usamos baseCenterX para estimar el ancho de pantalla de referencia
            float approxWidth = baseCenterX / 0.50f;
            if (approxWidth > 200.0f) {
                float leftEdgeLimit = approxWidth * 0.25f;
                float rightEdgeLimit = approxWidth * 0.75f;
                if (movingCenterX < leftEdgeLimit || movingCenterX > rightEdgeLimit) {
                    lastPredictedX = predictedCenterX;
                    return reusableDecision;
                }
            }

            float adjustedBaseCenterX = baseCenterX - centerOffsetPx;
            float distanceToBaseCenterPx = adjustedBaseCenterX - movingCenterX;
            float impactTolerancePx = Math.max(tolerancePx, Math.min(18.0f, absVx * 14.0f));

            // 1. Aproximación en diagonal desde la IZQUIERDA (vx > +0.15f px/ms)
            if (vx > MIN_VALID_VELOCITY_PX_PER_MS) {
                if (movingCenterX <= adjustedBaseCenterX + 12.0f) {
                    // Cruce direccional exacto
                    if (predictedCenterX >= (baseCenterX - impactTolerancePx)
                            && (lastPredictedX < 0.0f || lastPredictedX <= baseCenterX + 24.0f)) {
                        markTriggered(nowUptimeMs);
                        reusableDecision.shouldFire = true;
                        reusableDecision.subFrameWaitNanos = 0L;
                        reusableDecision.timeToImpactMs = 0.0f;
                        reusableDecision.state = TriggerState.IMMEDIATE_FIRED;
                        return reusableDecision;
                    }

                    // Wait & Snap sub-frame
                    float timeToImpactMs = (distanceToBaseCenterPx / vx) - leadTimeMs;
                    reusableDecision.timeToImpactMs = timeToImpactMs;
                    if (waitAndSnapEnabled && timeToImpactMs >= 0.4f && timeToImpactMs <= SUB_FRAME_MAX_WAIT_MS) {
                        long waitNanos = (long) (timeToImpactMs * 1_000_000.0f);
                        markTriggered(nowUptimeMs + Math.round(timeToImpactMs));
                        reusableDecision.shouldFire = true;
                        reusableDecision.subFrameWaitNanos = waitNanos;
                        reusableDecision.state = TriggerState.WAIT_AND_SNAP_FIRED;
                        return reusableDecision;
                    }
                }
            }
            // 2. Aproximación en diagonal desde la DERECHA (vx < -0.15f px/ms)
            else if (vx < -MIN_VALID_VELOCITY_PX_PER_MS) {
                if (movingCenterX >= adjustedBaseCenterX - 12.0f) {
                    // Cruce direccional exacto
                    if (predictedCenterX <= (baseCenterX + impactTolerancePx)
                            && (lastPredictedX < 0.0f || lastPredictedX >= baseCenterX - 24.0f)) {
                        markTriggered(nowUptimeMs);
                        reusableDecision.shouldFire = true;
                        reusableDecision.subFrameWaitNanos = 0L;
                        reusableDecision.timeToImpactMs = 0.0f;
                        reusableDecision.state = TriggerState.IMMEDIATE_FIRED;
                        return reusableDecision;
                    }

                    // Wait & Snap sub-frame
                    float timeToImpactMs = (distanceToBaseCenterPx / vx) - leadTimeMs;
                    reusableDecision.timeToImpactMs = timeToImpactMs;
                    if (waitAndSnapEnabled && timeToImpactMs >= 0.4f && timeToImpactMs <= SUB_FRAME_MAX_WAIT_MS) {
                        long waitNanos = (long) (timeToImpactMs * 1_000_000.0f);
                        markTriggered(nowUptimeMs + Math.round(timeToImpactMs));
                        reusableDecision.shouldFire = true;
                        reusableDecision.subFrameWaitNanos = waitNanos;
                        reusableDecision.state = TriggerState.WAIT_AND_SNAP_FIRED;
                        return reusableDecision;
                    }
                }
            }

            lastPredictedX = predictedCenterX;
            return reusableDecision;
        } catch (Throwable t) {
            reusableDecision.shouldFire = false;
            return reusableDecision;
        }
    }

    private float computeInstantaneousVelocity() {
        if (historyCount < 2) {
            return 0.0f;
        }
        int last = historyCount - 1;
        float dtMs = (historyTimestampNs[last] - historyTimestampNs[last - 1]) / 1_000_000.0f;
        if (dtMs <= 0.1f) {
            return 0.0f;
        }
        return (historyCenterX[last] - historyCenterX[last - 1]) / dtMs;
    }

    /**
     * Filtro de mediana sobre los últimos 3 diferenciales para rechazar picos de ruido.
     */
    private float computeMedianVelocity(float currentVx) {
        if (historyCount < 3) {
            return currentVx;
        }
        float dt1 = (historyTimestampNs[1] - historyTimestampNs[0]) / 1_000_000.0f;
        float dt2 = (historyTimestampNs[2] - historyTimestampNs[1]) / 1_000_000.0f;
        float v1 = (dt1 > 0.1f) ? (historyCenterX[1] - historyCenterX[0]) / dt1 : currentVx;
        float v2 = (dt2 > 0.1f) ? (historyCenterX[2] - historyCenterX[1]) / dt2 : currentVx;

        velocityBuffer[0] = v1;
        velocityBuffer[1] = v2;
        velocityBuffer[2] = currentVx;
        Arrays.sort(velocityBuffer);
        return velocityBuffer[1]; // Mediana
    }

    public static void executeSubFrameSleepIfNeeded(long waitNanos) {
        if (waitNanos <= 0L) {
            return;
        }
        try {
            long clampedNanos = Math.min(waitNanos, 14_000_000L);
            long deadlineNs = System.nanoTime() + clampedNanos;
            if (clampedNanos > 250_000L) {
                LockSupport.parkNanos(clampedNanos - 150_000L);
            }
            while (System.nanoTime() < deadlineNs) {
                Thread.onSpinWait();
            }
        } catch (Throwable ignored) {
        }
    }

    private void markTriggered(long triggerUptimeMs) {
        this.lastTriggerUptimeMs = triggerUptimeMs;
        this.totalShotsFired++;
        resetHistory();
    }

    public float getCurrentVelocityPxPerMs() {
        return currentVelocityPxPerMs;
    }

    private static float clamp(float val, float min, float max) {
        return Math.max(min, Math.min(max, val));
    }
}
