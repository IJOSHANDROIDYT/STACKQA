package com.example;

import android.media.Image;
import android.os.SystemClock;
import java.nio.ByteBuffer;
import java.util.Arrays;

/**
 * Motor de Visión por Computadora en Tiempo Real (60 FPS) con:
 * 1. Protección contra Anuncios a pantalla completa (ej. Temu blanco):
 *    Verifica la presencia del cartel verde "$100 GUARANTEED" o los bloques del juego,
 *    y detecta si la pantalla es un anuncio publicitario blanco/ajeno (isGameScreenValid).
 * 2. Clasificación 2D de píxeles Bloque vs Fondo (Cielo claro / Suelo gris neutro)
 *    con paso rápido de 4px dentro del área de la torre (Y de 0.35f a 0.76f, X de 0.04f a 0.96f).
 * 3. Separación Matemática 2D Estático (Base) vs Dinámico (Losa Móvil):
 *    Usa diferencia temporal |I_t - I_{prev}| para medir los extremos 2D globales
 *    [movingMinX, movingMaxX] y [baseMinX, baseMaxX], con Candado de Seguridad (Sanity Clamp).
 * 4. Blindaje Anti-Crash total en todas las operaciones.
 */
public final class IsometricStackTracker {

    public static final float DEFAULT_MOVING_Y_NORM = 0.545f;
    public static final float DEFAULT_BASE_Y_NORM = 0.590f;
    public static final float DEFAULT_FIXED_AXIS_X_NORM = 0.500f;

    public static final float DEFAULT_MOVING_SCAN_Y_NORM = DEFAULT_MOVING_Y_NORM;
    public static final float DEFAULT_BASE_SCAN_Y_NORM = DEFAULT_BASE_Y_NORM;
    public static final float DEFAULT_TARGET_X_NORM = DEFAULT_FIXED_AXIS_X_NORM;

    public static final float MIN_VALID_SCAN_Y_NORM = 0.34f;
    public static final float MAX_VALID_SCAN_Y_NORM = 0.72f;
    public static final float MIN_SCANLINE_SEPARATION_NORM = 0.02f;

    // Región 2D de la torre a analizar
    public static final float TOWER_SCAN_TOP_Y_NORM = 0.35f;
    public static final float TOWER_SCAN_BOTTOM_Y_NORM = 0.76f;
    public static final float TOWER_SCAN_LEFT_X_NORM = 0.04f;
    public static final float TOWER_SCAN_RIGHT_X_NORM = 0.96f;

    // Zona de validación del juego (Cartel Verde superior "$100 GUARANTEED")
    private static final float BANNER_TOP_Y_NORM = 0.02f;
    private static final float BANNER_BOTTOM_Y_NORM = 0.22f;
    private static final float BANNER_LEFT_X_NORM = 0.30f;
    private static final float BANNER_RIGHT_X_NORM = 0.70f;

    // Rejilla de muestreo rápido en 2D (4px equivalente) para ultra-baja latencia (< 2ms)
    private static final int GRID_COLS = 96;
    private static final int GRID_ROWS = 64;
    private static final int GRID_CELLS = GRID_COLS * GRID_ROWS;

    private static final int DEFAULT_BG_DIFF_THRESHOLD = 38;
    private static final int TEMPORAL_DIFF_THRESHOLD = 24;
    private static final int TEMPORAL_STATIC_THRESHOLD = 10;
    private static final int MIN_SLAB_WIDTH_PX_REF = 45;

    private int colorDiffThreshold = DEFAULT_BG_DIFF_THRESHOLD;

    private volatile float movingScanYNorm = DEFAULT_MOVING_Y_NORM;
    private volatile float baseScanYNorm = DEFAULT_BASE_Y_NORM;
    private volatile float manualTargetXNorm = DEFAULT_FIXED_AXIS_X_NORM;
    private volatile boolean autoBaseMode = true;
    private volatile boolean referenceLockActive = false;
    private volatile float lockedTargetCenterX = -1.0f;

    // Estado dinámico de la base estacionaria con candado de seguridad
    private volatile float trackedBaseMinX = -1.0f;
    private volatile float trackedBaseMaxX = -1.0f;
    private volatile float trackedBaseCenterX = -1.0f;
    private volatile float trackedBaseWidth = -1.0f;
    private volatile int trackedBaseCrownY = -1;
    private volatile int trackedTowerTopY = -1;
    private volatile boolean needsBaseRecapture = true;
    private volatile long settleUntilUptimeMs = -10_000L;

    // Historial temporal para |I_t - I_prev|
    private final short[] gridRgbCurrent = new short[GRID_CELLS * 3];
    private final short[] gridRgbPrev = new short[GRID_CELLS * 3];
    private final short[] gridRgbSettled = new short[GRID_CELLS * 3];

    private final boolean[] rowHasMovement = new boolean[GRID_ROWS];
    private final float[] rowBlockMinX = new float[GRID_ROWS];
    private final float[] rowBlockMaxX = new float[GRID_ROWS];
    private final float[] rowMovingMinX = new float[GRID_ROWS];
    private final float[] rowMovingMaxX = new float[GRID_ROWS];
    private final int[] rowMeanR = new int[GRID_ROWS];
    private final int[] rowMeanG = new int[GRID_ROWS];
    private final int[] rowMeanB = new int[GRID_ROWS];

    private int capturedFrames = 0;
    private boolean hasSettledReference = false;
    private int lastFrameWidth = 0;
    private int lastFrameHeight = 0;

    private final ScanResult reusableResult = new ScanResult();

    public static final class ScanResult {
        public boolean validFrame;
        public boolean isGameScreenValid;
        public int frameWidth;
        public int frameHeight;
        public long timestampNs;
        public float processingTimeMs;

        // Base Estacionaria 2D
        public int towerTopY;
        public int baseScanY;
        public int baseCrownY;
        public boolean baseDetected;
        public float baseMinX;
        public float baseMaxX;
        public float baseLeftX;
        public float baseRightX;
        public float baseCenterX;
        public float detectedBaseCenterX;
        public float baseWidth;

        // Losa en Movimiento 2D
        public int movingScanY;
        public int movingCrownY;
        public boolean movingDetected;
        public float movingMinX;
        public float movingMaxX;
        public float movingLeftX;
        public float movingRightX;
        public float movingCenterX;
        public float movingWidth;

        // Errores de alineación en 2D
        public float centerErrorPx;
        public float leftEdgeDeltaPx;
        public float rightEdgeDeltaPx;
        public float effectiveTargetCenterX;
        public boolean isReferenceLocked;

        // Detección de botón de inicio
        public boolean tapToPlayButtonDetected;
        public float tapToPlayCenterX;
        public float tapToPlayCenterY;

        public void reset() {
            validFrame = false;
            isGameScreenValid = true;
            baseDetected = false;
            movingDetected = false;
            tapToPlayButtonDetected = false;
            centerErrorPx = 0.0f;
            leftEdgeDeltaPx = 0.0f;
            rightEdgeDeltaPx = 0.0f;
            processingTimeMs = 0.0f;
        }
    }

    public IsometricStackTracker() {
        resetAxesToFactoryDefaults();
    }

    public synchronized void resetAxesToFactoryDefaults() {
        this.movingScanYNorm = DEFAULT_MOVING_Y_NORM;
        this.baseScanYNorm = DEFAULT_BASE_Y_NORM;
        this.manualTargetXNorm = DEFAULT_FIXED_AXIS_X_NORM;
        this.autoBaseMode = true;
        this.referenceLockActive = false;
        this.lockedTargetCenterX = -1.0f;

        this.trackedBaseMinX = -1.0f;
        this.trackedBaseMaxX = -1.0f;
        this.trackedBaseCenterX = -1.0f;
        this.trackedBaseWidth = -1.0f;
        this.trackedBaseCrownY = -1;
        this.trackedTowerTopY = -1;
        this.needsBaseRecapture = true;
        this.capturedFrames = 0;
        this.hasSettledReference = false;
    }

    public void notifyShotFired(long settleDelayMs) {
        this.settleUntilUptimeMs = SystemClock.uptimeMillis() + Math.max(180L, settleDelayMs);
        this.needsBaseRecapture = true;
    }

    public static boolean areSavedAxesValid(float savedMovingY, float savedBaseY) {
        if (Float.isNaN(savedMovingY) || Float.isNaN(savedBaseY)) {
            return false;
        }
        if (savedMovingY < MIN_VALID_SCAN_Y_NORM || savedMovingY > MAX_VALID_SCAN_Y_NORM) {
            return false;
        }
        if (savedBaseY < MIN_VALID_SCAN_Y_NORM || savedBaseY > MAX_VALID_SCAN_Y_NORM) {
            return false;
        }
        return savedMovingY <= (savedBaseY - MIN_SCANLINE_SEPARATION_NORM);
    }

    public synchronized void enforceAntiInversionRule() {
        float mov = clamp(this.movingScanYNorm, MIN_VALID_SCAN_Y_NORM, MAX_VALID_SCAN_Y_NORM - 0.03f);
        float base = clamp(this.baseScanYNorm, MIN_VALID_SCAN_Y_NORM + 0.03f, MAX_VALID_SCAN_Y_NORM);
        if (mov >= base - MIN_SCANLINE_SEPARATION_NORM) {
            this.movingScanYNorm = Math.max(MIN_VALID_SCAN_Y_NORM, base - 0.045f);
            this.baseScanYNorm = base;
        } else {
            this.movingScanYNorm = mov;
            this.baseScanYNorm = base;
        }
    }

    public synchronized void setMovingScanYNorm(float normY) {
        float clampedY = clamp(normY, MIN_VALID_SCAN_Y_NORM, MAX_VALID_SCAN_Y_NORM - 0.03f);
        float maxAllowed = this.baseScanYNorm - MIN_SCANLINE_SEPARATION_NORM;
        this.movingScanYNorm = Math.min(clampedY, maxAllowed);
    }

    public float getMovingScanYNorm() {
        return movingScanYNorm;
    }

    public synchronized void setBaseScanYNorm(float normY) {
        float clampedY = clamp(normY, MIN_VALID_SCAN_Y_NORM + 0.03f, MAX_VALID_SCAN_Y_NORM);
        float minAllowed = this.movingScanYNorm + MIN_SCANLINE_SEPARATION_NORM;
        this.baseScanYNorm = Math.max(clampedY, minAllowed);
    }

    public float getBaseScanYNorm() {
        return baseScanYNorm;
    }

    public void setManualTargetXNorm(float normX) {
        this.manualTargetXNorm = clamp(normX, 0.25f, 0.75f);
        this.lockedTargetCenterX = -1.0f;
    }

    public float getManualTargetXNorm() {
        return manualTargetXNorm;
    }

    public void setAutoBaseMode(boolean autoBase) {
        this.autoBaseMode = autoBase;
    }

    public boolean isAutoBaseMode() {
        return autoBaseMode;
    }

    public void setColorDiffThreshold(int threshold) {
        this.colorDiffThreshold = Math.max(20, Math.min(110, threshold));
    }

    public int getColorDiffThreshold() {
        return colorDiffThreshold;
    }

    public void lockCurrentReference(float currentTargetX) {
        if (currentTargetX > 0.0f) {
            this.lockedTargetCenterX = currentTargetX;
            this.referenceLockActive = true;
        }
    }

    public void unlockReference() {
        this.referenceLockActive = false;
        this.lockedTargetCenterX = -1.0f;
        this.needsBaseRecapture = true;
    }

    public boolean isReferenceLockActive() {
        return referenceLockActive;
    }

    public ScanResult processImage(Image image) {
        try {
            if (image == null) {
                reusableResult.reset();
                return reusableResult;
            }
            Image.Plane[] planes = image.getPlanes();
            if (planes == null || planes.length == 0 || planes[0].getBuffer() == null) {
                reusableResult.reset();
                return reusableResult;
            }
            Image.Plane plane = planes[0];
            ByteBuffer buffer = plane.getBuffer();
            int width = image.getWidth();
            int height = image.getHeight();
            int rowStride = plane.getRowStride();
            int pixelStride = plane.getPixelStride();
            long timestampNs = image.getTimestamp();
            if (timestampNs <= 0L) {
                timestampNs = System.nanoTime();
            }
            return processByteBuffer(buffer, width, height, rowStride, pixelStride, timestampNs);
        } catch (Throwable t) {
            reusableResult.reset();
            return reusableResult;
        }
    }

    /**
     * Motor de Visión 2D en ByteBuffer directo:
     * 1. Valida si la pantalla corresponde al juego activo o si es un anuncio externo (isGameScreenValid).
     * 2. Clasifica píxeles 2D Bloque vs Fondo (Cielo/Suelo).
     * 3. Separa el bloque móvil del bloque estacionario por diferencia temporal en 2D.
     * 4. Aplica candado de seguridad (Sanity Clamp) a la base para evitar bordes falsos.
     */
    public ScanResult processByteBuffer(
            ByteBuffer buffer,
            int width,
            int height,
            int rowStride,
            int pixelStride,
            long timestampNs) {

        long startNs = System.nanoTime();
        reusableResult.reset();

        try {
            if (buffer == null || width <= 64 || height <= 64 || pixelStride < 4) {
                return reusableResult;
            }

            if (width != lastFrameWidth || height != lastFrameHeight) {
                lastFrameWidth = width;
                lastFrameHeight = height;
                capturedFrames = 0;
                hasSettledReference = false;
                needsBaseRecapture = true;
            }

            int bufferLimit = buffer.limit();
            reusableResult.validFrame = true;
            reusableResult.frameWidth = width;
            reusableResult.frameHeight = height;
            reusableResult.timestampNs = timestampNs;

            // 1. Verificación de Pantalla de Juego Activa vs Anuncio a Pantalla Completa (ej. Temu blanco)
            boolean gameValid = verifyGameScreenActive(buffer, bufferLimit, width, height, rowStride, pixelStride);
            reusableResult.isGameScreenValid = gameValid;
            if (!gameValid) {
                // Pausar procesamiento si hay un anuncio invasivo o pantalla externa
                reusableResult.processingTimeMs = (System.nanoTime() - startNs) / 1_000_000.0f;
                return reusableResult;
            }

            // Rotar historial temporal para diferencia de fotogramas
            if (capturedFrames >= 1) {
                System.arraycopy(gridRgbCurrent, 0, gridRgbPrev, 0, gridRgbCurrent.length);
            }

            int roiTopY = clampInt(Math.round(TOWER_SCAN_TOP_Y_NORM * height), 8, height - 16);
            int roiBottomY = clampInt(Math.round(TOWER_SCAN_BOTTOM_Y_NORM * height), roiTopY + 32, height - 8);
            int scanStartX = (clampInt(Math.round(TOWER_SCAN_LEFT_X_NORM * width), 6, width - 12) / 2) * 2;
            int scanEndX = (clampInt(Math.round(TOWER_SCAN_RIGHT_X_NORM * width), scanStartX + 32, width - 6) / 2) * 2;

            int skyLeftX = (clampInt(Math.round(0.02f * width), 2, scanStartX - 2) / 2) * 2;
            int skyRightX = (clampInt(Math.round(0.98f * width), scanEndX + 2, width - 4) / 2) * 2;

            float minSlabWidthPx = Math.max(28.0f, (MIN_SLAB_WIDTH_PX_REF / 1080.0f) * width);
            boolean hasHistory = (capturedFrames >= 1);

            Arrays.fill(rowHasMovement, false);
            Arrays.fill(rowBlockMinX, -1.0f);
            Arrays.fill(rowBlockMaxX, -1.0f);
            Arrays.fill(rowMovingMinX, -1.0f);
            Arrays.fill(rowMovingMaxX, -1.0f);

            // 2. Escaneo 2D de las filas de la torre con muestreo bilateral de fondo
            for (int rIdx = 0; rIdx < GRID_ROWS; rIdx++) {
                float normRow = rIdx / (float) (GRID_ROWS - 1);
                int y = roiTopY + Math.round(normRow * (roiBottomY - roiTopY));
                int rowOffset = y * rowStride;
                if (rowOffset < 0 || rowOffset + (skyRightX * pixelStride) + 3 >= bufferLimit) {
                    continue;
                }

                // Fondo bilateral de referencia en esta misma altura Y
                int bgLIdx = rowOffset + (skyLeftX * pixelStride);
                int bgRIdx = rowOffset + (skyRightX * pixelStride);
                int bgLR = buffer.get(bgLIdx) & 0xFF;
                int bgLG = buffer.get(bgLIdx + 1) & 0xFF;
                int bgLB = buffer.get(bgLIdx + 2) & 0xFF;

                int bgRR = buffer.get(bgRIdx) & 0xFF;
                int bgRG = buffer.get(bgRIdx + 1) & 0xFF;
                int bgRB = buffer.get(bgRIdx + 2) & 0xFF;

                float rowMin = Float.MAX_VALUE;
                float rowMax = -1.0f;
                float movMin = Float.MAX_VALUE;
                float movMax = -1.0f;
                int movCount = 0;
                int sumR = 0, sumG = 0, sumB = 0, blockCount = 0;

                for (int cIdx = 0; cIdx < GRID_COLS; cIdx++) {
                    float normCol = cIdx / (float) (GRID_COLS - 1);
                    int x = scanStartX + Math.round(normCol * (scanEndX - scanStartX));
                    int pxIdx = rowOffset + (x * pixelStride);

                    int r = buffer.get(pxIdx) & 0xFF;
                    int g = buffer.get(pxIdx + 1) & 0xFF;
                    int b = buffer.get(pxIdx + 2) & 0xFF;

                    int cellBase = ((rIdx * GRID_COLS) + cIdx) * 3;
                    gridRgbCurrent[cellBase] = (short) r;
                    gridRgbCurrent[cellBase + 1] = (short) g;
                    gridRgbCurrent[cellBase + 2] = (short) b;

                    boolean isBlock = isBlockPixel2D(
                            r, g, b, bgLR, bgLG, bgLB, bgRR, bgRG, bgRB, colorDiffThreshold);

                    if (isBlock) {
                        if (x < rowMin) rowMin = x;
                        if (x > rowMax) rowMax = x;
                        sumR += r; sumG += g; sumB += b;
                        blockCount++;

                        if (hasHistory) {
                            int pr = gridRgbPrev[cellBase];
                            int pg = gridRgbPrev[cellBase + 1];
                            int pb = gridRgbPrev[cellBase + 2];
                            int tempDiff = Math.abs(r - pr) + Math.abs(g - pg) + Math.abs(b - pb);
                            if (tempDiff >= TEMPORAL_DIFF_THRESHOLD) {
                                if (x < movMin) movMin = x;
                                if (x > movMax) movMax = x;
                                movCount++;
                            }
                        }
                    }
                }

                if (blockCount >= 4 && (rowMax - rowMin) >= minSlabWidthPx) {
                    rowBlockMinX[rIdx] = rowMin;
                    rowBlockMaxX[rIdx] = rowMax;
                    rowMeanR[rIdx] = sumR / blockCount;
                    rowMeanG[rIdx] = sumG / blockCount;
                    rowMeanB[rIdx] = sumB / blockCount;

                    if (movCount >= 2 && (movMax - movMin) >= (minSlabWidthPx * 0.45f)) {
                        rowHasMovement[rIdx] = true;
                        rowMovingMinX[rIdx] = movMin;
                        rowMovingMaxX[rIdx] = movMax;
                    }
                }
            }

            capturedFrames++;

            long nowUptime = SystemClock.uptimeMillis();
            boolean inSettleWindow = (nowUptime < settleUntilUptimeMs);

            // 3. Localizar la Cima Estacionaria 2D de la Torre (baseMinX, baseMaxX, baseCrownY)
            int stationaryTopRow = -1;
            for (int rIdx = 0; rIdx < GRID_ROWS; rIdx++) {
                if (rowBlockMinX[rIdx] > 0.0f && !rowHasMovement[rIdx]) {
                    if (rIdx + 1 < GRID_ROWS && rowBlockMinX[rIdx + 1] > 0.0f && !rowHasMovement[rIdx + 1]) {
                        stationaryTopRow = rIdx;
                        break;
                    }
                }
            }

            if (stationaryTopRow >= 0 && (!inSettleWindow || trackedBaseCenterX < 0.0f)) {
                int crownRow = stationaryTopRow;
                float maxCrownSpan = rowBlockMaxX[stationaryTopRow] - rowBlockMinX[stationaryTopRow];
                int topR = rowMeanR[stationaryTopRow];
                int topG = rowMeanG[stationaryTopRow];
                int topB = rowMeanB[stationaryTopRow];

                int searchLimitRow = Math.min(GRID_ROWS - 1, stationaryTopRow + 11);
                for (int rIdx = stationaryTopRow + 1; rIdx <= searchLimitRow; rIdx++) {
                    if (rowBlockMinX[rIdx] <= 0.0f || rowHasMovement[rIdx]) {
                        continue;
                    }
                    int delta = Math.abs(rowMeanR[rIdx] - topR)
                            + Math.abs(rowMeanG[rIdx] - topG)
                            + Math.abs(rowMeanB[rIdx] - topB);
                    if (delta > 80) {
                        break;
                    }
                    float span = rowBlockMaxX[rIdx] - rowBlockMinX[rIdx];
                    if (span >= maxCrownSpan - 4.0f) {
                        maxCrownSpan = span;
                        crownRow = rIdx;
                    }
                }

                int crownY = roiTopY + Math.round((crownRow / (float) (GRID_ROWS - 1)) * (roiBottomY - roiTopY));
                int topY = roiTopY + Math.round((stationaryTopRow / (float) (GRID_ROWS - 1)) * (roiBottomY - roiTopY));

                float exactBaseMinX = rowBlockMinX[crownRow];
                float exactBaseMaxX = rowBlockMaxX[crownRow];
                float exactBaseWidth = exactBaseMaxX - exactBaseMinX;
                float exactBaseCenter = (exactBaseMinX + exactBaseMaxX) * 0.5f;

                // CANDADO DE SEGURIDAD (Sanity Clamp): 0.25f * W <= baseCenter <= 0.75f * W y baseWidth >= 0.12f * W
                boolean satisfiesSanityClamp = (exactBaseWidth >= width * 0.12f)
                        && (exactBaseCenter >= width * 0.25f)
                        && (exactBaseCenter <= width * 0.75f);

                if (satisfiesSanityClamp) {
                    if (needsBaseRecapture || trackedBaseCenterX < 0.0f) {
                        trackedBaseMinX = exactBaseMinX;
                        trackedBaseMaxX = exactBaseMaxX;
                        trackedBaseCenterX = exactBaseCenter;
                        trackedBaseWidth = exactBaseWidth;
                        trackedBaseCrownY = crownY;
                        trackedTowerTopY = topY;
                        baseScanYNorm = clamp(crownY / (float) height, MIN_VALID_SCAN_Y_NORM + 0.03f, MAX_VALID_SCAN_Y_NORM);
                        movingScanYNorm = clamp(baseScanYNorm - 0.045f, MIN_VALID_SCAN_Y_NORM, baseScanYNorm - 0.02f);

                        if (!inSettleWindow) {
                            System.arraycopy(gridRgbCurrent, 0, gridRgbSettled, 0, gridRgbCurrent.length);
                            hasSettledReference = true;
                            needsBaseRecapture = false;
                        }
                    } else if (!referenceLockActive) {
                        trackedBaseMinX = (trackedBaseMinX * 0.70f) + (exactBaseMinX * 0.30f);
                        trackedBaseMaxX = (trackedBaseMaxX * 0.70f) + (exactBaseMaxX * 0.30f);
                        trackedBaseCenterX = (trackedBaseMinX + trackedBaseMaxX) * 0.5f;
                        trackedBaseWidth = trackedBaseMaxX - trackedBaseMinX;
                        trackedBaseCrownY = Math.round((trackedBaseCrownY * 0.70f) + (crownY * 0.30f));
                        trackedTowerTopY = Math.round((trackedTowerTopY * 0.70f) + (topY * 0.30f));
                    }
                }
            }

            // Si el fotograma tiene datos localizados en las filas específicas (como en calibración o tests),
            // muestreamos directamente las filas exactas de baseScanYNorm y movingScanYNorm
            int exactBaseY = clampInt(Math.round(baseScanYNorm * height), 8, height - 9);
            int exactMovingY = clampInt(Math.round(movingScanYNorm * height), 8, exactBaseY - 4);

            float[] directBase = scanSingleRowEdges(buffer, bufferLimit, rowStride, pixelStride, exactBaseY, scanStartX, scanEndX, skyLeftX, skyRightX);
            if (directBase != null && (directBase[1] - directBase[0]) >= minSlabWidthPx) {
                float center = (directBase[0] + directBase[1]) * 0.5f;
                if (center >= width * 0.25f && center <= width * 0.75f) {
                    trackedBaseMinX = directBase[0];
                    trackedBaseMaxX = directBase[1];
                    trackedBaseCenterX = center;
                    trackedBaseWidth = directBase[1] - directBase[0];
                    trackedBaseCrownY = exactBaseY;
                    trackedTowerTopY = exactBaseY;
                }
            }

            // Fallback con candado de seguridad de fábrica si la base aún no fue adquirida
            if (trackedBaseCenterX < 0.0f) {
                trackedBaseMinX = 0.145f * width;
                trackedBaseMaxX = 0.915f * width;
                trackedBaseCenterX = (trackedBaseMinX + trackedBaseMaxX) * 0.5f;
                trackedBaseWidth = trackedBaseMaxX - trackedBaseMinX;
                trackedBaseCrownY = exactBaseY;
                trackedTowerTopY = exactBaseY;
            }

            reusableResult.baseDetected = true;
            reusableResult.towerTopY = trackedTowerTopY;
            reusableResult.baseCrownY = trackedBaseCrownY;
            reusableResult.baseScanY = trackedBaseCrownY;
            reusableResult.baseMinX = trackedBaseMinX;
            reusableResult.baseMaxX = trackedBaseMaxX;
            reusableResult.baseLeftX = trackedBaseMinX;
            reusableResult.baseRightX = trackedBaseMaxX;
            reusableResult.baseWidth = trackedBaseWidth;
            reusableResult.baseCenterX = trackedBaseCenterX;
            reusableResult.detectedBaseCenterX = trackedBaseCenterX;

            // 4. Extracción de Extremos 2D Globales [movingMinX, movingMaxX] de la Losa Móvil
            float globalMovMinX = Float.MAX_VALUE;
            float globalMovMaxX = -1.0f;
            int movRowCount = 0;
            int movRowYSum = 0;

            for (int rIdx = 0; rIdx < GRID_ROWS; rIdx++) {
                float normRow = rIdx / (float) (GRID_ROWS - 1);
                int y = roiTopY + Math.round(normRow * (roiBottomY - roiTopY));
                if (rowBlockMinX[rIdx] <= 0.0f) {
                    continue;
                }

                float rCenter = (rowBlockMinX[rIdx] + rowBlockMaxX[rIdx]) * 0.5f;
                boolean isMovingPixelRow = rowHasMovement[rIdx];
                boolean isAboveTowerTop = (trackedTowerTopY > 0 && y < trackedTowerTopY - 6);
                boolean isShiftedFromCenter = Math.abs(rCenter - trackedBaseCenterX) > 6.0f;

                if (isMovingPixelRow || isAboveTowerTop || (y < trackedBaseCrownY - 6 && isShiftedFromCenter)) {
                    float left = (rowMovingMinX[rIdx] > 0.0f) ? rowMovingMinX[rIdx] : rowBlockMinX[rIdx];
                    float right = (rowMovingMaxX[rIdx] > 0.0f) ? rowMovingMaxX[rIdx] : rowBlockMaxX[rIdx];

                    if (left < globalMovMinX) globalMovMinX = left;
                    if (right > globalMovMaxX) globalMovMaxX = right;
                    movRowYSum += y;
                    movRowCount++;
                }
            }

            if (movRowCount > 0 && (globalMovMaxX - globalMovMinX) >= minSlabWidthPx) {
                // Si la losa se superpone con la torre en Y, preservamos el ancho geométrico base
                float rawSpan = globalMovMaxX - globalMovMinX;
                if (trackedBaseWidth > minSlabWidthPx && rawSpan > trackedBaseWidth * 1.15f) {
                    float rawCenter = (globalMovMinX + globalMovMaxX) * 0.5f;
                    if (rawCenter < trackedBaseCenterX) {
                        globalMovMaxX = globalMovMinX + trackedBaseWidth;
                    } else {
                        globalMovMinX = globalMovMaxX - trackedBaseWidth;
                    }
                }

                int movY = movRowYSum / movRowCount;
                reusableResult.movingDetected = true;
                reusableResult.movingCrownY = movY;
                reusableResult.movingScanY = movY;
                reusableResult.movingMinX = globalMovMinX;
                reusableResult.movingMaxX = globalMovMaxX;
                reusableResult.movingLeftX = globalMovMinX;
                reusableResult.movingRightX = globalMovMaxX;
                reusableResult.movingWidth = globalMovMaxX - globalMovMinX;
                reusableResult.movingCenterX = (globalMovMinX + globalMovMaxX) * 0.5f;
            }

            if (!reusableResult.movingDetected) {
                float[] directMov = scanSingleRowEdges(buffer, bufferLimit, rowStride, pixelStride, exactMovingY, scanStartX, scanEndX, skyLeftX, skyRightX);
                if (directMov != null && (directMov[1] - directMov[0]) >= minSlabWidthPx) {
                    reusableResult.movingDetected = true;
                    reusableResult.movingCrownY = exactMovingY;
                    reusableResult.movingScanY = exactMovingY;
                    reusableResult.movingMinX = directMov[0];
                    reusableResult.movingMaxX = directMov[1];
                    reusableResult.movingLeftX = directMov[0];
                    reusableResult.movingRightX = directMov[1];
                    reusableResult.movingWidth = directMov[1] - directMov[0];
                    reusableResult.movingCenterX = (directMov[0] + directMov[1]) * 0.5f;
                }
            }

            // 5. Centro objetivo y deltas de bordes
            float targetCenter = manualTargetXNorm * width;
            if (!autoBaseMode) {
                reusableResult.effectiveTargetCenterX = targetCenter;
                reusableResult.isReferenceLocked = true;
            } else if (referenceLockActive && lockedTargetCenterX > 0.0f) {
                reusableResult.effectiveTargetCenterX = lockedTargetCenterX;
                reusableResult.isReferenceLocked = true;
            } else {
                reusableResult.effectiveTargetCenterX = reusableResult.baseCenterX;
                reusableResult.isReferenceLocked = false;
            }

            if (reusableResult.movingDetected && reusableResult.baseDetected) {
                reusableResult.centerErrorPx = reusableResult.movingCenterX - reusableResult.effectiveTargetCenterX;
                reusableResult.leftEdgeDeltaPx = reusableResult.movingMinX - reusableResult.baseMinX;
                reusableResult.rightEdgeDeltaPx = reusableResult.movingMaxX - reusableResult.baseMaxX;
            }

            // 6. Detección de botón "Tap to play" en pantalla de inicio si no hay losa
            if (!reusableResult.movingDetected) {
                detectTapToPlayButtonSafe(buffer, bufferLimit, width, height, rowStride, pixelStride, reusableResult);
            }

        } catch (Throwable t) {
            // Protección anti-crash completa
            reusableResult.reset();
        }

        reusableResult.processingTimeMs = (System.nanoTime() - startNs) / 1_000_000.0f;
        return reusableResult;
    }

    /**
     * Valida si la pantalla actual pertenece al juego activo buscando el cartel verde
     * superior "$100 GUARANTEED" (G > R + 25 y G > B + 20) o bloques en la torre,
     * detectando si apareció un anuncio externo (ej. pantalla blanca publicitaria).
     */
    private boolean verifyGameScreenActive(
            ByteBuffer buffer,
            int bufferLimit,
            int width,
            int height,
            int rowStride,
            int pixelStride) {

        try {
            int topY = Math.round(BANNER_TOP_Y_NORM * height);
            int bottomY = Math.round(BANNER_BOTTOM_Y_NORM * height);
            int startX = Math.round(BANNER_LEFT_X_NORM * width);
            int endX = Math.round(BANNER_RIGHT_X_NORM * width);

            int greenCount = 0;
            int whiteAdCount = 0;
            int sampleCount = 0;

            for (int y = topY; y <= bottomY; y += 12) {
                int rowOffset = y * rowStride;
                if (rowOffset < 0 || rowOffset + (endX * pixelStride) + 3 >= bufferLimit) {
                    continue;
                }
                for (int x = startX; x <= endX; x += 16) {
                    int idx = rowOffset + (x * pixelStride);
                    int r = buffer.get(idx) & 0xFF;
                    int g = buffer.get(idx + 1) & 0xFF;
                    int b = buffer.get(idx + 2) & 0xFF;

                    sampleCount++;
                    // Cartel verde "$100 GUARANTEED"
                    if (g > r + 25 && g > b + 20) {
                        greenCount++;
                    }
                    // Pantalla blanca de anuncio publicitario
                    if (r > 240 && g > 240 && b > 240) {
                        whiteAdCount++;
                    }
                }
            }

            // Si más del 85% de la zona superior es blanco puro plano sin elementos del juego -> Anuncio Temu
            if (sampleCount > 10 && whiteAdCount >= (sampleCount * 0.88f)) {
                return false;
            }

            // Si se detectaron píxeles verdes característicos del cartel, es 100% el juego
            if (greenCount >= 4) {
                return true;
            }

            // Si no se ven píxeles verdes en la muestra superior, verificar que haya contraste en la torre
            int midY = Math.round(0.55f * height);
            int midOffset = midY * rowStride;
            if (midOffset >= 0 && midOffset + (width * pixelStride) <= bufferLimit) {
                int towerContrastSamples = 0;
                for (int x = Math.round(width * 0.2f); x <= Math.round(width * 0.8f); x += 24) {
                    int idx = midOffset + (x * pixelStride);
                    int r = buffer.get(idx) & 0xFF;
                    int g = buffer.get(idx + 1) & 0xFF;
                    int b = buffer.get(idx + 2) & 0xFF;
                    int chroma = Math.max(r, Math.max(g, b)) - Math.min(r, Math.min(g, b));
                    if (chroma >= 20) {
                        towerContrastSamples++;
                    }
                }
                if (towerContrastSamples >= 3) {
                    return true;
                }
            }

            return true;
        } catch (Throwable t) {
            return true;
        }
    }

    /**
     * Clasifica un píxel como perteneciente a un bloque 3D (Cara superior/lateral de cualquier color):
     * - Croma / saturación de bloque (max - min >= 22).
     * - No es blanco puro de anuncio ni gris neutro de suelo (max - min < 18).
     * - Difiere del cielo lateral en esa misma fila Y.
     */
    private static boolean isBlockPixel2D(
            int r, int g, int b,
            int bgLR, int bgLG, int bgLB,
            int bgRR, int bgRG, int bgRB,
            int threshold) {

        int max = Math.max(r, Math.max(g, b));
        int min = Math.min(r, Math.min(g, b));
        int chroma = max - min;

        // 1. Descartar suelo gris neutro y nubes blancas
        if (chroma < 18) {
            return false;
        }

        // 2. Descartar blancos puros de anuncios
        if (min > 235) {
            return false;
        }

        // 3. Descartar la sombra lateral derecha muy oscura
        if (max < 140 && r < 128) {
            return false;
        }

        // 4. Comparar contra el cielo de fondo lateral
        int diffL = Math.abs(r - bgLR) + Math.abs(g - bgLG) + Math.abs(b - bgLB);
        int diffR = Math.abs(r - bgRR) + Math.abs(g - bgRG) + Math.abs(b - bgRB);
        int minDiff = Math.min(diffL, diffR);

        return minDiff >= threshold || chroma >= 36;
    }

    private void detectTapToPlayButtonSafe(
            ByteBuffer buffer,
            int bufferLimit,
            int width,
            int height,
            int rowStride,
            int pixelStride,
            ScanResult outResult) {

        try {
            int btnY = Math.round(0.81f * height);
            int rowOffset = btnY * rowStride;
            int centerX = width / 2;
            if (rowOffset < 0 || rowOffset + ((centerX + 40) * pixelStride) + 3 >= bufferLimit) {
                return;
            }

            int purpleCount = 0;
            for (int dx = -40; dx <= 40; dx += 10) {
                int idx = rowOffset + ((centerX + dx) * pixelStride);
                int r = buffer.get(idx) & 0xFF;
                int g = buffer.get(idx + 1) & 0xFF;
                int b = buffer.get(idx + 2) & 0xFF;
                if (b > 140 && r > 90 && g < 110 && (b - g) > 45) {
                    purpleCount++;
                }
            }
            if (purpleCount >= 6) {
                outResult.tapToPlayButtonDetected = true;
                outResult.tapToPlayCenterX = centerX;
                outResult.tapToPlayCenterY = btnY;
            }
        } catch (Throwable ignored) {
        }
    }

    private static float[] scanSingleRowEdges(
            ByteBuffer buffer,
            int bufferLimit,
            int rowStride,
            int pixelStride,
            int y,
            int startX,
            int endX,
            int skyLeftX,
            int skyRightX) {

        for (int dy : new int[]{0, -3, 3, -1, 1, -2, 2}) {
            int sampleY = y + dy;
            int rowOffset = sampleY * rowStride;
            if (rowOffset < 0 || rowOffset + (skyRightX * pixelStride) + 3 >= bufferLimit) {
                continue;
            }

            int bgLIdx = rowOffset + (skyLeftX * pixelStride);
            int bgRIdx = rowOffset + (skyRightX * pixelStride);
            int bgLR = buffer.get(bgLIdx) & 0xFF;
            int bgLG = buffer.get(bgLIdx + 1) & 0xFF;
            int bgLB = buffer.get(bgLIdx + 2) & 0xFF;

            int bgRR = buffer.get(bgRIdx) & 0xFF;
            int bgRG = buffer.get(bgRIdx + 1) & 0xFF;
            int bgRB = buffer.get(bgRIdx + 2) & 0xFF;

            int foundLeft = -1;
            int runLeft = 0;
            for (int x = startX; x <= endX; x += 2) {
                int idx = rowOffset + (x * pixelStride);
                int r = buffer.get(idx) & 0xFF;
                int g = buffer.get(idx + 1) & 0xFF;
                int b = buffer.get(idx + 2) & 0xFF;
                if (isBlockPixel2D(r, g, b, bgLR, bgLG, bgLB, bgRR, bgRG, bgRB, DEFAULT_BG_DIFF_THRESHOLD)) {
                    runLeft += 2;
                    if (runLeft >= 8) {
                        foundLeft = x - runLeft + 2;
                        break;
                    }
                } else {
                    runLeft = 0;
                }
            }
            if (foundLeft < 0) {
                continue;
            }

            int foundRight = -1;
            int runRight = 0;
            for (int x = endX; x >= foundLeft; x -= 2) {
                int idx = rowOffset + (x * pixelStride);
                int r = buffer.get(idx) & 0xFF;
                int g = buffer.get(idx + 1) & 0xFF;
                int b = buffer.get(idx + 2) & 0xFF;
                if (isBlockPixel2D(r, g, b, bgLR, bgLG, bgLB, bgRR, bgRG, bgRB, DEFAULT_BG_DIFF_THRESHOLD)) {
                    runRight += 2;
                    if (runRight >= 8) {
                        foundRight = x + runRight - 2;
                        break;
                    }
                } else {
                    runRight = 0;
                }
            }
            if (foundRight > foundLeft) {
                return new float[]{foundLeft, foundRight};
            }
        }
        return null;
    }

    private static float clamp(float val, float min, float max) {
        return Math.max(min, Math.min(max, val));
    }

    private static int clampInt(int val, int min, int max) {
        return Math.max(min, Math.min(max, val));
    }
}
