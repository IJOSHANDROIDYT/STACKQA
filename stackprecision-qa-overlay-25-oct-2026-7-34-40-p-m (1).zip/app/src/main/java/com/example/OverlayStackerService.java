package com.example;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;

/**
 * Servicio en Primer Plano de Superposición (Overlay) y Captura a 60 FPS (OverlayStackerService).
 * Soluciones implementadas:
 * 1. PROHIBIDO dibujar dentro del área de la torre (Y de 0.32 a 0.80) cuando Auto-Stack está ACTIVO
 *    para erradicar al 100% el bucle de retroalimentación donde la cámara captura el propio dibujo del overlay.
 * 2. Dibuja en su lugar una Regla HUD Horizontal Superior en Y = 0.25f que muestra las marcas verdes
 *    de la base y el bloque cian/amarillo alineándose en tiempo real sin ensuciar la torre.
 * 3. Protección contra Anuncios (ej. Temu): Pausa automática si isGameScreenValid es false.
 * 4. Blindaje Anti-Crash completo con try-catch en todo el ciclo de captura y despacho.
 */
public final class OverlayStackerService extends Service {

    public static final String ACTION_START_OVERLAY = "com.example.action.START_OVERLAY";
    public static final String ACTION_STOP_OVERLAY = "com.example.action.STOP_OVERLAY";
    public static final String EXTRA_RESULT_CODE = "extra_result_code";
    public static final String EXTRA_RESULT_DATA = "extra_result_data";

    public static final String PREFS_NAME = "qa_autostacker_prefs";
    public static final String KEY_BASE_SCAN_Y = "base_scan_y_norm";
    public static final String KEY_MOVING_SCAN_Y = "moving_scan_y_norm";
    public static final String KEY_TARGET_X = "target_x_norm";
    public static final String KEY_LEAD_TIME_MS = "lead_time_ms";
    public static final String KEY_CENTER_OFFSET_PX = "center_offset_px";
    public static final String KEY_AUTO_BASE_MODE = "auto_base_mode";
    public static final String KEY_PANEL_SCALE = "panel_scale";

    private static final String CHANNEL_ID = "qa_autostacker_overlay_channel";
    private static final int NOTIFICATION_ID = 1001;

    private static volatile OverlayStackerService runningInstance;

    private WindowManager windowManager;
    private MediaProjectionManager projectionManager;
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;

    private HandlerThread visionThread;
    private Handler visionHandler;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private final IsometricStackTracker stackTracker = new IsometricStackTracker();
    private final PredictiveTriggerEngine triggerEngine = new PredictiveTriggerEngine();

    private SharedPreferences prefs;
    private int screenWidth;
    private int screenHeight;
    private int screenDensityDpi;

    private volatile boolean autoStackEnabled = false;
    private volatile boolean calibrationMode = false;
    private volatile boolean isMinimizedToPill = false;
    private volatile boolean autoTapToPlayEnabled = true;
    private float panelScaleFactor = 1.0f;
    private long lastTapToPlayUptimeMs = -10_000L;

    // Estado visual sincronizado
    private volatile boolean renderGameValid = true;
    private volatile int renderBaseCrownY = 0;
    private volatile boolean renderBaseDetected = false;
    private volatile float renderBaseMinX = 0.0f;
    private volatile float renderBaseMaxX = 0.0f;
    private volatile float renderTargetCenterX = 0.0f;

    private volatile int renderMovingCrownY = 0;
    private volatile boolean renderMovingDetected = false;
    private volatile float renderMovingMinX = 0.0f;
    private volatile float renderMovingMaxX = 0.0f;
    private volatile float renderMovingCenterX = 0.0f;
    private volatile float renderPredictedX = 0.0f;
    private volatile float renderVelocityPxPerMs = 0.0f;
    private volatile float renderAnalysisTimeMs = 0.0f;
    private volatile long lastShotFlashUptimeMs = 0L;
    private volatile String renderStatusText = "LISTO (60 FPS)";

    private LaserCalibrationView laserCalibrationView;
    private WindowManager.LayoutParams laserLayoutParams;

    private LinearLayout floatingRootContainer;
    private LinearLayout expandedPanelContent;
    private TextView miniPillButton;
    private WindowManager.LayoutParams panelLayoutParams;

    private Button btnToggleAutoStack;
    private Button btnToggleCalibrate;
    private Button btnToggleMode;
    private Button btnAutoAxes;
    private TextView txtLeadTimeValue;
    private TextView txtCenterOffsetValue;
    private TextView txtTelemetryLine;

    public static OverlayStackerService getRunningInstance() {
        return runningInstance;
    }

    public IsometricStackTracker getStackTracker() {
        return stackTracker;
    }

    public PredictiveTriggerEngine getTriggerEngine() {
        return triggerEngine;
    }

    public boolean isAutoStackEnabled() {
        return autoStackEnabled;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        runningInstance = this;
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        updateScreenMetrics();
        loadAndValidateSavedConfiguration();
        startVisionThread();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            if (intent != null && ACTION_STOP_OVERLAY.equals(intent.getAction())) {
                stopSelf();
                return START_NOT_STICKY;
            }

            int resultCode = Activity.RESULT_CANCELED;
            Intent resultData = null;
            if (intent != null) {
                resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
                resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
            }

            boolean hasProjectionPayload = (resultCode == Activity.RESULT_OK && resultData != null);
            promoteToForeground(hasProjectionPayload);

            if (Settings.canDrawOverlays(this)) {
                ensureOverlayViewsCreated();
            }

            if (hasProjectionPayload) {
                startMediaProjectionCapture(resultCode, resultData);
            }
        } catch (Throwable ignored) {
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        try {
            autoStackEnabled = false;
            stopMediaProjectionCapture();
            removeOverlayViews();
            stopVisionThread();
        } catch (Throwable ignored) {
        } finally {
            if (runningInstance == this) {
                runningInstance = null;
            }
            super.onDestroy();
        }
    }

    private void updateScreenMetrics() {
        try {
            DisplayMetrics dm = getResources().getDisplayMetrics();
            if (windowManager != null && windowManager.getDefaultDisplay() != null) {
                windowManager.getDefaultDisplay().getRealMetrics(dm);
            }
            screenWidth = Math.max(320, dm.widthPixels);
            screenHeight = Math.max(480, dm.heightPixels);
            screenDensityDpi = dm.densityDpi;
            renderTargetCenterX = stackTracker.getManualTargetXNorm() * screenWidth;
            renderPredictedX = renderTargetCenterX;
            renderBaseCrownY = Math.round(IsometricStackTracker.DEFAULT_BASE_Y_NORM * screenHeight);
            renderMovingCrownY = Math.round(IsometricStackTracker.DEFAULT_MOVING_Y_NORM * screenHeight);
        } catch (Throwable ignored) {
        }
    }

    private void loadAndValidateSavedConfiguration() {
        try {
            float savedMovingY = prefs.getFloat(KEY_MOVING_SCAN_Y, IsometricStackTracker.DEFAULT_MOVING_Y_NORM);
            float savedBaseY = prefs.getFloat(KEY_BASE_SCAN_Y, IsometricStackTracker.DEFAULT_BASE_Y_NORM);
            float savedTargetX = prefs.getFloat(KEY_TARGET_X, IsometricStackTracker.DEFAULT_FIXED_AXIS_X_NORM);
            float savedLeadMs = prefs.getFloat(KEY_LEAD_TIME_MS, PredictiveTriggerEngine.DEFAULT_LEAD_TIME_MS);
            float savedOffsetPx = prefs.getFloat(KEY_CENTER_OFFSET_PX, PredictiveTriggerEngine.DEFAULT_CENTER_OFFSET_PX);
            panelScaleFactor = prefs.getFloat(KEY_PANEL_SCALE, 1.0f);

            if (!IsometricStackTracker.areSavedAxesValid(savedMovingY, savedBaseY)) {
                savedMovingY = IsometricStackTracker.DEFAULT_MOVING_Y_NORM;
                savedBaseY = IsometricStackTracker.DEFAULT_BASE_Y_NORM;
                savedTargetX = IsometricStackTracker.DEFAULT_FIXED_AXIS_X_NORM;
                savedOffsetPx = 0.0f;
            }

            stackTracker.resetAxesToFactoryDefaults();
            stackTracker.setBaseScanYNorm(savedBaseY);
            stackTracker.setMovingScanYNorm(savedMovingY);
            stackTracker.setManualTargetXNorm(savedTargetX);
            stackTracker.setAutoBaseMode(true);

            triggerEngine.setLeadTimeMs(savedLeadMs);
            triggerEngine.setCenterOffsetPx(savedOffsetPx);

            renderBaseCrownY = Math.round(stackTracker.getBaseScanYNorm() * screenHeight);
            renderMovingCrownY = Math.round(stackTracker.getMovingScanYNorm() * screenHeight);
            renderTargetCenterX = stackTracker.getManualTargetXNorm() * screenWidth;
            renderPredictedX = renderTargetCenterX;

            saveConfigurationToPrefs();
        } catch (Throwable ignored) {
        }
    }

    public void applyFactoryAutoAxesReset() {
        try {
            stackTracker.resetAxesToFactoryDefaults();
            triggerEngine.setCenterOffsetPx(0.0f);
            triggerEngine.resetHistory();

            renderBaseCrownY = Math.round(stackTracker.getBaseScanYNorm() * screenHeight);
            renderMovingCrownY = Math.round(stackTracker.getMovingScanYNorm() * screenHeight);
            renderTargetCenterX = stackTracker.getManualTargetXNorm() * screenWidth;
            renderPredictedX = renderTargetCenterX;
            renderStatusText = "RE-ESCANEO CIMA ACTIVO";

            saveConfigurationToPrefs();
            updateControlButtonsAppearance();
            if (laserCalibrationView != null) {
                laserCalibrationView.invalidate();
            }
            refreshOverlayTelemetryOnMainThread();
        } catch (Throwable ignored) {
        }
    }

    public void saveConfigurationToPrefs() {
        try {
            stackTracker.enforceAntiInversionRule();
            prefs.edit()
                    .putFloat(KEY_MOVING_SCAN_Y, stackTracker.getMovingScanYNorm())
                    .putFloat(KEY_BASE_SCAN_Y, stackTracker.getBaseScanYNorm())
                    .putFloat(KEY_TARGET_X, stackTracker.getManualTargetXNorm())
                    .putFloat(KEY_LEAD_TIME_MS, triggerEngine.getLeadTimeMs())
                    .putFloat(KEY_CENTER_OFFSET_PX, triggerEngine.getCenterOffsetPx())
                    .putBoolean(KEY_AUTO_BASE_MODE, stackTracker.isAutoBaseMode())
                    .putFloat(KEY_PANEL_SCALE, panelScaleFactor)
                    .apply();
        } catch (Throwable ignored) {
        }
    }

    private void promoteToForeground(boolean withMediaProjectionType) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID,
                        "QA Auto-Stacker 60FPS Service",
                        NotificationManager.IMPORTANCE_LOW);
                channel.setDescription("Rastreo 2D de extremos y predicción de impacto");
                nm.createNotificationChannel(channel);
            }

            Intent openAppIntent = new Intent(this, MainActivity.class);
            PendingIntent pendingOpen = PendingIntent.getActivity(
                    this,
                    0,
                    openAppIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Notification.Builder builder = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    ? new Notification.Builder(this, CHANNEL_ID)
                    : new Notification.Builder(this);

            Notification notification = builder
                    .setContentTitle("QA Auto-Stacker 60 FPS Activo")
                    .setContentText("HUD Superior (Sin interferencia sobre la torre)")
                    .setSmallIcon(android.R.drawable.ic_menu_compass)
                    .setContentIntent(pendingOpen)
                    .setOngoing(true)
                    .build();

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && withMediaProjectionType) {
                startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                startForeground(NOTIFICATION_ID, notification);
            }
        } catch (Throwable ignored) {
        }
    }

    private void startVisionThread() {
        try {
            if (visionThread != null) {
                return;
            }
            visionThread = new HandlerThread(
                    "QAStackerByteBuffer60FPS",
                    Process.THREAD_PRIORITY_URGENT_DISPLAY);
            visionThread.start();
            visionHandler = new Handler(visionThread.getLooper());
        } catch (Throwable ignored) {
        }
    }

    private void stopVisionThread() {
        try {
            if (visionThread != null) {
                visionThread.quitSafely();
                visionThread = null;
                visionHandler = null;
            }
        } catch (Throwable ignored) {
        }
    }

    private void startMediaProjectionCapture(int resultCode, Intent resultData) {
        try {
            stopMediaProjectionCapture();
            if (projectionManager == null) {
                return;
            }
            updateScreenMetrics();
            mediaProjection = projectionManager.getMediaProjection(resultCode, resultData);
            if (mediaProjection == null) {
                return;
            }

            mediaProjection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    mainHandler.post(() -> stopMediaProjectionCapture());
                }
            }, mainHandler);

            imageReader = ImageReader.newInstance(
                    screenWidth,
                    screenHeight,
                    PixelFormat.RGBA_8888,
                    2);

            imageReader.setOnImageAvailableListener(reader -> {
                Image image = null;
                try {
                    image = reader.acquireLatestImage();
                    if (image != null) {
                        processCapturedFrame(image);
                    }
                } catch (Throwable ignored) {
                } finally {
                    if (image != null) {
                        try {
                            image.close();
                        } catch (Throwable ignored) {
                        }
                    }
                }
            }, visionHandler);

            virtualDisplay = mediaProjection.createVirtualDisplay(
                    "QAStacker60FPSDisplay",
                    screenWidth,
                    screenHeight,
                    screenDensityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.getSurface(),
                    null,
                    visionHandler);

            renderStatusText = "CAPTURA 60FPS ACTIVA";
            refreshOverlayTelemetryOnMainThread();
        } catch (Throwable e) {
            renderStatusText = "MODO SIMULADOR / CALIBRACIÓN";
            refreshOverlayTelemetryOnMainThread();
        }
    }

    private void stopMediaProjectionCapture() {
        try {
            if (virtualDisplay != null) {
                virtualDisplay.release();
                virtualDisplay = null;
            }
            if (imageReader != null) {
                imageReader.setOnImageAvailableListener(null, null);
                imageReader.close();
                imageReader = null;
            }
            if (mediaProjection != null) {
                mediaProjection.stop();
                mediaProjection = null;
            }
        } catch (Throwable ignored) {
        }
    }

    private void processCapturedFrame(Image image) {
        try {
            IsometricStackTracker.ScanResult scan = stackTracker.processImage(image);
            handleScanAndPrediction(scan);
        } catch (Throwable ignored) {
        }
    }

    public void onExternalByteBufferFrameProcessed(IsometricStackTracker.ScanResult scan) {
        handleScanAndPrediction(scan);
    }

    private void handleScanAndPrediction(IsometricStackTracker.ScanResult scan) {
        try {
            if (scan == null || !scan.validFrame) {
                return;
            }

            renderGameValid = scan.isGameScreenValid;

            // Protección contra Anuncios (ej. Temu): Pausar disparos si la pantalla no es del juego
            if (!scan.isGameScreenValid) {
                renderStatusText = "ANUNCIO / PANTALLA NO VÁLIDA (PAUSADO)";
                if (laserCalibrationView != null) {
                    laserCalibrationView.postInvalidateOnAnimation();
                }
                refreshOverlayTelemetryOnMainThread();
                return;
            }

            PredictiveTriggerEngine.PredictionDecision decision = triggerEngine.evaluateFrame(
                    scan.movingDetected,
                    scan.movingCenterX,
                    scan.effectiveTargetCenterX,
                    scan.timestampNs,
                    autoStackEnabled);

            if (decision.shouldFire && autoStackEnabled) {
                if (decision.subFrameWaitNanos > 0L) {
                    PredictiveTriggerEngine.executeSubFrameSleepIfNeeded(decision.subFrameWaitNanos);
                }
                TapAccessibilityService.dispatchGlobalOrLocalSafeTap(scan.frameWidth, scan.frameHeight);
                stackTracker.notifyShotFired(240L);
                lastShotFlashUptimeMs = SystemClock.uptimeMillis();
            } else if (autoStackEnabled && autoTapToPlayEnabled && scan.tapToPlayButtonDetected) {
                long nowMs = SystemClock.uptimeMillis();
                if (nowMs - lastTapToPlayUptimeMs > 1500L) {
                    lastTapToPlayUptimeMs = nowMs;
                    TapAccessibilityService service = TapAccessibilityService.getInstance();
                    if (service != null) {
                        service.performUltraFastTap(scan.tapToPlayCenterX, scan.tapToPlayCenterY);
                    }
                    stackTracker.notifyShotFired(300L);
                }
            }

            renderBaseCrownY = scan.baseCrownY;
            renderBaseDetected = scan.baseDetected;
            renderBaseMinX = scan.baseMinX;
            renderBaseMaxX = scan.baseMaxX;
            renderTargetCenterX = scan.effectiveTargetCenterX;

            renderMovingCrownY = scan.movingCrownY;
            renderMovingDetected = scan.movingDetected;
            renderMovingMinX = scan.movingMinX;
            renderMovingMaxX = scan.movingMaxX;
            renderMovingCenterX = scan.movingCenterX;
            renderPredictedX = decision.predictedX;
            renderVelocityPxPerMs = decision.velocityPxPerMs;
            renderAnalysisTimeMs = scan.processingTimeMs;

            switch (decision.state) {
                case IMMEDIATE_FIRED:
                    renderStatusText = "PERFECT SNAP ⚡";
                    break;
                case WAIT_AND_SNAP_FIRED:
                    renderStatusText = "WAIT & SNAP 🎯";
                    break;
                case COOLDOWN:
                    renderStatusText = "RE-CAPTURA BASE (240ms)";
                    break;
                case TRACKING:
                    renderStatusText = String.format(Locale.US, "VX: %+.2f px/ms", decision.velocityPxPerMs);
                    break;
                case SEARCHING:
                default:
                    renderStatusText = "BUSCANDO LOSA";
                    break;
            }

            if (laserCalibrationView != null) {
                laserCalibrationView.postInvalidateOnAnimation();
            }
            refreshOverlayTelemetryOnMainThread();
        } catch (Throwable ignored) {
        }
    }

    private void ensureOverlayViewsCreated() {
        try {
            if (windowManager == null) {
                return;
            }
            int overlayType = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;

            if (laserCalibrationView == null) {
                laserCalibrationView = new LaserCalibrationView(this);
                laserLayoutParams = new WindowManager.LayoutParams(
                        WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.MATCH_PARENT,
                        overlayType,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                        PixelFormat.TRANSLUCENT);
                laserLayoutParams.gravity = Gravity.TOP | Gravity.START;
                windowManager.addView(laserCalibrationView, laserLayoutParams);
            }

            if (floatingRootContainer == null) {
                buildFloatingControlPanel(overlayType);
            }
        } catch (Throwable ignored) {
        }
    }

    private void removeOverlayViews() {
        try {
            if (windowManager == null) {
                return;
            }
            if (laserCalibrationView != null) {
                windowManager.removeView(laserCalibrationView);
                laserCalibrationView = null;
            }
            if (floatingRootContainer != null) {
                windowManager.removeView(floatingRootContainer);
                floatingRootContainer = null;
            }
        } catch (Throwable ignored) {
        }
    }

    private void setCalibrationTouchMode(boolean interactive) {
        try {
            this.calibrationMode = interactive;
            if (laserCalibrationView != null && laserLayoutParams != null && windowManager != null) {
                if (interactive) {
                    laserLayoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
                } else {
                    stackTracker.enforceAntiInversionRule();
                    laserLayoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
                    saveConfigurationToPrefs();
                }
                windowManager.updateViewLayout(laserCalibrationView, laserLayoutParams);
                laserCalibrationView.invalidate();
            }
            updateControlButtonsAppearance();
        } catch (Throwable ignored) {
        }
    }

    private void buildFloatingControlPanel(int overlayType) {
        try {
            floatingRootContainer = new LinearLayout(this);
            floatingRootContainer.setOrientation(LinearLayout.VERTICAL);

            GradientDrawable panelBg = new GradientDrawable();
            panelBg.setColor(Color.argb(232, 15, 23, 42));
            panelBg.setCornerRadius(dpToPx(14));
            panelBg.setStroke(dpToPx(1), Color.argb(180, 56, 189, 248));
            floatingRootContainer.setBackground(panelBg);
            int pad = dpToPx(8);
            floatingRootContainer.setPadding(pad, pad, pad, pad);

            miniPillButton = new TextView(this);
            miniPillButton.setText("⚡ QA 60FPS [ABRIR]");
            miniPillButton.setTextColor(Color.parseColor("#38BDF8"));
            miniPillButton.setTypeface(Typeface.DEFAULT_BOLD);
            miniPillButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            miniPillButton.setPadding(dpToPx(10), dpToPx(6), dpToPx(10), dpToPx(6));
            miniPillButton.setVisibility(View.GONE);
            miniPillButton.setOnClickListener(v -> setMinimizedToPill(false));
            floatingRootContainer.addView(miniPillButton);

            expandedPanelContent = new LinearLayout(this);
            expandedPanelContent.setOrientation(LinearLayout.VERTICAL);
            floatingRootContainer.addView(expandedPanelContent);

            LinearLayout headerRow = new LinearLayout(this);
            headerRow.setOrientation(LinearLayout.HORIZONTAL);
            headerRow.setGravity(Gravity.CENTER_VERTICAL);

            TextView titleView = new TextView(this);
            titleView.setText("⋮⋮ QA STACKER 60FPS");
            titleView.setTextColor(Color.WHITE);
            titleView.setTypeface(Typeface.DEFAULT_BOLD);
            titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
            headerRow.addView(titleView, titleLp);

            Button btnSmaller = createMiniHeaderButton("[-]", v -> adjustPanelScale(-0.10f));
            Button btnLarger = createMiniHeaderButton("[+]", v -> adjustPanelScale(+0.10f));
            Button btnMinimize = createMiniHeaderButton("[_]", v -> setMinimizedToPill(true));
            Button btnClose = createMiniHeaderButton("[X]", v -> stopSelf());

            headerRow.addView(btnSmaller);
            headerRow.addView(btnLarger);
            headerRow.addView(btnMinimize);
            headerRow.addView(btnClose);
            expandedPanelContent.addView(headerRow);

            txtTelemetryLine = new TextView(this);
            txtTelemetryLine.setTextColor(Color.parseColor("#A7F3D0"));
            txtTelemetryLine.setTypeface(Typeface.MONOSPACE);
            txtTelemetryLine.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
            txtTelemetryLine.setPadding(0, dpToPx(3), 0, dpToPx(4));
            expandedPanelContent.addView(txtTelemetryLine);

            LinearLayout primaryRow = new LinearLayout(this);
            primaryRow.setOrientation(LinearLayout.HORIZONTAL);

            btnToggleAutoStack = createActionPillButton("Auto-Stack: OFF", v -> {
                autoStackEnabled = !autoStackEnabled;
                triggerEngine.resetHistory();
                if (autoStackEnabled) {
                    stackTracker.notifyShotFired(180L);
                }
                updateControlButtonsAppearance();
                if (laserCalibrationView != null) {
                    laserCalibrationView.invalidate();
                }
            });
            btnToggleCalibrate = createActionPillButton("Calibrar Ejes", v -> {
                setCalibrationTouchMode(!calibrationMode);
            });

            LinearLayout.LayoutParams halfLp = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
            halfLp.setMargins(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2));
            primaryRow.addView(btnToggleAutoStack, halfLp);
            primaryRow.addView(btnToggleCalibrate, halfLp);
            expandedPanelContent.addView(primaryRow);

            LinearLayout leadRow = new LinearLayout(this);
            leadRow.setOrientation(LinearLayout.HORIZONTAL);
            leadRow.setGravity(Gravity.CENTER_VERTICAL);

            Button btnLeadMinus = createStepButton("-2ms", v -> {
                triggerEngine.adjustLeadTimeMs(-2.0f);
                saveConfigurationToPrefs();
                updateControlButtonsAppearance();
            });
            txtLeadTimeValue = new TextView(this);
            txtLeadTimeValue.setGravity(Gravity.CENTER);
            txtLeadTimeValue.setTextColor(Color.WHITE);
            txtLeadTimeValue.setTypeface(Typeface.DEFAULT_BOLD);
            txtLeadTimeValue.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            Button btnLeadPlus = createStepButton("+2ms", v -> {
                triggerEngine.adjustLeadTimeMs(+2.0f);
                saveConfigurationToPrefs();
                updateControlButtonsAppearance();
            });

            leadRow.addView(btnLeadMinus);
            leadRow.addView(txtLeadTimeValue, new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));
            leadRow.addView(btnLeadPlus);
            expandedPanelContent.addView(leadRow);

            LinearLayout offsetRow = new LinearLayout(this);
            offsetRow.setOrientation(LinearLayout.HORIZONTAL);
            offsetRow.setGravity(Gravity.CENTER_VERTICAL);

            Button btnOffsetLeft = createStepButton("◀ -2px", v -> {
                triggerEngine.adjustCenterOffsetPx(-2.0f);
                saveConfigurationToPrefs();
                updateControlButtonsAppearance();
                if (laserCalibrationView != null) {
                    laserCalibrationView.invalidate();
                }
            });
            txtCenterOffsetValue = new TextView(this);
            txtCenterOffsetValue.setGravity(Gravity.CENTER);
            txtCenterOffsetValue.setTextColor(Color.WHITE);
            txtCenterOffsetValue.setTypeface(Typeface.DEFAULT_BOLD);
            txtCenterOffsetValue.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            Button btnOffsetRight = createStepButton("▶ +2px", v -> {
                triggerEngine.adjustCenterOffsetPx(+2.0f);
                saveConfigurationToPrefs();
                updateControlButtonsAppearance();
                if (laserCalibrationView != null) {
                    laserCalibrationView.invalidate();
                }
            });

            offsetRow.addView(btnOffsetLeft);
            offsetRow.addView(txtCenterOffsetValue, new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));
            offsetRow.addView(btnOffsetRight);
            expandedPanelContent.addView(offsetRow);

            LinearLayout modeRow = new LinearLayout(this);
            modeRow.setOrientation(LinearLayout.HORIZONTAL);

            btnToggleMode = createActionPillButton("Modo: Auto-Base", v -> {
                boolean nextMode = !stackTracker.isAutoBaseMode();
                stackTracker.setAutoBaseMode(nextMode);
                if (nextMode) {
                    stackTracker.unlockReference();
                }
                saveConfigurationToPrefs();
                updateControlButtonsAppearance();
                if (laserCalibrationView != null) {
                    laserCalibrationView.invalidate();
                }
            });

            btnAutoAxes = createActionPillButton("Auto-Ejes", v -> {
                applyFactoryAutoAxesReset();
            });

            LinearLayout.LayoutParams modeLp = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.35f);
            modeLp.setMargins(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2));
            LinearLayout.LayoutParams autoAxesLp = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.85f);
            autoAxesLp.setMargins(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2));

            modeRow.addView(btnToggleMode, modeLp);
            modeRow.addView(btnAutoAxes, autoAxesLp);
            expandedPanelContent.addView(modeRow);

            panelLayoutParams = new WindowManager.LayoutParams(
                    dpToPx(Math.round(256 * panelScaleFactor)),
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    overlayType,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            panelLayoutParams.gravity = Gravity.TOP | Gravity.START;
            panelLayoutParams.x = dpToPx(12);
            panelLayoutParams.y = dpToPx(56);

            attachDragListenerToView(headerRow);
            attachDragListenerToView(miniPillButton);

            updateControlButtonsAppearance();
            refreshOverlayTelemetryOnMainThread();

            windowManager.addView(floatingRootContainer, panelLayoutParams);
        } catch (Throwable ignored) {
        }
    }

    private void attachDragListenerToView(View dragHandle) {
        dragHandle.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (panelLayoutParams == null || windowManager == null) {
                    return false;
                }
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = panelLayoutParams.x;
                        initialY = panelLayoutParams.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = Math.round(event.getRawX() - initialTouchX);
                        int dy = Math.round(event.getRawY() - initialTouchY);
                        if (Math.abs(dx) > 6 || Math.abs(dy) > 6) {
                            moved = true;
                        }
                        panelLayoutParams.x = Math.max(0, Math.min(screenWidth - dpToPx(80), initialX + dx));
                        panelLayoutParams.y = Math.max(0, Math.min(screenHeight - dpToPx(60), initialY + dy));
                        try {
                            windowManager.updateViewLayout(floatingRootContainer, panelLayoutParams);
                        } catch (Throwable ignored) {
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            v.performClick();
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void adjustPanelScale(float delta) {
        panelScaleFactor = Math.max(0.80f, Math.min(1.30f, panelScaleFactor + delta));
        saveConfigurationToPrefs();
        if (floatingRootContainer != null && panelLayoutParams != null && !isMinimizedToPill) {
            panelLayoutParams.width = dpToPx(Math.round(256 * panelScaleFactor));
            floatingRootContainer.setScaleX(panelScaleFactor);
            floatingRootContainer.setScaleY(panelScaleFactor);
            try {
                windowManager.updateViewLayout(floatingRootContainer, panelLayoutParams);
            } catch (Throwable ignored) {
            }
        }
    }

    private void setMinimizedToPill(boolean minimize) {
        this.isMinimizedToPill = minimize;
        if (expandedPanelContent == null || miniPillButton == null || panelLayoutParams == null) {
            return;
        }
        if (minimize) {
            expandedPanelContent.setVisibility(View.GONE);
            miniPillButton.setVisibility(View.VISIBLE);
            String stateTag = autoStackEnabled ? "ON" : "OFF";
            miniPillButton.setText("⚡ QA 60FPS [" + stateTag + "] ▾");
            panelLayoutParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
        } else {
            miniPillButton.setVisibility(View.GONE);
            expandedPanelContent.setVisibility(View.VISIBLE);
            panelLayoutParams.width = dpToPx(Math.round(256 * panelScaleFactor));
        }
        try {
            windowManager.updateViewLayout(floatingRootContainer, panelLayoutParams);
        } catch (Throwable ignored) {
        }
    }

    private void updateControlButtonsAppearance() {
        if (btnToggleAutoStack != null) {
            btnToggleAutoStack.setText(autoStackEnabled ? "Auto-Stack: ON" : "Auto-Stack: OFF");
            styleButtonBackground(
                    btnToggleAutoStack,
                    autoStackEnabled ? Color.parseColor("#059669") : Color.parseColor("#334155"));
        }
        if (btnToggleCalibrate != null) {
            btnToggleCalibrate.setText(calibrationMode ? "Guardar Ejes ✓" : "Calibrar Ejes");
            styleButtonBackground(
                    btnToggleCalibrate,
                    calibrationMode ? Color.parseColor("#D97706") : Color.parseColor("#1E293B"));
        }
        if (txtLeadTimeValue != null) {
            txtLeadTimeValue.setText(String.format(
                    Locale.US,
                    "Anticipación: %.0fms",
                    triggerEngine.getLeadTimeMs()));
        }
        if (txtCenterOffsetValue != null) {
            float off = triggerEngine.getCenterOffsetPx();
            String sign = (off >= 0.0f) ? "+" : "";
            txtCenterOffsetValue.setText(String.format(
                    Locale.US,
                    "Eje X: %s%.0fpx",
                    sign,
                    off));
        }
        if (btnToggleMode != null) {
            boolean autoBase = stackTracker.isAutoBaseMode();
            btnToggleMode.setText(autoBase ? "Modo: Auto-Base" : "Modo: Eje Fijo");
            styleButtonBackground(
                    btnToggleMode,
                    autoBase ? Color.parseColor("#0284C7") : Color.parseColor("#7C3AED"));
        }
        if (btnAutoAxes != null) {
            btnAutoAxes.setText("Auto-Ejes");
            styleButtonBackground(btnAutoAxes, Color.parseColor("#0D9488"));
        }
        if (miniPillButton != null && isMinimizedToPill) {
            miniPillButton.setText("⚡ QA 60FPS [" + (autoStackEnabled ? "ON" : "OFF") + "] ▾");
        }
    }

    private void refreshOverlayTelemetryOnMainThread() {
        mainHandler.post(() -> {
            if (txtTelemetryLine != null) {
                txtTelemetryLine.setText(String.format(
                        Locale.US,
                        "ROI: %.2fms | Shots: %d | %s",
                        renderAnalysisTimeMs,
                        triggerEngine.getTotalShotsFired(),
                        renderStatusText));
            }
        });
    }

    private Button createMiniHeaderButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.parseColor("#E2E8F0"));
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        b.setPadding(dpToPx(6), dpToPx(2), dpToPx(6), dpToPx(2));
        b.setMinimumWidth(0);
        b.setMinWidth(0);
        b.setMinimumHeight(0);
        b.setMinHeight(0);
        styleButtonBackground(b, Color.parseColor("#1E293B"));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dpToPx(2), 0, 0, 0);
        b.setLayoutParams(lp);
        b.setOnClickListener(listener);
        return b;
    }

    private Button createActionPillButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        b.setPadding(dpToPx(6), dpToPx(5), dpToPx(6), dpToPx(5));
        b.setMinimumHeight(0);
        b.setMinHeight(0);
        styleButtonBackground(b, Color.parseColor("#334155"));
        b.setOnClickListener(listener);
        return b;
    }

    private Button createStepButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.parseColor("#38BDF8"));
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        b.setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));
        b.setMinimumWidth(0);
        b.setMinWidth(0);
        b.setMinimumHeight(0);
        b.setMinHeight(0);
        styleButtonBackground(b, Color.parseColor("#0F172A"));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2));
        b.setLayoutParams(lp);
        b.setOnClickListener(listener);
        return b;
    }

    private void styleButtonBackground(View button, int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dpToPx(8));
        bg.setStroke(dpToPx(1), Color.argb(90, 255, 255, 255));
        button.setBackground(bg);
    }

    private int dpToPx(int dp) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp,
                getResources().getDisplayMetrics()));
    }

    /**
     * Lienzo Láser Visualizador:
     * - Cuando Auto-Stack está ACTIVO (autoStackEnabled == true):
     *   PROHIBIDO dibujar en el área de la torre (Y de 0.32f a 0.80f).
     *   Dibuja en su lugar la "Regla HUD Horizontal Superior" limpia en Y = 0.25f * h
     *   para eliminar al 100% cualquier auto-interferencia de la cámara con el propio dibujo.
     * - Cuando Auto-Stack está en pausa (autoStackEnabled == false):
     *   Dibuja las guías completas para inspección y calibración.
     */
    private final class LaserCalibrationView extends View {

        private final Paint rulerBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rulerAxisPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rulerBaseTickPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rulerMovingTickPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rulerPredictedPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rulerLabelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        private final Paint towerGuidePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint towerMovingPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint towerPredictedPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint safeTapZonePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        private final RectF hudRulerRect = new RectF();
        private final RectF towerBoxRect = new RectF();

        private int activeDragTarget = 0;

        LaserCalibrationView(Context context) {
            super(context);

            rulerBgPaint.setColor(Color.argb(210, 15, 23, 42));
            rulerBgPaint.setStyle(Paint.Style.FILL);

            rulerAxisPaint.setColor(Color.parseColor("#475569"));
            rulerAxisPaint.setStrokeWidth(dpToPx(2));

            rulerBaseTickPaint.setColor(Color.parseColor("#00E676"));
            rulerBaseTickPaint.setStrokeWidth(dpToPx(3));

            rulerMovingTickPaint.setColor(Color.parseColor("#00E5FF"));
            rulerMovingTickPaint.setStrokeWidth(dpToPx(3));

            rulerPredictedPaint.setColor(Color.parseColor("#FFEA00"));
            rulerPredictedPaint.setStyle(Paint.Style.FILL);

            rulerLabelPaint.setColor(Color.WHITE);
            rulerLabelPaint.setTextSize(TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_SP, 10, getResources().getDisplayMetrics()));
            rulerLabelPaint.setTypeface(Typeface.MONOSPACE);

            towerGuidePaint.setColor(Color.parseColor("#00E676"));
            towerGuidePaint.setStrokeWidth(dpToPx(2));
            towerGuidePaint.setStyle(Paint.Style.STROKE);
            towerGuidePaint.setPathEffect(new DashPathEffect(new float[]{12f, 8f}, 0f));

            towerMovingPaint.setColor(Color.parseColor("#00E5FF"));
            towerMovingPaint.setStrokeWidth(dpToPx(2));
            towerMovingPaint.setStyle(Paint.Style.STROKE);

            towerPredictedPaint.setColor(Color.parseColor("#FFEA00"));
            towerPredictedPaint.setStyle(Paint.Style.FILL);

            safeTapZonePaint.setColor(Color.parseColor("#38BDF8"));
            safeTapZonePaint.setStyle(Paint.Style.STROKE);
            safeTapZonePaint.setStrokeWidth(dpToPx(2));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) {
                return;
            }

            // 1. REGLA HUD HORIZONTAL SUPERIOR EN Y = 0.25f (FUERA DEL ÁREA DE CAPTURA DE LA TORRE)
            float rulerCenterY = 0.25f * h;
            float rulerHeight = dpToPx(36);
            hudRulerRect.set(w * 0.05f, rulerCenterY - (rulerHeight * 0.5f), w * 0.95f, rulerCenterY + (rulerHeight * 0.5f));
            canvas.drawRoundRect(hudRulerRect, dpToPx(8), dpToPx(8), rulerBgPaint);

            // Eje central de la regla
            canvas.drawLine(hudRulerRect.left + dpToPx(8), rulerCenterY, hudRulerRect.right - dpToPx(8), rulerCenterY, rulerAxisPaint);

            float targetX = (renderTargetCenterX > 0.0f) ? renderTargetCenterX : (w * 0.5f);
            float targetWithOffset = targetX - triggerEngine.getCenterOffsetPx();

            // Marcas verdes de la Base [baseLeftX, baseCenterX, baseRightX] en el HUD superior
            if (renderBaseDetected && renderBaseMaxX > renderBaseMinX) {
                canvas.drawLine(renderBaseMinX, rulerCenterY - dpToPx(12), renderBaseMinX, rulerCenterY + dpToPx(12), rulerBaseTickPaint);
                canvas.drawLine(renderBaseMaxX, rulerCenterY - dpToPx(12), renderBaseMaxX, rulerCenterY + dpToPx(12), rulerBaseTickPaint);
                canvas.drawLine(targetWithOffset, rulerCenterY - dpToPx(16), targetWithOffset, rulerCenterY + dpToPx(16), rulerBaseTickPaint);
            } else {
                canvas.drawLine(targetWithOffset, rulerCenterY - dpToPx(16), targetWithOffset, rulerCenterY + dpToPx(16), rulerBaseTickPaint);
            }

            // Marcas cian/amarillo del Bloque Móvil [movingMinX, movingCenterX, movingMaxX] en el HUD superior
            if (renderMovingDetected && renderMovingMaxX > renderMovingMinX) {
                canvas.drawLine(renderMovingMinX, rulerCenterY - dpToPx(8), renderMovingMinX, rulerCenterY + dpToPx(8), rulerMovingTickPaint);
                canvas.drawLine(renderMovingMaxX, rulerCenterY - dpToPx(8), renderMovingMaxX, rulerCenterY + dpToPx(8), rulerMovingTickPaint);
                canvas.drawCircle(renderMovingCenterX, rulerCenterY, dpToPx(5), rulerMovingTickPaint);

                float clampedPredX = Math.max(hudRulerRect.left + dpToPx(10), Math.min(hudRulerRect.right - dpToPx(10), renderPredictedX));
                canvas.drawCircle(clampedPredX, rulerCenterY, dpToPx(5), rulerPredictedPaint);
            }

            String hudLabel = autoStackEnabled ? "HUD 60FPS: ALINEACIÓN ACTIVA" : "PAUSADO / CALIBRACIÓN";
            canvas.drawText(hudLabel, hudRulerRect.left + dpToPx(10), hudRulerRect.top + dpToPx(12), rulerLabelPaint);

            // 2. GUIAS SOBRE LA TORRE: SOLO CUANDO autoStackEnabled == false (PAUSADO O CALIBRANDO)
            // Cuando autoStackEnabled == true, está PROHIBIDO dibujar dentro de Y [0.32f, 0.80f]
            if (!autoStackEnabled) {
                float baseY = (renderBaseCrownY > 0) ? renderBaseCrownY : (stackTracker.getBaseScanYNorm() * h);
                float movingY = (renderMovingCrownY > 0) ? renderMovingCrownY : (stackTracker.getMovingScanYNorm() * h);

                // Dibujar guías completas para calibrar
                canvas.drawLine(targetWithOffset, baseY - dpToPx(80), targetWithOffset, baseY + dpToPx(40), towerGuidePaint);

                if (renderBaseDetected && renderBaseMaxX > renderBaseMinX) {
                    canvas.drawLine(renderBaseMinX, baseY - dpToPx(60), renderBaseMinX, baseY + dpToPx(30), towerGuidePaint);
                    canvas.drawLine(renderBaseMaxX, baseY - dpToPx(60), renderBaseMaxX, baseY + dpToPx(30), towerGuidePaint);
                    canvas.drawLine(renderBaseMinX, baseY, renderBaseMaxX, baseY, towerGuidePaint);
                }

                if (renderMovingDetected && renderMovingMaxX > renderMovingMinX) {
                    float boxHalfH = dpToPx(16);
                    towerBoxRect.set(renderMovingMinX, movingY - boxHalfH, renderMovingMaxX, movingY + boxHalfH);
                    canvas.drawRoundRect(towerBoxRect, dpToPx(4), dpToPx(4), towerMovingPaint);
                    canvas.drawCircle(renderMovingCenterX, movingY, dpToPx(5), towerMovingPaint);
                    canvas.drawCircle(renderPredictedX, movingY, dpToPx(5), towerPredictedPaint);
                }
            }

            // Indicador de tap discreto en esquina lateral
            float tapX = TapAccessibilityService.DEFAULT_SAFE_TAP_X_NORM * w;
            float tapY = TapAccessibilityService.DEFAULT_SAFE_TAP_Y_NORM * h;
            long sinceShotMs = SystemClock.uptimeMillis() - lastShotFlashUptimeMs;
            if (sinceShotMs >= 0L && sinceShotMs < 180L) {
                safeTapZonePaint.setColor(Color.parseColor("#00E676"));
                canvas.drawCircle(tapX, tapY, dpToPx(12), safeTapZonePaint);
            } else if (calibrationMode) {
                safeTapZonePaint.setColor(Color.argb(110, 56, 189, 248));
                canvas.drawCircle(tapX, tapY, dpToPx(6), safeTapZonePaint);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (!calibrationMode) {
                return false;
            }
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) {
                return false;
            }
            float touchX = event.getX();
            float touchY = event.getY();

            float movingY = stackTracker.getMovingScanYNorm() * h;
            float baseY = stackTracker.getBaseScanYNorm() * h;
            float targetX = stackTracker.getManualTargetXNorm() * w;

            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (Math.abs(touchX - targetX) <= dpToPx(36)) {
                        activeDragTarget = 3;
                    } else if (Math.abs(touchY - movingY) <= Math.abs(touchY - baseY)) {
                        activeDragTarget = 1;
                    } else {
                        activeDragTarget = 2;
                    }
                    applyCalibrationTouch(touchX, touchY, w, h);
                    return true;

                case MotionEvent.ACTION_MOVE:
                    applyCalibrationTouch(touchX, touchY, w, h);
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    activeDragTarget = 0;
                    stackTracker.enforceAntiInversionRule();
                    saveConfigurationToPrefs();
                    invalidate();
                    return true;

                default:
                    return false;
            }
        }

        private void applyCalibrationTouch(float touchX, float touchY, int w, int h) {
            float normY = touchY / (float) h;
            if (activeDragTarget == 1) {
                stackTracker.setMovingScanYNorm(normY);
                renderMovingCrownY = Math.round(stackTracker.getMovingScanYNorm() * h);
            } else if (activeDragTarget == 2) {
                stackTracker.setBaseScanYNorm(normY);
                renderBaseCrownY = Math.round(stackTracker.getBaseScanYNorm() * h);
            } else if (activeDragTarget == 3) {
                stackTracker.setManualTargetXNorm(touchX / (float) w);
                stackTracker.setAutoBaseMode(false);
                renderTargetCenterX = touchX;
                updateControlButtonsAppearance();
            }
            invalidate();
        }
    }
}
