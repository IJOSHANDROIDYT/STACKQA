package com.example;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.ComponentName;
import android.content.Context;
import android.graphics.Path;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;

/**
 * Ejecutor de Toques Infalible en Zona Libre (TapAccessibilityService).
 * Ejecuta un gesto de 45ms con un micro-trazo de 2px en (0.85f * screenWidth, 0.35f * screenHeight),
 * lejos del panel flotante superior-izquierdo y lejos de las líneas de escaneo centrales.
 */
public final class TapAccessibilityService extends AccessibilityService {

    public static final float DEFAULT_SAFE_TAP_X_NORM = 0.85f;
    public static final float DEFAULT_SAFE_TAP_Y_NORM = 0.35f;
    public static final long ULTRA_FAST_TAP_DURATION_MS = 45L;
    private static final float MICRO_STROKE_DELTA_PX = 2.0f;

    private static volatile TapAccessibilityService instance;
    private static volatile LocalTapListener localTapListener;

    public interface LocalTapListener {
        void onFastTapDispatched(float tapX, float tapY, long timestampNs);
    }

    public static TapAccessibilityService getInstance() {
        return instance;
    }

    public static void setLocalTapListener(LocalTapListener listener) {
        localTapListener = listener;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Sin procesamiento de eventos de ventana para preservar latencia mínima
    }

    @Override
    public void onInterrupt() {
        // Requerido por AccessibilityService
    }

    @Override
    public void onDestroy() {
        if (instance == this) {
            instance = null;
        }
        super.onDestroy();
    }

    /**
     * Ejecuta el clic infalible de 45ms en la zona libre lateral derecha (0.85f * W, 0.35f * H).
     */
    public boolean performSafeUpperTap(int screenWidth, int screenHeight) {
        float tapX = DEFAULT_SAFE_TAP_X_NORM * screenWidth;
        float tapY = DEFAULT_SAFE_TAP_Y_NORM * screenHeight;
        return performUltraFastTap(tapX, tapY);
    }

    /**
     * Ejecuta un GestureDescription de 45ms con micro-trazo de 2px para garantizar el registro
     * del toque en cualquier motor 3D de juego sin ser filtrado como toque fantasma.
     */
    public boolean performUltraFastTap(float x, float y) {
        try {
            long nowNs = System.nanoTime();
            LocalTapListener listener = localTapListener;
            if (listener != null) {
                listener.onFastTapDispatched(x, y, nowNs);
            }

            DisplayMetrics dm = getResources().getDisplayMetrics();
            float safeX = Math.max(12.0f, Math.min(x, dm.widthPixels - 14.0f));
            float safeY = Math.max(12.0f, Math.min(y, dm.heightPixels - 14.0f));

            Path tapPath = new Path();
            tapPath.moveTo(safeX, safeY);
            tapPath.lineTo(safeX + MICRO_STROKE_DELTA_PX, safeY + MICRO_STROKE_DELTA_PX);

            GestureDescription.StrokeDescription stroke =
                    new GestureDescription.StrokeDescription(tapPath, 0L, ULTRA_FAST_TAP_DURATION_MS);

            GestureDescription gesture = new GestureDescription.Builder()
                    .addStroke(stroke)
                    .build();

            return dispatchGesture(gesture, null, null);
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * Despacha el toque de 45ms en (0.85f * screenWidth, 0.35f * screenHeight) a través del
     * servicio de accesibilidad o hacia el banco de pruebas local.
     */
    public static boolean dispatchGlobalOrLocalSafeTap(int screenWidth, int screenHeight) {
        try {
            float tapX = DEFAULT_SAFE_TAP_X_NORM * screenWidth;
            float tapY = DEFAULT_SAFE_TAP_Y_NORM * screenHeight;

            TapAccessibilityService service = instance;
            if (service != null) {
                return service.performUltraFastTap(tapX, tapY);
            }

            LocalTapListener listener = localTapListener;
            if (listener != null) {
                listener.onFastTapDispatched(tapX, tapY, System.nanoTime());
                return true;
            }
            return false;
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * Comprueba si TapAccessibilityService se encuentra habilitado en Ajustes del Sistema.
     */
    public static boolean isServiceEnabled(Context context) {
        if (instance != null) {
            return true;
        }
        if (context == null) {
            return false;
        }
        ComponentName expectedComponent = new ComponentName(context, TapAccessibilityService.class);
        String enabledServices = Settings.Secure.getString(
                context.getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabledServices)) {
            return false;
        }
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabledServices);
        while (splitter.hasNext()) {
            String componentStr = splitter.next();
            ComponentName enabledComponent = ComponentName.unflattenFromString(componentStr);
            if (enabledComponent != null && enabledComponent.equals(expectedComponent)) {
                return true;
            }
        }
        return false;
    }
}
