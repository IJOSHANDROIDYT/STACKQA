package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import java.nio.ByteBuffer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `verify factory coordinates anti-inversion and top-face chroma detector`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("QA AutoStacker", appName)

    // Verify TapAccessibilityService default tap point (0.50f, 0.715f) and 35ms stroke
    TapAccessibilityService.resetTapPointToDefaults()
    assertEquals(0.50f, TapAccessibilityService.getTapXNorm(), 0.0001f)
    assertEquals(0.715f, TapAccessibilityService.getTapYNorm(), 0.0001f)
    assertEquals(35L, TapAccessibilityService.ULTRA_FAST_TAP_DURATION_MS)

    val tracker = IsometricStackTracker()
    assertEquals(0.545f, tracker.movingScanYNorm, 0.0001f)
    assertEquals(0.590f, tracker.baseScanYNorm, 0.0001f)
    assertTrue(tracker.isAutoBaseMode)

    // Verify anti-inversion rule prevents MOVING_Y from crossing below BASE_Y - 0.02f
    assertFalse(IsometricStackTracker.areSavedAxesValid(0.62f, 0.46f))
    tracker.movingScanYNorm = 0.65f
    assertTrue(tracker.movingScanYNorm <= tracker.baseScanYNorm - 0.02f + 0.0001f)
    tracker.resetAxesToFactoryDefaults()

    val width = 1080
    val height = 2400
    val rowStride = width * 4
    val buffer = ByteBuffer.allocateDirect(width * height * 4)

    val baseY = Math.round(tracker.baseScanYNorm * height)
    val movingY = Math.round(tracker.movingScanYNorm * height)

    fun fillRowBandWithRealisticColors(y: Int, topLeftX: Int, topRightX: Int, darkRightWallEndX: Int) {
      for (dy in listOf(-3, 3)) {
        val row = (y + dy) * rowStride
        for (x in 0 until width step 2) {
          val idx = row + x * 4
          when {
            x in topLeftX..topRightX -> {
              // Illuminated top face: R=181, G=140, B=190 (chroma=50 >= 26, max=190 >= 135)
              buffer.put(idx, 181.toByte())
              buffer.put(idx + 1, 140.toByte())
              buffer.put(idx + 2, 190.toByte())
              buffer.put(idx + 3, 255.toByte())
            }
            x in (topRightX + 1)..darkRightWallEndX -> {
              // Dark right lateral face: R=108, G=73, B=138 (must be ignored!)
              buffer.put(idx, 108.toByte())
              buffer.put(idx + 1, 73.toByte())
              buffer.put(idx + 2, 138.toByte())
              buffer.put(idx + 3, 255.toByte())
            }
            else -> {
              // Neutral grey floor around tower: R=180, G=172, B=180 (chroma=8 < 26, must be ignored!)
              buffer.put(idx, 180.toByte())
              buffer.put(idx + 1, 172.toByte())
              buffer.put(idx + 2, 180.toByte())
              buffer.put(idx + 3, 255.toByte())
            }
          }
        }
      }
    }

    fillRowBandWithRealisticColors(baseY, 340, 740, 820)
    fillRowBandWithRealisticColors(movingY, 260, 660, 740)

    // Warm up JIT once before measuring sub-3ms real-time frame budget
    tracker.processByteBuffer(buffer, width, height, rowStride, 4, 90_000_000L)
    val scan = tracker.processByteBuffer(buffer, width, height, rowStride, 4, 100_000_000L)
    assertTrue(scan.validFrame)
    assertTrue(scan.baseDetected)
    assertTrue(scan.movingDetected)
    // Verify dark right wall (741..820) and grey floor were ignored, centering strictly on [340..740] -> 540
    assertEquals(340.0f, scan.baseLeftEdgeX, 6.0f)
    assertEquals(740.0f, scan.baseRightEdgeX, 6.0f)
    assertEquals(540.0f, scan.detectedBaseCenterX, 6.0f)
    assertEquals(460.0f, scan.movingCenterX, 6.0f)
    assertTrue("Processing time must be < 3ms (was ${scan.processingTimeMs}ms)", scan.processingTimeMs < 3.0f)
  }

  @Test
  fun `verify PredictiveTriggerEngine Top-Face Center Alignment and 35px distance gate`() {
    val predictor = PredictiveTriggerEngine()
    predictor.leadTimeMs = 24.0f
    predictor.centerOffsetPx = 0.0f

    val targetX = 540.0f

    // 1. Slow/static noise (0.04 px/ms < 0.15 px/ms) must NOT fire even on target
    predictor.evaluateFrame(true, 539.0f, targetX, 100_000_000L, true)
    val slowDecision = predictor.evaluateFrame(true, 539.6f, targetX, 116_000_000L, true)
    assertFalse(slowDecision.shouldFire)

    // 2. Premature shot guard: block far from center (|trueMovingCenterX - baseCenterX| > 35px) must NEVER fire
    predictor.resetStats()
    predictor.evaluateLeadingEdgeFrame(true, 620.0f, 1020.0f, 820.0f, 340.0f, 740.0f, 540.0f, 150_000_000L, true)
    val farDecision = predictor.evaluateLeadingEdgeFrame(
      true, 580.0f, 980.0f, 780.0f, 340.0f, 740.0f, 540.0f, 166_000_000L, true
    )
    assertFalse(farDecision.shouldFire)

    // 3. Real block approaching from left at 1.0 px/ms with left side clipped at screen border (x=36)
    // reconstructs trueMovingCenterX = movingRightEdgeX - (baseWidth * 0.5f) and fires within <= 35px of 540
    predictor.resetStats()
    predictor.evaluateLeadingEdgeFrame(true, 36.0f, 660.0f, 348.0f, 340.0f, 740.0f, 540.0f, 200_000_000L, true)
    predictor.evaluateLeadingEdgeFrame(true, 36.0f, 676.0f, 356.0f, 340.0f, 740.0f, 540.0f, 216_000_000L, true)
    predictor.evaluateLeadingEdgeFrame(true, 36.0f, 692.0f, 364.0f, 340.0f, 740.0f, 540.0f, 232_000_000L, true)
    val leftClippedDecision = predictor.evaluateLeadingEdgeFrame(
      true, 36.0f, 716.0f, 376.0f, 340.0f, 740.0f, 540.0f, 248_000_000L, true
    )
    assertTrue(leftClippedDecision.trackingRightLeadingEdge)
    assertTrue(leftClippedDecision.shouldFire)
  }
}
