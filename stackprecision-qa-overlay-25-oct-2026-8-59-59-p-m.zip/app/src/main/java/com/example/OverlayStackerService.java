package com.example;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;

/**
 * Servicio en Primer Plano de Superposición (Overlay) y Captura a 60 FPS (OverlayStackerService).
 * Implementa las 4 correcciones matemáticas:
 * 1. Guía Visual del Rombo de la Cara Superior:
 *    Al pulsar Auto-Ejes o Calibrar Ejes, dibuja el rombo verde ciñendo ÚNICAMENTE la Cara Superior
 *    del bloque más alto (ej. bloque fucsia de la cima), mostrando que las líneas verticales verdes
 *    baseLeftX y baseRightX coinciden con las puntas izquierda y derecha de la cima real y nunca
 *    con los escalones morados viejos de atrás.
 * 2. Cero auto-interferencia con MediaProjection cuando Auto-Stack: ON está activo
 *    (solo se dibuja la Regla HUD en Y = 0.25f).
 * 3. Integración con trueMovingCenterX (autoverificado con baseWidth) y regla estricta de 35px
 *    de PredictiveTriggerEngine.
 * 4. Toque firme de 35ms en (0.50f, 0.715f) y re-captura automática tras 280ms.
 */
public final class OverlayStackerService extends Service {

    public static final String ACTION_START_OVERLAY = "com.example.action.START_OVERLAY";
    public static final String ACTION_STOP_OVERLAY = "com.example.action.STOP_OVERLAY";
    public static final String EXTRA_RESULT_CODE = "extra_result_code";
    public static final String EXTRA_RESULT_DATA = "extra_result_data";

    public static final String PREFS_NAME = "qa_autostacker_prefs";
    public static final String KEY_BASE_SCAN_Y = "base_scan_y_norm";
    public static final String KEY_MOVING_SCAN_Y = "moving_scan_y_norm";
    public static final String KEY_TARGET_X = "target_x_norm";
    public static final String KEY_HALF_WIDTH_NORM = "half_width_norm";
    public static final String KEY_TAP_X_NORM = "tap_x_norm";
    public static final String KEY_TAP_Y_NORM = "tap_y_norm";
    public static final String KEY_LEAD_TIME_MS = "lead_time_ms";
    public static final String KEY_CENTER_OFFSET_PX = "center_offset_px";
    public static final String KEY_AUTO_BASE_MODE = "auto_base_mode";
    public static final String KEY_PANEL_SCALE = "panel_scale";

    private static final String CHANNEL_ID = "qa_autostacker_overlay_channel";
    private static final int NOTIFICATION_ID = 1001;

    private static volatile OverlayStackerService runningInstance;

    private WindowManager windowManager;
    private MediaProjectionManager projectionManager;
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;

    private HandlerThread visionThread;
    private Handler visionHandler;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private final IsometricStackTracker stackTracker = new IsometricStackTracker();
    private final PredictiveTriggerEngine triggerEngine = new PredictiveTriggerEngine();

    private SharedPreferences prefs;
    private int screenWidth;
    private int screenHeight;
    private int screenDensityDpi;

    private volatile boolean autoStackEnabled = false;
    private volatile boolean calibrationMode = false;
    private volatile boolean isMinimizedToPill = false;
    private volatile boolean autoTapToPlayEnabled = true;
    private float panelScaleFactor = 1.0f;
    private long lastTapToPlayUptimeMs = -10_000L;

    // Estado visual sincronizado de la Cara Superior de la Cima y Losa Móvil
    private volatile boolean renderGameValid = true;
    private volatile boolean renderBaseDetected = false;
    private volatile float renderTopVertexX = 0.0f;
    private volatile int renderTowerTopY = 0;
    private volatile int renderBaseCenterY = 0;
    private volatile float renderBaseFrontX = 0.0f;
    private volatile int renderBaseFrontY = 0;
    private volatile float renderBaseLeftX = 0.0f;
    private volatile float renderBaseRightX = 0.0f;
    private volatile float renderBaseCenterX = 0.0f;

    private volatile boolean renderMovingDetected = false;
    private volatile float renderMovingLeftX = 0.0f;
    private volatile float renderMovingRightX = 0.0f;
    private volatile float renderTrueMovingCenterX = 0.0f;
    private volatile float renderPredictedCenterX = 0.0f;
    private volatile float renderVelocityPxPerMs = 0.0f;
    private volatile float renderAnalysisTimeMs = 0.0f;
    private volatile String renderStatusText = "LISTO (60 FPS)";

    private LaserCalibrationView laserCalibrationView;
    private WindowManager.LayoutParams laserLayoutParams;

    private LinearLayout floatingRootContainer;
    private LinearLayout expandedPanelContent;
    private TextView miniPillButton;
    private WindowManager.LayoutParams panelLayoutParams;

    private Button btnToggleAutoStack;
    private Button btnToggleCalibrate;
    private Button btnToggleMode;
    private Button btnAutoAxes;
    private TextView txtLeadTimeValue;
    private TextView txtCenterOffsetValue;
    private TextView txtTelemetryLine;

    public static OverlayStackerService getRunningInstance() {
        return runningInstance;
    }

    public IsometricStackTracker getStackTracker() {
        return stackTracker;
    }

    public PredictiveTriggerEngine getTriggerEngine() {
        return triggerEngine;
    }

    public boolean isAutoStackEnabled() {
        return autoStackEnabled;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        runningInstance = this;
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        updateScreenMetrics();
        loadAndValidateSavedConfiguration();
        startVisionThread();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            if (intent != null && ACTION_STOP_OVERLAY.equals(intent.getAction())) {
                stopSelf();
                return START_NOT_STICKY;
            }

            int resultCode = Activity.RESULT_CANCELED;
            Intent resultData = null;
            if (intent != null) {
                resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
                resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
            }

            boolean hasProjectionPayload = (resultCode == Activity.RESULT_OK && resultData != null);
            promoteToForeground(hasProjectionPayload);

            if (Settings.canDrawOverlays(this)) {
                ensureOverlayViewsCreated();
            }

            if (hasProjectionPayload) {
                startMediaProjectionCapture(resultCode, resultData);
            }
        } catch (Throwable ignored) {
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        try {
            autoStackEnabled = false;
            stopMediaProjectionCapture();
            removeOverlayViews();
            stopVisionThread();
        } catch (Throwable ignored) {
        } finally {
            if (runningInstance == this) {
                runningInstance = null;
            }
            super.onDestroy();
        }
    }

    private void updateScreenMetrics() {
        try {
            DisplayMetrics dm = getResources().getDisplayMetrics();
            if (windowManager != null && windowManager.getDefaultDisplay() != null) {
                windowManager.getDefaultDisplay().getRealMetrics(dm);
            }
            screenWidth = Math.max(320, dm.widthPixels);
            screenHeight = Math.max(480, dm.heightPixels);
            screenDensityDpi = dm.densityDpi;
            syncRenderStateFromTracker();
        } catch (Throwable ignored) {
        }
    }

    private void syncRenderStateFromTracker() {
        float centerPx = stackTracker.getManualTargetXNorm() * screenWidth;
        float halfW = stackTracker.getManualHalfWidthNorm() * screenWidth;
        int centerY = Math.round(stackTracker.getBaseScanYNorm() * screenHeight);
        int halfH = Math.round(halfW * 0.48f);

        renderBaseCenterX = centerPx;
        renderBaseLeftX = centerPx - halfW;
        renderBaseRightX = centerPx + halfW;
        renderBaseCenterY = centerY;
        renderTopVertexX = centerPx;
        renderTowerTopY = Math.max(12, centerY - halfH);
        renderBaseFrontX = centerPx;
        renderBaseFrontY = Math.min(screenHeight - 12, centerY + halfH);
        renderPredictedCenterX = centerPx;
    }

    private void loadAndValidateSavedConfiguration() {
        try {
            float savedMovingY = prefs.getFloat(KEY_MOVING_SCAN_Y, IsometricStackTracker.DEFAULT_MOVING_Y_NORM);
            float savedBaseY = prefs.getFloat(KEY_BASE_SCAN_Y, IsometricStackTracker.DEFAULT_BASE_Y_NORM);
            float savedTargetX = prefs.getFloat(KEY_TARGET_X, IsometricStackTracker.DEFAULT_FIXED_AXIS_X_NORM);
            float savedHalfW = prefs.getFloat(KEY_HALF_WIDTH_NORM, IsometricStackTracker.DEFAULT_HALF_WIDTH_NORM);
            float savedTapX = prefs.getFloat(KEY_TAP_X_NORM, TapAccessibilityService.DEFAULT_SAFE_TAP_X_NORM);
            float savedTapY = prefs.getFloat(KEY_TAP_Y_NORM, TapAccessibilityService.DEFAULT_SAFE_TAP_Y_NORM);
            float savedLeadMs = prefs.getFloat(KEY_LEAD_TIME_MS, PredictiveTriggerEngine.DEFAULT_LEAD_TIME_MS);
            float savedOffsetPx = prefs.getFloat(KEY_CENTER_OFFSET_PX, PredictiveTriggerEngine.DEFAULT_CENTER_OFFSET_PX);
            panelScaleFactor = prefs.getFloat(KEY_PANEL_SCALE, 1.0f);

            if (!IsometricStackTracker.areSavedAxesValid(savedMovingY, savedBaseY)) {
                savedMovingY = IsometricStackTracker.DEFAULT_MOVING_Y_NORM;
                savedBaseY = IsometricStackTracker.DEFAULT_BASE_Y_NORM;
                savedTargetX = IsometricStackTracker.DEFAULT_FIXED_AXIS_X_NORM;
                savedHalfW = IsometricStackTracker.DEFAULT_HALF_WIDTH_NORM;
                savedOffsetPx = 0.0f;
            }

            // Si un ancho guardado anteriormente era demasiado grande (> 0.40f), restaurar a 0.20f
            if (savedHalfW > 0.36f || savedHalfW < 0.07f) {
                savedHalfW = IsometricStackTracker.DEFAULT_HALF_WIDTH_NORM;
            }

            if (savedTapY < 0.45f && Math.abs(savedTapX - 0.85f) < 0.08f) {
                savedTapX = TapAccessibilityService.DEFAULT_SAFE_TAP_X_NORM;
                savedTapY = TapAccessibilityService.DEFAULT_SAFE_TAP_Y_NORM;
            }

            TapAccessibilityService.setTapPointNorm(savedTapX, savedTapY);

            stackTracker.resetAxesToFactoryDefaults();
            stackTracker.setBaseScanYNorm(savedBaseY);
            stackTracker.setMovingScanYNorm(savedMovingY);
            stackTracker.setManualTargetXNorm(savedTargetX);
            stackTracker.setManualHalfWidthNorm(savedHalfW);
            stackTracker.setAutoBaseMode(true);

            triggerEngine.setLeadTimeMs(savedLeadMs);
            triggerEngine.setCenterOffsetPx(savedOffsetPx);

            syncRenderStateFromTracker();
            saveConfigurationToPrefs();
        } catch (Throwable ignored) {
        }
    }

    /**
     * Acción del botón [Auto-Ejes]:
     * Escanea la Cara Superior más alta e iluminada en el centro de la torre,
     * ignorando escalones viejos de atrás, y encaja el rombo verde sobre el bloque superior.
     */
    public void applyFactoryAutoAxesReset() {
        try {
            stackTracker.requestAutoAxesSnap();
            triggerEngine.setCenterOffsetPx(0.0f);
            triggerEngine.resetHistory();

            renderStatusText = "AUTO-EJES: CIMA DETECTADA";

            saveConfigurationToPrefs();
            updateControlButtonsAppearance();
            if (laserCalibrationView != null) {
                laserCalibrationView.invalidate();
            }
            refreshOverlayTelemetryOnMainThread();
        } catch (Throwable ignored) {
        }
    }

    public void saveConfigurationToPrefs() {
        try {
            stackTracker.enforceAntiInversionRule();
            prefs.edit()
                    .putFloat(KEY_MOVING_SCAN_Y, stackTracker.getMovingScanYNorm())
                    .putFloat(KEY_BASE_SCAN_Y, stackTracker.getBaseScanYNorm())
                    .putFloat(KEY_TARGET_X, stackTracker.getManualTargetXNorm())
                    .putFloat(KEY_HALF_WIDTH_NORM, stackTracker.getManualHalfWidthNorm())
                    .putFloat(KEY_TAP_X_NORM, TapAccessibilityService.getTapXNorm())
                    .putFloat(KEY_TAP_Y_NORM, TapAccessibilityService.getTapYNorm())
                    .putFloat(KEY_LEAD_TIME_MS, triggerEngine.getLeadTimeMs())
                    .putFloat(KEY_CENTER_OFFSET_PX, triggerEngine.getCenterOffsetPx())
                    .putBoolean(KEY_AUTO_BASE_MODE, stackTracker.isAutoBaseMode())
                    .putFloat(KEY_PANEL_SCALE, panelScaleFactor)
                    .apply();
        } catch (Throwable ignored) {
        }
    }

    private void promoteToForeground(boolean withMediaProjectionType) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID,
                        "QA Auto-Stacker 60FPS Service",
                        NotificationManager.IMPORTANCE_LOW);
                channel.setDescription("Detector de Cara Superior a 60 FPS");
                nm.createNotificationChannel(channel);
            }

            Intent openAppIntent = new Intent(this, MainActivity.class);
            PendingIntent pendingOpen = PendingIntent.getActivity(
                    this,
                    0,
                    openAppIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Notification.Builder builder = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    ? new Notification.Builder(this, CHANNEL_ID)
                    : new Notification.Builder(this);

            Notification notification = builder
                    .setContentTitle("QA Auto-Stacker 60 FPS Activo")
                    .setContentText("Aislamiento de Cara Superior + Toque 35ms")
                    .setSmallIcon(android.R.drawable.ic_menu_compass)
                    .setContentIntent(pendingOpen)
                    .setOngoing(true)
                    .build();

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && withMediaProjectionType) {
                startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                startForeground(NOTIFICATION_ID, notification);
            }
        } catch (Throwable ignored) {
        }
    }

    private void startVisionThread() {
        try {
            if (visionThread != null) {
                return;
            }
            visionThread = new HandlerThread(
                    "QAStackerByteBuffer60FPS",
                    Process.THREAD_PRIORITY_URGENT_DISPLAY);
            visionThread.start();
            visionHandler = new Handler(visionThread.getLooper());
        } catch (Throwable ignored) {
        }
    }

    private void stopVisionThread() {
        try {
            if (visionThread != null) {
                visionThread.quitSafely();
                visionThread = null;
                visionHandler = null;
            }
        } catch (Throwable ignored) {
        }
    }

    private void startMediaProjectionCapture(int resultCode, Intent resultData) {
        try {
            stopMediaProjectionCapture();
            if (projectionManager == null) {
                return;
            }
            updateScreenMetrics();
            mediaProjection = projectionManager.getMediaProjection(resultCode, resultData);
            if (mediaProjection == null) {
                return;
            }

            mediaProjection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    mainHandler.post(() -> stopMediaProjectionCapture());
                }
            }, mainHandler);

            imageReader = ImageReader.newInstance(
                    screenWidth,
                    screenHeight,
                    PixelFormat.RGBA_8888,
                    2);

            imageReader.setOnImageAvailableListener(reader -> {
                Image image = null;
                try {
                    image = reader.acquireLatestImage();
                    if (image != null) {
                        processCapturedFrame(image);
                    }
                } catch (Throwable ignored) {
                } finally {
                    if (image != null) {
                        try {
                            image.close();
                        } catch (Throwable ignored) {
                        }
                    }
                }
            }, visionHandler);

            virtualDisplay = mediaProjection.createVirtualDisplay(
                    "QAStacker60FPSDisplay",
                    screenWidth,
                    screenHeight,
                    screenDensityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.getSurface(),
                    null,
                    visionHandler);

            renderStatusText = "CAPTURA 60FPS ACTIVA";
            refreshOverlayTelemetryOnMainThread();
        } catch (Throwable e) {
            renderStatusText = "MODO SIMULADOR / CALIBRACIÓN";
            refreshOverlayTelemetryOnMainThread();
        }
    }

    private void stopMediaProjectionCapture() {
        try {
            if (virtualDisplay != null) {
                virtualDisplay.release();
                virtualDisplay = null;
            }
            if (imageReader != null) {
                imageReader.setOnImageAvailableListener(null, null);
                imageReader.close();
                imageReader = null;
            }
            if (mediaProjection != null) {
                mediaProjection.stop();
                mediaProjection = null;
            }
        } catch (Throwable ignored) {
        }
    }

    private void processCapturedFrame(Image image) {
        try {
            IsometricStackTracker.ScanResult scan = stackTracker.processImage(image);
            handleScanAndPrediction(scan);
        } catch (Throwable ignored) {
        }
    }

    public void onExternalByteBufferFrameProcessed(IsometricStackTracker.ScanResult scan) {
        handleScanAndPrediction(scan);
    }

    private void handleScanAndPrediction(IsometricStackTracker.ScanResult scan) {
        try {
            if (scan == null || !scan.validFrame) {
                return;
            }

            renderGameValid = scan.isGameScreenValid;

            if (!scan.isGameScreenValid) {
                renderStatusText = "ANUNCIO / PANTALLA NO VÁLIDA (PAUSADO)";
                if (laserCalibrationView != null) {
                    laserCalibrationView.postInvalidateOnAnimation();
                }
                refreshOverlayTelemetryOnMainThread();
                return;
            }

            PredictiveTriggerEngine.PredictionDecision decision = triggerEngine.evaluateScanResult(
                    scan,
                    autoStackEnabled);

            if (decision.shouldFire && autoStackEnabled) {
                if (decision.subFrameWaitNanos > 0L) {
                    PredictiveTriggerEngine.executeSubFrameSleepIfNeeded(decision.subFrameWaitNanos);
                }
                TapAccessibilityService.dispatchGlobalOrLocalSafeTap(scan.frameWidth, scan.frameHeight);
                // Esperar 280ms tras disparar para re-escanear la nueva Cara Superior más alta
                stackTracker.notifyShotFired(IsometricStackTracker.POST_SHOT_SETTLE_DELAY_MS);
            } else if (autoStackEnabled && autoTapToPlayEnabled && scan.tapToPlayButtonDetected) {
                long nowMs = SystemClock.uptimeMillis();
                if (nowMs - lastTapToPlayUptimeMs > 1500L) {
                    lastTapToPlayUptimeMs = nowMs;
                    TapAccessibilityService.dispatchGlobalOrLocalSafeTap(scan.frameWidth, scan.frameHeight);
                    stackTracker.notifyShotFired(IsometricStackTracker.POST_SHOT_SETTLE_DELAY_MS);
                }
            }

            renderBaseDetected = scan.baseDetected;
            renderTopVertexX = scan.topVertexX;
            renderTowerTopY = scan.towerTopY;
            renderBaseCenterY = scan.baseCenterY;
            renderBaseFrontX = scan.baseFrontX;
            renderBaseFrontY = scan.baseFrontY;
            renderBaseLeftX = scan.effectiveTargetLeftEdgeX;
            renderBaseRightX = scan.effectiveTargetRightEdgeX;
            renderBaseCenterX = scan.effectiveTargetCenterX;

            renderMovingDetected = scan.movingDetected;
            renderMovingLeftX = scan.movingLeftEdgeX;
            renderMovingRightX = scan.movingRightEdgeX;
            renderTrueMovingCenterX = scan.trueMovingCenterX;
            renderPredictedCenterX = decision.predictedX;
            renderVelocityPxPerMs = decision.velocityPxPerMs;
            renderAnalysisTimeMs = scan.processingTimeMs;

            switch (decision.state) {
                case IMMEDIATE_FIRED:
                    renderStatusText = "PERFECT TOP-FACE SNAP ⚡";
                    break;
                case WAIT_AND_SNAP_FIRED:
                    renderStatusText = "SUB-FRAME SNAP 🎯";
                    break;
                case COOLDOWN:
                    renderStatusText = "RE-ESCANEO CIMA (280ms)";
                    break;
                case TRACKING:
                    String dirArrow = (decision.velocityPxPerMs >= 0.0f) ? "↘" : "↙";
                    renderStatusText = String.format(
                            Locale.US,
                            "%s VX:%+.2f | Δ:%.0fpx",
                            dirArrow,
                            decision.velocityPxPerMs,
                            decision.centerErrorPx);
                    break;
                case SEARCHING:
                default:
                    renderStatusText = "CARA SUPERIOR LISTA";
                    break;
            }

            if (laserCalibrationView != null) {
                laserCalibrationView.postInvalidateOnAnimation();
            }
            refreshOverlayTelemetryOnMainThread();
        } catch (Throwable ignored) {
        }
    }

    private void ensureOverlayViewsCreated() {
        try {
            if (windowManager == null) {
                return;
            }
            int overlayType = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;

            if (laserCalibrationView == null) {
                laserCalibrationView = new LaserCalibrationView(this);
                laserLayoutParams = new WindowManager.LayoutParams(
                        WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.MATCH_PARENT,
                        overlayType,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                        PixelFormat.TRANSLUCENT);
                laserLayoutParams.gravity = Gravity.TOP | Gravity.START;
                windowManager.addView(laserCalibrationView, laserLayoutParams);
            }

            if (floatingRootContainer == null) {
                buildFloatingControlPanel(overlayType);
            }
        } catch (Throwable ignored) {
        }
    }

    private void removeOverlayViews() {
        try {
            if (windowManager == null) {
                return;
            }
            if (laserCalibrationView != null) {
                windowManager.removeView(laserCalibrationView);
                laserCalibrationView = null;
            }
            if (floatingRootContainer != null) {
                windowManager.removeView(floatingRootContainer);
                floatingRootContainer = null;
            }
        } catch (Throwable ignored) {
        }
    }

    private void setCalibrationTouchMode(boolean interactive) {
        try {
            this.calibrationMode = interactive;
            if (interactive && autoStackEnabled) {
                autoStackEnabled = false;
            }
            if (laserCalibrationView != null && laserLayoutParams != null && windowManager != null) {
                if (interactive) {
                    laserLayoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
                } else {
                    stackTracker.enforceAntiInversionRule();
                    laserLayoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
                    saveConfigurationToPrefs();
                }
                windowManager.updateViewLayout(laserCalibrationView, laserLayoutParams);
                laserCalibrationView.invalidate();
            }
            updateControlButtonsAppearance();
        } catch (Throwable ignored) {
        }
    }

    private void buildFloatingControlPanel(int overlayType) {
        try {
            floatingRootContainer = new LinearLayout(this);
            floatingRootContainer.setOrientation(LinearLayout.VERTICAL);

            GradientDrawable panelBg = new GradientDrawable();
            panelBg.setColor(Color.argb(232, 15, 23, 42));
            panelBg.setCornerRadius(dpToPx(14));
            panelBg.setStroke(dpToPx(1), Color.argb(180, 56, 189, 248));
            floatingRootContainer.setBackground(panelBg);
            int pad = dpToPx(8);
            floatingRootContainer.setPadding(pad, pad, pad, pad);

            miniPillButton = new TextView(this);
            miniPillButton.setText("⚡ QA 60FPS [ABRIR]");
            miniPillButton.setTextColor(Color.parseColor("#38BDF8"));
            miniPillButton.setTypeface(Typeface.DEFAULT_BOLD);
            miniPillButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            miniPillButton.setPadding(dpToPx(10), dpToPx(6), dpToPx(10), dpToPx(6));
            miniPillButton.setVisibility(View.GONE);
            miniPillButton.setOnClickListener(v -> setMinimizedToPill(false));
            floatingRootContainer.addView(miniPillButton);

            expandedPanelContent = new LinearLayout(this);
            expandedPanelContent.setOrientation(LinearLayout.VERTICAL);
            floatingRootContainer.addView(expandedPanelContent);

            LinearLayout headerRow = new LinearLayout(this);
            headerRow.setOrientation(LinearLayout.HORIZONTAL);
            headerRow.setGravity(Gravity.CENTER_VERTICAL);

            TextView titleView = new TextView(this);
            titleView.setText("⋮⋮ QA STACKER 60FPS");
            titleView.setTextColor(Color.WHITE);
            titleView.setTypeface(Typeface.DEFAULT_BOLD);
            titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
            headerRow.addView(titleView, titleLp);

            Button btnSmaller = createMiniHeaderButton("[-]", v -> adjustPanelScale(-0.10f));
            Button btnLarger = createMiniHeaderButton("[+]", v -> adjustPanelScale(+0.10f));
            Button btnMinimize = createMiniHeaderButton("[_]", v -> setMinimizedToPill(true));
            Button btnClose = createMiniHeaderButton("[X]", v -> stopSelf());

            headerRow.addView(btnSmaller);
            headerRow.addView(btnLarger);
            headerRow.addView(btnMinimize);
            headerRow.addView(btnClose);
            expandedPanelContent.addView(headerRow);

            txtTelemetryLine = new TextView(this);
            txtTelemetryLine.setTextColor(Color.parseColor("#A7F3D0"));
            txtTelemetryLine.setTypeface(Typeface.MONOSPACE);
            txtTelemetryLine.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
            txtTelemetryLine.setPadding(0, dpToPx(3), 0, dpToPx(4));
            expandedPanelContent.addView(txtTelemetryLine);

            LinearLayout primaryRow = new LinearLayout(this);
            primaryRow.setOrientation(LinearLayout.HORIZONTAL);

            btnToggleAutoStack = createActionPillButton("Auto-Stack: OFF", v -> {
                autoStackEnabled = !autoStackEnabled;
                if (autoStackEnabled && calibrationMode) {
                    setCalibrationTouchMode(false);
                }
                triggerEngine.resetHistory();
                if (autoStackEnabled) {
                    stackTracker.notifyShotFired(180L);
                }
                updateControlButtonsAppearance();
                if (laserCalibrationView != null) {
                    laserCalibrationView.invalidate();
                }
            });
            btnToggleCalibrate = createActionPillButton("Calibrar Ejes", v -> {
                setCalibrationTouchMode(!calibrationMode);
            });

            LinearLayout.LayoutParams halfLp = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
            halfLp.setMargins(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2));
            primaryRow.addView(btnToggleAutoStack, halfLp);
            primaryRow.addView(btnToggleCalibrate, halfLp);
            expandedPanelContent.addView(primaryRow);

            LinearLayout leadRow = new LinearLayout(this);
            leadRow.setOrientation(LinearLayout.HORIZONTAL);
            leadRow.setGravity(Gravity.CENTER_VERTICAL);

            Button btnLeadMinus = createStepButton("-2ms", v -> {
                triggerEngine.adjustLeadTimeMs(-2.0f);
                saveConfigurationToPrefs();
                updateControlButtonsAppearance();
            });
            txtLeadTimeValue = new TextView(this);
            txtLeadTimeValue.setGravity(Gravity.CENTER);
            txtLeadTimeValue.setTextColor(Color.WHITE);
            txtLeadTimeValue.setTypeface(Typeface.DEFAULT_BOLD);
            txtLeadTimeValue.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            Button btnLeadPlus = createStepButton("+2ms", v -> {
                triggerEngine.adjustLeadTimeMs(+2.0f);
                saveConfigurationToPrefs();
                updateControlButtonsAppearance();
            });

            leadRow.addView(btnLeadMinus);
            leadRow.addView(txtLeadTimeValue, new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));
            leadRow.addView(btnLeadPlus);
            expandedPanelContent.addView(leadRow);

            LinearLayout offsetRow = new LinearLayout(this);
            offsetRow.setOrientation(LinearLayout.HORIZONTAL);
            offsetRow.setGravity(Gravity.CENTER_VERTICAL);

            Button btnOffsetLeft = createStepButton("◀ -2px", v -> {
                triggerEngine.adjustCenterOffsetPx(-2.0f);
                saveConfigurationToPrefs();
                updateControlButtonsAppearance();
                if (laserCalibrationView != null) {
                    laserCalibrationView.invalidate();
                }
            });
            txtCenterOffsetValue = new TextView(this);
            txtCenterOffsetValue.setGravity(Gravity.CENTER);
            txtCenterOffsetValue.setTextColor(Color.WHITE);
            txtCenterOffsetValue.setTypeface(Typeface.DEFAULT_BOLD);
            txtCenterOffsetValue.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            Button btnOffsetRight = createStepButton("▶ +2px", v -> {
                triggerEngine.adjustCenterOffsetPx(+2.0f);
                saveConfigurationToPrefs();
                updateControlButtonsAppearance();
                if (laserCalibrationView != null) {
                    laserCalibrationView.invalidate();
                }
            });

            offsetRow.addView(btnOffsetLeft);
            offsetRow.addView(txtCenterOffsetValue, new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));
            offsetRow.addView(btnOffsetRight);
            expandedPanelContent.addView(offsetRow);

            LinearLayout modeRow = new LinearLayout(this);
            modeRow.setOrientation(LinearLayout.HORIZONTAL);

            btnToggleMode = createActionPillButton("Modo: Auto-Base", v -> {
                boolean nextMode = !stackTracker.isAutoBaseMode();
                stackTracker.setAutoBaseMode(nextMode);
                if (nextMode) {
                    stackTracker.unlockReference();
                }
                saveConfigurationToPrefs();
                updateControlButtonsAppearance();
                if (laserCalibrationView != null) {
                    laserCalibrationView.invalidate();
                }
            });

            btnAutoAxes = createActionPillButton("Auto-Ejes", v -> {
                applyFactoryAutoAxesReset();
            });

            LinearLayout.LayoutParams modeLp = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.35f);
            modeLp.setMargins(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2));
            LinearLayout.LayoutParams autoAxesLp = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.85f);
            autoAxesLp.setMargins(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2));

            modeRow.addView(btnToggleMode, modeLp);
            modeRow.addView(btnAutoAxes, autoAxesLp);
            expandedPanelContent.addView(modeRow);

            panelLayoutParams = new WindowManager.LayoutParams(
                    dpToPx(Math.round(256 * panelScaleFactor)),
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    overlayType,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            panelLayoutParams.gravity = Gravity.TOP | Gravity.START;
            panelLayoutParams.x = dpToPx(12);
            panelLayoutParams.y = dpToPx(56);

            attachDragListenerToView(headerRow);
            attachDragListenerToView(miniPillButton);

            updateControlButtonsAppearance();
            refreshOverlayTelemetryOnMainThread();

            windowManager.addView(floatingRootContainer, panelLayoutParams);
        } catch (Throwable ignored) {
        }
    }

    private void attachDragListenerToView(View dragHandle) {
        dragHandle.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (panelLayoutParams == null || windowManager == null) {
                    return false;
                }
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = panelLayoutParams.x;
                        initialY = panelLayoutParams.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = Math.round(event.getRawX() - initialTouchX);
                        int dy = Math.round(event.getRawY() - initialTouchY);
                        if (Math.abs(dx) > 6 || Math.abs(dy) > 6) {
                            moved = true;
                        }
                        panelLayoutParams.x = Math.max(0, Math.min(screenWidth - dpToPx(80), initialX + dx));
                        panelLayoutParams.y = Math.max(0, Math.min(screenHeight - dpToPx(60), initialY + dy));
                        try {
                            windowManager.updateViewLayout(floatingRootContainer, panelLayoutParams);
                        } catch (Throwable ignored) {
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            v.performClick();
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void adjustPanelScale(float delta) {
        panelScaleFactor = Math.max(0.80f, Math.min(1.30f, panelScaleFactor + delta));
        saveConfigurationToPrefs();
        if (floatingRootContainer != null && panelLayoutParams != null && !isMinimizedToPill) {
            panelLayoutParams.width = dpToPx(Math.round(256 * panelScaleFactor));
            floatingRootContainer.setScaleX(panelScaleFactor);
            floatingRootContainer.setScaleY(panelScaleFactor);
            try {
                windowManager.updateViewLayout(floatingRootContainer, panelLayoutParams);
            } catch (Throwable ignored) {
            }
        }
    }

    private void setMinimizedToPill(boolean minimize) {
        this.isMinimizedToPill = minimize;
        if (expandedPanelContent == null || miniPillButton == null || panelLayoutParams == null) {
            return;
        }
        if (minimize) {
            expandedPanelContent.setVisibility(View.GONE);
            miniPillButton.setVisibility(View.VISIBLE);
            String stateTag = autoStackEnabled ? "ON" : "OFF";
            miniPillButton.setText("⚡ QA 60FPS [" + stateTag + "] ▾");
            panelLayoutParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
        } else {
            miniPillButton.setVisibility(View.GONE);
            expandedPanelContent.setVisibility(View.VISIBLE);
            panelLayoutParams.width = dpToPx(Math.round(256 * panelScaleFactor));
        }
        try {
            windowManager.updateViewLayout(floatingRootContainer, panelLayoutParams);
        } catch (Throwable ignored) {
        }
    }

    private void updateControlButtonsAppearance() {
        if (btnToggleAutoStack != null) {
            btnToggleAutoStack.setText(autoStackEnabled ? "Auto-Stack: ON" : "Auto-Stack: OFF");
            styleButtonBackground(
                    btnToggleAutoStack,
                    autoStackEnabled ? Color.parseColor("#059669") : Color.parseColor("#334155"));
        }
        if (btnToggleCalibrate != null) {
            btnToggleCalibrate.setText(calibrationMode ? "Guardar Ejes ✓" : "Calibrar Ejes");
            styleButtonBackground(
                    btnToggleCalibrate,
                    calibrationMode ? Color.parseColor("#D97706") : Color.parseColor("#1E293B"));
        }
        if (txtLeadTimeValue != null) {
            txtLeadTimeValue.setText(String.format(
                    Locale.US,
                    "Anticipación: %.0fms",
                    triggerEngine.getLeadTimeMs()));
        }
        if (txtCenterOffsetValue != null) {
            float off = triggerEngine.getCenterOffsetPx();
            String sign = (off >= 0.0f) ? "+" : "";
            txtCenterOffsetValue.setText(String.format(
                    Locale.US,
                    "Eje X: %s%.0fpx",
                    sign,
                    off));
        }
        if (btnToggleMode != null) {
            boolean autoBase = stackTracker.isAutoBaseMode();
            btnToggleMode.setText(autoBase ? "Modo: Auto-Base" : "Modo: Eje Fijo");
            styleButtonBackground(
                    btnToggleMode,
                    autoBase ? Color.parseColor("#0284C7") : Color.parseColor("#7C3AED"));
        }
        if (btnAutoAxes != null) {
            btnAutoAxes.setText("Auto-Ejes");
            styleButtonBackground(btnAutoAxes, Color.parseColor("#0D9488"));
        }
        if (miniPillButton != null && isMinimizedToPill) {
            miniPillButton.setText("⚡ QA 60FPS [" + (autoStackEnabled ? "ON" : "OFF") + "] ▾");
        }
    }

    private void refreshOverlayTelemetryOnMainThread() {
        mainHandler.post(() -> {
            if (txtTelemetryLine != null) {
                txtTelemetryLine.setText(String.format(
                        Locale.US,
                        "ROI: %.2fms | Shots: %d | %s",
                        renderAnalysisTimeMs,
                        triggerEngine.getTotalShotsFired(),
                        renderStatusText));
            }
        });
    }

    private Button createMiniHeaderButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.parseColor("#E2E8F0"));
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        b.setPadding(dpToPx(6), dpToPx(2), dpToPx(6), dpToPx(2));
        b.setMinimumWidth(0);
        b.setMinWidth(0);
        b.setMinimumHeight(0);
        b.setMinHeight(0);
        styleButtonBackground(b, Color.parseColor("#1E293B"));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dpToPx(2), 0, 0, 0);
        b.setLayoutParams(lp);
        b.setOnClickListener(listener);
        return b;
    }

    private Button createActionPillButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        b.setPadding(dpToPx(6), dpToPx(5), dpToPx(6), dpToPx(5));
        b.setMinimumHeight(0);
        b.setMinHeight(0);
        styleButtonBackground(b, Color.parseColor("#334155"));
        b.setOnClickListener(listener);
        return b;
    }

    private Button createStepButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.parseColor("#38BDF8"));
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        b.setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));
        b.setMinimumWidth(0);
        b.setMinWidth(0);
        b.setMinimumHeight(0);
        b.setMinHeight(0);
        styleButtonBackground(b, Color.parseColor("#0F172A"));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2));
        b.setLayoutParams(lp);
        b.setOnClickListener(listener);
        return b;
    }

    private void styleButtonBackground(View button, int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dpToPx(8));
        bg.setStroke(dpToPx(1), Color.argb(90, 255, 255, 255));
        button.setBackground(bg);
    }

    private int dpToPx(int dp) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp,
                getResources().getDisplayMetrics()));
    }

    /**
     * Guía Visual del Rombo de la Cara Superior (REGLA 4):
     * - Cuando Auto-Stack: ON (autoStackEnabled == true):
     *   No dibuja nada dentro de la zona de la torre, solo la Regla HUD en Y = 0.25f.
     * - Cuando Auto-Stack: OFF o Calibrar Ejes:
     *   Dibuja el rombo verde ciñendo ÚNICAMENTE la Cara Superior del bloque más alto
     *   (topVertex, rightVertex=baseRightX, frontVertex, leftVertex=baseLeftX), mostrando que
     *   las líneas verticales verdes baseLeftX y baseRightX coinciden con las puntas izquierda
     *   y derecha del bloque superior (ej. fucsia) y nunca con los escalones viejos de atrás.
     */
    private final class LaserCalibrationView extends View {

        private static final int DRAG_NONE = 0;
        private static final int DRAG_RHOMBUS_CENTER = 1;
        private static final int DRAG_LEFT_VERTEX = 2;
        private static final int DRAG_RIGHT_VERTEX = 3;
        private static final int DRAG_TAP_POINT = 4;

        private final Paint rulerBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rulerAxisPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rulerBaseTickPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rulerMovingTickPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rulerPredictedPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rulerLabelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        private final Paint rhombusFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rhombusStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tripwireEdgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint crosshairPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tapCircleFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tapCircleStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        private final RectF hudRulerRect = new RectF();
        private final Path rhombusPath = new Path();
        private int activeDragHandle = DRAG_NONE;

        LaserCalibrationView(Context context) {
            super(context);

            rulerBgPaint.setColor(Color.argb(215, 15, 23, 42));
            rulerBgPaint.setStyle(Paint.Style.FILL);

            rulerAxisPaint.setColor(Color.parseColor("#475569"));
            rulerAxisPaint.setStrokeWidth(dpToPx(2));

            rulerBaseTickPaint.setColor(Color.parseColor("#22C55E"));
            rulerBaseTickPaint.setStrokeWidth(dpToPx(3));
            rulerBaseTickPaint.setStyle(Paint.Style.STROKE);

            rulerMovingTickPaint.setColor(Color.parseColor("#06B6D4"));
            rulerMovingTickPaint.setStrokeWidth(dpToPx(3));
            rulerMovingTickPaint.setStyle(Paint.Style.FILL_AND_STROKE);

            rulerPredictedPaint.setColor(Color.parseColor("#FACC15"));
            rulerPredictedPaint.setStyle(Paint.Style.FILL);

            rulerLabelPaint.setColor(Color.parseColor("#E2E8F0"));
            rulerLabelPaint.setTypeface(Typeface.MONOSPACE);
            rulerLabelPaint.setTextSize(TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_SP, 10, getResources().getDisplayMetrics()));

            rhombusFillPaint.setColor(Color.argb(46, 34, 197, 94));
            rhombusFillPaint.setStyle(Paint.Style.FILL);

            rhombusStrokePaint.setColor(Color.parseColor("#22C55E"));
            rhombusStrokePaint.setStrokeWidth(dpToPx(2));
            rhombusStrokePaint.setStyle(Paint.Style.STROKE);

            tripwireEdgePaint.setColor(Color.parseColor("#00E676"));
            tripwireEdgePaint.setStrokeWidth(dpToPx(3));
            tripwireEdgePaint.setStyle(Paint.Style.STROKE);
            tripwireEdgePaint.setPathEffect(new DashPathEffect(new float[]{12f, 8f}, 0f));

            crosshairPaint.setColor(Color.parseColor("#FACC15"));
            crosshairPaint.setStrokeWidth(dpToPx(2));
            crosshairPaint.setStyle(Paint.Style.STROKE);

            tapCircleFillPaint.setColor(Color.argb(185, 16, 185, 129));
            tapCircleFillPaint.setStyle(Paint.Style.FILL);

            tapCircleStrokePaint.setColor(Color.WHITE);
            tapCircleStrokePaint.setStrokeWidth(dpToPx(2));
            tapCircleStrokePaint.setStyle(Paint.Style.STROKE);

            labelPaint.setColor(Color.WHITE);
            labelPaint.setTypeface(Typeface.DEFAULT_BOLD);
            labelPaint.setTextAlign(Paint.Align.CENTER);
            labelPaint.setTextSize(TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_SP, 11, getResources().getDisplayMetrics()));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) {
                return;
            }

            // 1. REGLA HUD HORIZONTAL SUPERIOR EN Y = 0.25f (FUERA DE LA ZONA DE LA TORRE)
            float rulerCenterY = 0.25f * h;
            float rulerHeight = dpToPx(36);
            hudRulerRect.set(w * 0.05f, rulerCenterY - (rulerHeight * 0.5f), w * 0.95f, rulerCenterY + (rulerHeight * 0.5f));
            canvas.drawRoundRect(hudRulerRect, dpToPx(8), dpToPx(8), rulerBgPaint);
            canvas.drawLine(hudRulerRect.left + dpToPx(8), rulerCenterY, hudRulerRect.right - dpToPx(8), rulerCenterY, rulerAxisPaint);

            float offsetPx = triggerEngine.getCenterOffsetPx();
            float baseLeftX = ((renderBaseLeftX > 0.0f) ? renderBaseLeftX : (w * 0.32f)) - offsetPx;
            float baseRightX = ((renderBaseRightX > 0.0f) ? renderBaseRightX : (w * 0.68f)) - offsetPx;
            float baseCenterX = (baseLeftX + baseRightX) * 0.5f;

            // Marcas verdes de la Cara Superior Base: [baseLeftX, baseCenterX, baseRightX]
            canvas.drawLine(baseLeftX, rulerCenterY - dpToPx(12), baseLeftX, rulerCenterY + dpToPx(12), rulerBaseTickPaint);
            canvas.drawLine(baseRightX, rulerCenterY - dpToPx(12), baseRightX, rulerCenterY + dpToPx(12), rulerBaseTickPaint);
            canvas.drawLine(baseCenterX, rulerCenterY - dpToPx(16), baseCenterX, rulerCenterY + dpToPx(16), rulerBaseTickPaint);

            // Marcas de la Cara Superior Móvil: [movingLeftX, trueMovingCenterX, movingRightX]
            if (renderMovingDetected && renderTrueMovingCenterX > 0.0f) {
                canvas.drawLine(renderMovingLeftX, rulerCenterY - dpToPx(8), renderMovingLeftX, rulerCenterY + dpToPx(8), rulerMovingTickPaint);
                canvas.drawLine(renderMovingRightX, rulerCenterY - dpToPx(8), renderMovingRightX, rulerCenterY + dpToPx(8), rulerMovingTickPaint);
                canvas.drawCircle(renderTrueMovingCenterX, rulerCenterY, dpToPx(5), rulerMovingTickPaint);

                float clampedPredX = Math.max(
                        hudRulerRect.left + dpToPx(10),
                        Math.min(hudRulerRect.right - dpToPx(10), renderPredictedCenterX));
                canvas.drawCircle(clampedPredX, rulerCenterY, dpToPx(5), rulerPredictedPaint);
            }

            String hudLabel = autoStackEnabled
                    ? "HUD 60FPS: CARA SUPERIOR ACTIVA (VENTANA ≤ 35PX)"
                    : (calibrationMode ? "MODO CALIBRAR: AJUSTA ROMBO ⊕ Y PUNTO (TAP)" : "PAUSADO (ROMBO CEÑIDO A LA CIMA)");
            canvas.drawText(hudLabel, hudRulerRect.left + dpToPx(10), hudRulerRect.top + dpToPx(12), rulerLabelPaint);

            // 2. CUANDO autoStackEnabled == true, NO DIBUJAR NADA SOBRE LA TORRE NI SOBRE EL PUNTO DE TOQUE
            if (autoStackEnabled) {
                return;
            }

            // 3. GUÍA VISUAL DEL ROMBO DE LA CARA SUPERIOR MÁS ALTA (Solo con Auto-Stack: OFF)
            float centerY = (renderBaseCenterY > 0) ? renderBaseCenterY : (stackTracker.getBaseScanYNorm() * h);
            float halfW = (baseRightX - baseLeftX) * 0.5f;
            float halfH = Math.max(dpToPx(22), halfW * 0.48f);

            float topY = (renderTowerTopY > 0 && renderTowerTopY < centerY - dpToPx(10))
                    ? renderTowerTopY
                    : (centerY - halfH);
            float frontY = (renderBaseFrontY > centerY + dpToPx(10))
                    ? renderBaseFrontY
                    : (centerY + halfH);
            float topX = (renderTopVertexX > 0.0f) ? (renderTopVertexX - offsetPx) : baseCenterX;
            float frontX = (renderBaseFrontX > 0.0f) ? (renderBaseFrontX - offsetPx) : baseCenterX;

            // Rombo verde ciñendo exclusivamente la Cara Superior del bloque más alto
            rhombusPath.reset();
            rhombusPath.moveTo(topX, topY);
            rhombusPath.lineTo(baseRightX, centerY);
            rhombusPath.lineTo(frontX, frontY);
            rhombusPath.lineTo(baseLeftX, centerY);
            rhombusPath.close();

            canvas.drawPath(rhombusPath, rhombusFillPaint);
            canvas.drawPath(rhombusPath, rhombusStrokePaint);

            // Líneas verticales verdes baseLeftX y baseRightX coincidiendo con las puntas de la cima
            canvas.drawLine(baseLeftX, topY - dpToPx(36), baseLeftX, frontY + dpToPx(18), tripwireEdgePaint);
            canvas.drawLine(baseRightX, topY - dpToPx(36), baseRightX, frontY + dpToPx(18), tripwireEdgePaint);

            // Miras (⊕) en Vértice Izquierdo, Vértice Derecho, Centro y Vértice Frontal
            drawPrecisionCrosshair(canvas, baseLeftX, centerY, "⊕ baseLeftX");
            drawPrecisionCrosshair(canvas, baseRightX, centerY, "⊕ baseRightX");
            drawPrecisionCrosshair(canvas, baseCenterX, centerY, "⊕ baseCenterX");
            drawPrecisionCrosshair(canvas, frontX, frontY, "⊕ FRENTE");

            // 4. Punto Verde Arrastrable (TAP) en la zona real del juego (por defecto 0.50f, 0.715f)
            float tapX = TapAccessibilityService.getTapXNorm() * w;
            float tapY = TapAccessibilityService.getTapYNorm() * h;
            float tapRadius = dpToPx(20);
            canvas.drawCircle(tapX, tapY, tapRadius, tapCircleFillPaint);
            canvas.drawCircle(tapX, tapY, tapRadius, tapCircleStrokePaint);
            canvas.drawLine(tapX - dpToPx(8), tapY, tapX + dpToPx(8), tapY, tapCircleStrokePaint);
            canvas.drawLine(tapX, tapY - dpToPx(8), tapX, tapY + dpToPx(8), tapCircleStrokePaint);
            canvas.drawText(
                    String.format(Locale.US, "TAP (%.2f, %.2f)", TapAccessibilityService.getTapXNorm(), TapAccessibilityService.getTapYNorm()),
                    tapX,
                    tapY + tapRadius + dpToPx(14),
                    labelPaint);
        }

        private void drawPrecisionCrosshair(Canvas canvas, float x, float y, String tag) {
            float r = dpToPx(10);
            canvas.drawCircle(x, y, r, crosshairPaint);
            canvas.drawLine(x - r - dpToPx(4), y, x + r + dpToPx(4), y, crosshairPaint);
            canvas.drawLine(x, y - r - dpToPx(4), x, y + r + dpToPx(4), crosshairPaint);
            if (calibrationMode && tag != null) {
                canvas.drawText(tag, x, y - r - dpToPx(6), labelPaint);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (!calibrationMode) {
                return false;
            }
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) {
                return false;
            }
            float touchX = event.getX();
            float touchY = event.getY();

            float tapX = TapAccessibilityService.getTapXNorm() * w;
            float tapY = TapAccessibilityService.getTapYNorm() * h;
            float centerX = (renderBaseCenterX > 0.0f) ? renderBaseCenterX : (stackTracker.getManualTargetXNorm() * w);
            float centerY = (renderBaseCenterY > 0) ? renderBaseCenterY : (stackTracker.getBaseScanYNorm() * h);
            float leftVertexX = (renderBaseLeftX > 0.0f) ? renderBaseLeftX : (centerX - stackTracker.getManualHalfWidthNorm() * w);
            float rightVertexX = (renderBaseRightX > 0.0f) ? renderBaseRightX : (centerX + stackTracker.getManualHalfWidthNorm() * w);

            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    float distTap = hypot(touchX - tapX, touchY - tapY);
                    float distLeft = hypot(touchX - leftVertexX, touchY - centerY);
                    float distRight = hypot(touchX - rightVertexX, touchY - centerY);
                    float grabRadius = dpToPx(42);

                    if (distTap <= grabRadius) {
                        activeDragHandle = DRAG_TAP_POINT;
                    } else if (distLeft <= grabRadius && distLeft < distRight) {
                        activeDragHandle = DRAG_LEFT_VERTEX;
                    } else if (distRight <= grabRadius) {
                        activeDragHandle = DRAG_RIGHT_VERTEX;
                    } else {
                        activeDragHandle = DRAG_RHOMBUS_CENTER;
                    }
                    applyCalibrationTouch(touchX, touchY, w, h);
                    return true;

                case MotionEvent.ACTION_MOVE:
                    applyCalibrationTouch(touchX, touchY, w, h);
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    activeDragHandle = DRAG_NONE;
                    stackTracker.enforceAntiInversionRule();
                    saveConfigurationToPrefs();
                    invalidate();
                    return true;

                default:
                    return false;
            }
        }

        private void applyCalibrationTouch(float touchX, float touchY, int w, int h) {
            float normX = touchX / (float) w;
            float normY = touchY / (float) h;

            if (activeDragHandle == DRAG_TAP_POINT) {
                TapAccessibilityService.setTapPointNorm(normX, normY);
            } else if (activeDragHandle == DRAG_LEFT_VERTEX) {
                float currentCenterNorm = stackTracker.getManualTargetXNorm();
                float newHalfWidthNorm = Math.max(0.07f, Math.min(0.42f, currentCenterNorm - normX));
                stackTracker.setManualHalfWidthNorm(newHalfWidthNorm);
                stackTracker.setAutoBaseMode(false);
                syncRenderStateFromTracker();
                updateControlButtonsAppearance();
            } else if (activeDragHandle == DRAG_RIGHT_VERTEX) {
                float currentCenterNorm = stackTracker.getManualTargetXNorm();
                float newHalfWidthNorm = Math.max(0.07f, Math.min(0.42f, normX - currentCenterNorm));
                stackTracker.setManualHalfWidthNorm(newHalfWidthNorm);
                stackTracker.setAutoBaseMode(false);
                syncRenderStateFromTracker();
                updateControlButtonsAppearance();
            } else if (activeDragHandle == DRAG_RHOMBUS_CENTER) {
                stackTracker.setManualTargetXNorm(normX);
                stackTracker.setBaseScanYNorm(normY);
                stackTracker.setMovingScanYNorm(stackTracker.getBaseScanYNorm() - 0.045f);
                stackTracker.setAutoBaseMode(false);
                syncRenderStateFromTracker();
                updateControlButtonsAppearance();
            }
            invalidate();
        }

        private float hypot(float dx, float dy) {
            return (float) Math.sqrt(dx * dx + dy * dy);
        }
    }
}
