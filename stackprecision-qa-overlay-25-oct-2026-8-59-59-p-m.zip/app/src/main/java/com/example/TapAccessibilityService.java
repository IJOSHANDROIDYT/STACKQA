package com.example;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.ComponentName;
import android.content.Context;
import android.graphics.Path;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;

/**
 * Servicio de Accesibilidad para Disparo Táctil de Ultra-Baja Latencia (TapAccessibilityService).
 * - Coordenada por defecto en la zona real de recepción de toque del juego:
 *   X = 0.50f * screenWidth, Y = 0.715f * screenHeight (sobre el cuerpo inferior de la torre / "Tap to play").
 * - Soporta ajuste interactivo de la coordenada (TAP) desde el modo Calibrar Ejes.
 * - Ejecuta un gesto limpio y firme de 35ms (moveTo(tapX, tapY) -> lineTo(tapX, tapY + 1f))
 *   sin dibujar destellos en el overlay durante Auto-Stack: ON.
 */
public final class TapAccessibilityService extends AccessibilityService {

    public static final float DEFAULT_SAFE_TAP_X_NORM = 0.50f;
    public static final float DEFAULT_SAFE_TAP_Y_NORM = 0.715f;
    public static final long ULTRA_FAST_TAP_DURATION_MS = 35L;
    private static final float MICRO_STROKE_DELTA_Y_PX = 1.0f;

    private static volatile TapAccessibilityService instance;
    private static volatile LocalTapListener localTapListener;

    private static volatile float customTapXNorm = DEFAULT_SAFE_TAP_X_NORM;
    private static volatile float customTapYNorm = DEFAULT_SAFE_TAP_Y_NORM;

    public interface LocalTapListener {
        void onFastTapDispatched(float tapX, float tapY, long timestampNs);
    }

    public static TapAccessibilityService getInstance() {
        return instance;
    }

    public static void setLocalTapListener(LocalTapListener listener) {
        localTapListener = listener;
    }

    /**
     * Permite configurar la posición normalizada del punto (TAP) cuando el usuario lo arrastra
     * en modo Calibrar.
     */
    public static void setTapPointNorm(float xNorm, float yNorm) {
        if (!Float.isNaN(xNorm) && !Float.isNaN(yNorm)) {
            customTapXNorm = clamp(xNorm, 0.08f, 0.92f);
            customTapYNorm = clamp(yNorm, 0.12f, 0.92f);
        }
    }

    public static float getTapXNorm() {
        return customTapXNorm;
    }

    public static float getTapYNorm() {
        return customTapYNorm;
    }

    public static void resetTapPointToDefaults() {
        customTapXNorm = DEFAULT_SAFE_TAP_X_NORM;
        customTapYNorm = DEFAULT_SAFE_TAP_Y_NORM;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Sin procesamiento de eventos de ventana para preservar latencia mínima
    }

    @Override
    public void onInterrupt() {
        // Requerido por el contrato de AccessibilityService
    }

    @Override
    public void onDestroy() {
        if (instance == this) {
            instance = null;
        }
        super.onDestroy();
    }

    /**
     * Ejecuta el toque firme de 35ms en la coordenada configurada (por defecto 0.50f * W, 0.715f * H).
     */
    public boolean performSafeUpperTap(int screenWidth, int screenHeight) {
        float tapX = customTapXNorm * screenWidth;
        float tapY = customTapYNorm * screenHeight;
        return performUltraFastTap(tapX, tapY);
    }

    /**
     * Ejecuta un GestureDescription limpio y firme de 35ms con trazo vertical de 1px
     * (moveTo(tapX, tapY) -> lineTo(tapX, tapY + 1f)) para garantizar el registro inmediato
     * del toque en el motor 3D del juego.
     */
    public boolean performUltraFastTap(float tapX, float tapY) {
        try {
            long nowNs = System.nanoTime();
            LocalTapListener listener = localTapListener;
            if (listener != null) {
                listener.onFastTapDispatched(tapX, tapY, nowNs);
            }

            DisplayMetrics dm = getResources().getDisplayMetrics();
            float safeX = Math.max(12.0f, Math.min(tapX, dm.widthPixels - 12.0f));
            float safeY = Math.max(12.0f, Math.min(tapY, dm.heightPixels - 14.0f));

            Path tapPath = new Path();
            tapPath.moveTo(safeX, safeY);
            tapPath.lineTo(safeX, safeY + MICRO_STROKE_DELTA_Y_PX);

            GestureDescription.StrokeDescription stroke =
                    new GestureDescription.StrokeDescription(tapPath, 0L, ULTRA_FAST_TAP_DURATION_MS);

            GestureDescription gesture = new GestureDescription.Builder()
                    .addStroke(stroke)
                    .build();

            return dispatchGesture(gesture, null, null);
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * Despacha el toque de 35ms en (customTapXNorm * screenWidth, customTapYNorm * screenHeight)
     * — por defecto (0.50f * screenWidth, 0.715f * screenHeight) — a través del servicio de
     * accesibilidad o hacia el banco de pruebas local.
     */
    public static boolean dispatchGlobalOrLocalSafeTap(int screenWidth, int screenHeight) {
        try {
            float tapX = customTapXNorm * screenWidth;
            float tapY = customTapYNorm * screenHeight;
            return dispatchCustomCoordinateTap(tapX, tapY);
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * Despacha un toque de 35ms en coordenadas de píxel explícitas.
     */
    public static boolean dispatchCustomCoordinateTap(float tapX, float tapY) {
        try {
            TapAccessibilityService service = instance;
            if (service != null) {
                return service.performUltraFastTap(tapX, tapY);
            }

            LocalTapListener listener = localTapListener;
            if (listener != null) {
                listener.onFastTapDispatched(tapX, tapY, System.nanoTime());
                return true;
            }
            return false;
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * Comprueba si TapAccessibilityService se encuentra habilitado en Ajustes del Sistema.
     */
    public static boolean isServiceEnabled(Context context) {
        try {
            if (instance != null) {
                return true;
            }
            if (context == null) {
                return false;
            }
            ComponentName expectedComponent = new ComponentName(context, TapAccessibilityService.class);
            String enabledServices = Settings.Secure.getString(
                    context.getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (TextUtils.isEmpty(enabledServices)) {
                return false;
            }
            TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
            splitter.setString(enabledServices);
            while (splitter.hasNext()) {
                String componentStr = splitter.next();
                ComponentName enabledComponent = ComponentName.unflattenFromString(componentStr);
                if (enabledComponent != null && enabledComponent.equals(expectedComponent)) {
                    return true;
                }
            }
            return false;
        } catch (Throwable t) {
            return false;
        }
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
