package com.example;

import android.os.SystemClock;
import java.util.Arrays;
import java.util.concurrent.locks.LockSupport;

/**
 * Predictor Cinemático Simétrico de Encaje 3D sobre la Cara Superior (PredictiveTriggerEngine):
 * Con trueMovingCenterX y baseCenterX medidos ambos exclusivamente sobre la Cara Superior:
 * 1. Calcula la velocidad horizontal vx = (trueMovingCenterX_now - trueMovingCenterX_prev) / dtMs
 *    con filtrado de mediana sobre 3 fotogramas.
 * 2. Exige que la pieza se esté acercando hacia baseCenterX:
 *    - Si viene desde la IZQUIERDA (vx > +0.15f), trueMovingCenterX <= baseCenterX.
 *    - Si viene desde la DERECHA (vx < -0.15f), trueMovingCenterX >= baseCenterX.
 * 3. Predice la posición con LEAD_TIME_MS (por defecto 22ms):
 *    predictedCenterX = trueMovingCenterX + (vx * LEAD_TIME_MS) + CENTER_OFFSET_PX
 * 4. Regla estricta para NO disparar antes de tiempo (umbral máximo de aproximación de 35px):
 *    - Cuando viene de la IZQUIERDA (vx > 0): SOLO dispara cuando trueMovingCenterX esté a menos de 35px
 *      de baseCenterX y predictedCenterX >= baseCenterX.
 *    - Cuando viene de la DERECHA (vx < 0): SOLO dispara cuando trueMovingCenterX esté a menos de 35px
 *      de baseCenterX y predictedCenterX <= baseCenterX.
 * 5. Enfriamiento de 280ms tras el disparo para re-escanear la nueva Cara Superior más alta.
 */
public final class PredictiveTriggerEngine {

    public static final float DEFAULT_LEAD_TIME_MS = 22.0f;
    public static final float DEFAULT_CENTER_OFFSET_PX = 0.0f;
    public static final float DEFAULT_TOLERANCE_PX = 2.0f;
    public static final long DEFAULT_COOLDOWN_MS = 280L;

    public static final float MIN_VALID_VELOCITY_PX_PER_MS = 0.15f;
    public static final float MAX_VALID_VELOCITY_PX_PER_MS = 3.80f;

    // Regla estricta: prohibido disparar si |trueMovingCenterX - baseCenterX| > 35px
    public static final float MAX_TRIGGER_APPROACH_DISTANCE_PX = 35.0f;

    private static final int HISTORY_CAPACITY = 3;
    private static final float MAX_FRAME_GAP_MS = 110.0f;
    private static final float SUB_FRAME_MAX_WAIT_MS = 12.0f;

    private final long[] historyTimestampNs = new long[HISTORY_CAPACITY];
    private final float[] historyTrueCenterX = new float[HISTORY_CAPACITY];
    private final float[] velocityScratch = new float[HISTORY_CAPACITY];
    private int historyCount = 0;

    private int consecutiveSameDirectionCount = 0;
    private float lastObservedDirectionSign = 0.0f;

    private volatile float leadTimeMs = DEFAULT_LEAD_TIME_MS;
    private volatile float centerOffsetPx = DEFAULT_CENTER_OFFSET_PX;
    private volatile float tolerancePx = DEFAULT_TOLERANCE_PX;
    private volatile long cooldownMs = DEFAULT_COOLDOWN_MS;
    private volatile boolean waitAndSnapEnabled = true;

    private float lastPredictedCenterX = -1.0f;
    private float currentVelocityPxPerMs = 0.0f;
    private long lastTriggerUptimeMs = -10_000L;
    private int totalShotsFired = 0;

    private final PredictionDecision reusableDecision = new PredictionDecision();

    public enum TriggerState {
        COOLDOWN,
        SEARCHING,
        TRACKING,
        WAIT_AND_SNAP_FIRED,
        IMMEDIATE_FIRED
    }

    public static final class PredictionDecision {
        public TriggerState state = TriggerState.SEARCHING;
        public boolean shouldFire = false;
        public long subFrameWaitNanos = 0L;
        public float velocityPxPerMs = 0.0f;

        // Centros reales y predichos sobre la Cara Superior
        public float predictedX = 0.0f;
        public float targetCenterX = 0.0f;
        public float centerErrorPx = 0.0f;

        // Campos adicionales de telemetría compatibles con el HUD
        public boolean trackingRightLeadingEdge = true;
        public float activeLeadingEdgeX = 0.0f;
        public float predictedLeadingEdgeX = 0.0f;
        public float targetLeadingEdgeX = 0.0f;
        public float leadingEdgeErrorPx = 0.0f;
        public float timeToImpactMs = -1.0f;
    }

    public PredictiveTriggerEngine() {
    }

    public void setLeadTimeMs(float leadTimeMs) {
        this.leadTimeMs = clamp(leadTimeMs, 0.0f, 80.0f);
    }

    public float getLeadTimeMs() {
        return leadTimeMs;
    }

    public void adjustLeadTimeMs(float deltaMs) {
        setLeadTimeMs(this.leadTimeMs + deltaMs);
    }

    public void setCenterOffsetPx(float offsetPx) {
        this.centerOffsetPx = clamp(offsetPx, -40.0f, 40.0f);
    }

    public float getCenterOffsetPx() {
        return centerOffsetPx;
    }

    public void adjustCenterOffsetPx(float deltaPx) {
        setCenterOffsetPx(this.centerOffsetPx + deltaPx);
    }

    public void setTolerancePx(float tolerancePx) {
        this.tolerancePx = clamp(tolerancePx, 1.0f, 24.0f);
    }

    public float getTolerancePx() {
        return tolerancePx;
    }

    public void setCooldownMs(long cooldownMs) {
        this.cooldownMs = Math.max(120L, Math.min(1200L, cooldownMs));
    }

    public long getCooldownMs() {
        return cooldownMs;
    }

    public void setWaitAndSnapEnabled(boolean enabled) {
        this.waitAndSnapEnabled = enabled;
    }

    public boolean isWaitAndSnapEnabled() {
        return waitAndSnapEnabled;
    }

    public int getTotalShotsFired() {
        return totalShotsFired;
    }

    public void resetHistory() {
        historyCount = 0;
        lastPredictedCenterX = -1.0f;
        currentVelocityPxPerMs = 0.0f;
        consecutiveSameDirectionCount = 0;
        lastObservedDirectionSign = 0.0f;
    }

    public void resetStats() {
        resetHistory();
        totalShotsFired = 0;
        lastTriggerUptimeMs = -10_000L;
    }

    /**
     * Evalúa un ScanResult completo empleando trueMovingCenterX (autoverificado con baseWidth)
     * frente a effectiveTargetCenterX (baseCenterX de la Cara Superior).
     */
    public PredictionDecision evaluateScanResult(
            IsometricStackTracker.ScanResult scan,
            boolean autoStackEnabled) {
        if (scan == null || !scan.validFrame) {
            resetHistory();
            reusableDecision.shouldFire = false;
            reusableDecision.state = TriggerState.SEARCHING;
            return reusableDecision;
        }
        float movCenter = (scan.trueMovingCenterX > 0.0f) ? scan.trueMovingCenterX : scan.movingCenterX;
        return evaluateFrame(
                scan.movingDetected,
                movCenter,
                scan.effectiveTargetCenterX,
                scan.timestampNs,
                autoStackEnabled);
    }

    /**
     * Sobrecarga compatible que delega a la condición simétrica de encaje sobre trueMovingCenterX.
     */
    public PredictionDecision evaluateLeadingEdgeFrame(
            boolean movingDetected,
            float movingLeftEdgeX,
            float movingRightEdgeX,
            float movingCenterX,
            float baseLeftEdgeX,
            float baseRightEdgeX,
            float baseCenterX,
            long frameTimestampNs,
            boolean autoStackEnabled) {

        float baseWidth = Math.max(0.0f, baseRightEdgeX - baseLeftEdgeX);
        float trueMovingCenterX = movingCenterX;
        if (baseWidth > 32.0f) {
            // Autoverificación de ancho: si un extremo está cortado en el borde de la pantalla,
            // reconstruir trueMovingCenterX desde el vértice interior visible
            if (movingLeftEdgeX <= 88.0f && movingRightEdgeX > movingLeftEdgeX) {
                trueMovingCenterX = movingRightEdgeX - (baseWidth * 0.5f);
            } else if (movingRightEdgeX >= 980.0f && movingRightEdgeX > movingLeftEdgeX) {
                trueMovingCenterX = movingLeftEdgeX + (baseWidth * 0.5f);
            }
        }
        return evaluateFrame(
                movingDetected,
                trueMovingCenterX,
                baseCenterX,
                frameTimestampNs,
                autoStackEnabled);
    }

    /**
     * REGLA 3: CONDICIÓN DE DISPARO SIN ADELANTOS NI ATRASOS:
     * 1. Calcula vx = (trueMovingCenterX_now - trueMovingCenterX_prev) / dtMs.
     * 2. Exige que la pieza se esté acercando hacia baseCenterX:
     *    - Si viene desde la IZQUIERDA (vx > +0.15f), trueMovingCenterX <= baseCenterX.
     *    - Si viene desde la DERECHA (vx < -0.15f), trueMovingCenterX >= baseCenterX.
     * 3. Predice: predictedCenterX = trueMovingCenterX + (vx * LEAD_TIME_MS) + CENTER_OFFSET_PX.
     * 4. Regla estricta para NO disparar antes de tiempo:
     *    - Cuando viene de la IZQUIERDA (vx > 0): SOLO dispara cuando trueMovingCenterX esté a menos
     *      de 35px de baseCenterX y predictedCenterX >= baseCenterX.
     *    - Cuando viene de la DERECHA (vx < 0): SOLO dispara cuando trueMovingCenterX esté a menos
     *      de 35px de baseCenterX y predictedCenterX <= baseCenterX.
     */
    public PredictionDecision evaluateFrame(
            boolean movingDetected,
            float trueMovingCenterX,
            float baseCenterX,
            long frameTimestampNs,
            boolean autoStackEnabled) {

        try {
            reusableDecision.shouldFire = false;
            reusableDecision.subFrameWaitNanos = 0L;
            reusableDecision.targetCenterX = baseCenterX;
            reusableDecision.targetLeadingEdgeX = baseCenterX;
            reusableDecision.centerErrorPx = trueMovingCenterX - baseCenterX;
            reusableDecision.leadingEdgeErrorPx = reusableDecision.centerErrorPx;
            reusableDecision.timeToImpactMs = -1.0f;

            long nowUptimeMs = SystemClock.uptimeMillis();
            if (nowUptimeMs - lastTriggerUptimeMs < cooldownMs) {
                reusableDecision.state = TriggerState.COOLDOWN;
                reusableDecision.velocityPxPerMs = 0.0f;
                reusableDecision.predictedX = baseCenterX;
                reusableDecision.predictedLeadingEdgeX = baseCenterX;
                return reusableDecision;
            }

            if (!movingDetected || trueMovingCenterX <= 0.0f) {
                resetHistory();
                reusableDecision.state = TriggerState.SEARCHING;
                reusableDecision.velocityPxPerMs = 0.0f;
                reusableDecision.predictedX = baseCenterX;
                reusableDecision.predictedLeadingEdgeX = baseCenterX;
                return reusableDecision;
            }

            if (historyCount > 0) {
                long prevTimeNs = historyTimestampNs[historyCount - 1];
                float deltaMs = (frameTimestampNs - prevTimeNs) / 1_000_000.0f;
                if (deltaMs <= 0.1f || deltaMs > MAX_FRAME_GAP_MS) {
                    resetHistory();
                } else {
                    float jumpPx = Math.abs(trueMovingCenterX - historyTrueCenterX[historyCount - 1]);
                    if (jumpPx > 180.0f) {
                        resetHistory();
                    }
                }
            }

            if (historyCount < HISTORY_CAPACITY) {
                historyTimestampNs[historyCount] = frameTimestampNs;
                historyTrueCenterX[historyCount] = trueMovingCenterX;
                historyCount++;
            } else {
                historyTimestampNs[0] = historyTimestampNs[1];
                historyTrueCenterX[0] = historyTrueCenterX[1];
                historyTimestampNs[1] = historyTimestampNs[2];
                historyTrueCenterX[1] = historyTrueCenterX[2];
                historyTimestampNs[2] = frameTimestampNs;
                historyTrueCenterX[2] = trueMovingCenterX;
            }

            if (historyCount < 2) {
                reusableDecision.state = TriggerState.TRACKING;
                reusableDecision.velocityPxPerMs = 0.0f;
                reusableDecision.activeLeadingEdgeX = trueMovingCenterX;
                reusableDecision.predictedX = trueMovingCenterX + centerOffsetPx;
                reusableDecision.predictedLeadingEdgeX = reusableDecision.predictedX;
                lastPredictedCenterX = -1.0f;
                return reusableDecision;
            }

            // 1. Calcular velocidad horizontal vx = (trueMovingCenterX_now - trueMovingCenterX_prev) / dtMs
            float vx = computeFilteredCenterVelocity();
            this.currentVelocityPxPerMs = vx;
            float absVx = Math.abs(vx);

            // 3. Predecir posición con LEAD_TIME_MS (por defecto 22ms)
            float predictedCenterX = trueMovingCenterX + (vx * leadTimeMs) + centerOffsetPx;

            reusableDecision.velocityPxPerMs = vx;
            reusableDecision.trackingRightLeadingEdge = (vx >= 0.0f);
            reusableDecision.activeLeadingEdgeX = trueMovingCenterX;
            reusableDecision.predictedX = predictedCenterX;
            reusableDecision.predictedLeadingEdgeX = predictedCenterX;
            reusableDecision.state = TriggerState.TRACKING;

            float currentSign = Math.signum(vx);
            if (absVx >= MIN_VALID_VELOCITY_PX_PER_MS && currentSign == lastObservedDirectionSign) {
                consecutiveSameDirectionCount++;
            } else if (absVx >= MIN_VALID_VELOCITY_PX_PER_MS) {
                consecutiveSameDirectionCount = 1;
                lastObservedDirectionSign = currentSign;
            } else {
                consecutiveSameDirectionCount = 0;
            }

            boolean validDirectionConfidence = (consecutiveSameDirectionCount >= 2);
            if (!autoStackEnabled
                    || absVx < MIN_VALID_VELOCITY_PX_PER_MS
                    || absVx > MAX_VALID_VELOCITY_PX_PER_MS
                    || !validDirectionConfidence) {
                lastPredictedCenterX = predictedCenterX;
                return reusableDecision;
            }

            // 4. REGLA ESTRICTA PARA NO DISPARAR ANTES DE TIEMPO:
            //    - Si viene desde la IZQUIERDA (vx > +0.15f):
            //      SOLO dispara cuando trueMovingCenterX esté a menos de 35px de baseCenterX
            //      (0 <= baseCenterX - trueMovingCenterX <= 35px) y predictedCenterX >= baseCenterX.
            if (vx >= MIN_VALID_VELOCITY_PX_PER_MS) {
                float distanceFromLeftPx = baseCenterX - trueMovingCenterX;

                if (distanceFromLeftPx <= MAX_TRIGGER_APPROACH_DISTANCE_PX && distanceFromLeftPx >= -6.0f) {
                    if (predictedCenterX >= baseCenterX) {
                        markTriggered(nowUptimeMs);
                        reusableDecision.shouldFire = true;
                        reusableDecision.subFrameWaitNanos = 0L;
                        reusableDecision.timeToImpactMs = 0.0f;
                        reusableDecision.state = TriggerState.IMMEDIATE_FIRED;
                        return reusableDecision;
                    }

                    // Si falta menos de un fotograma (< 12ms) y ya está dentro de los 35px finales
                    float remainingPx = baseCenterX - predictedCenterX;
                    float timeToImpactMs = remainingPx / vx;
                    reusableDecision.timeToImpactMs = timeToImpactMs;
                    if (waitAndSnapEnabled && timeToImpactMs > 0.0f && timeToImpactMs <= SUB_FRAME_MAX_WAIT_MS) {
                        long waitNanos = (long) (timeToImpactMs * 1_000_000.0f);
                        markTriggered(nowUptimeMs + Math.round(timeToImpactMs));
                        reusableDecision.shouldFire = true;
                        reusableDecision.subFrameWaitNanos = waitNanos;
                        reusableDecision.state = TriggerState.WAIT_AND_SNAP_FIRED;
                        return reusableDecision;
                    }
                }
            }
            //    - Si viene desde la DERECHA (vx < -0.15f):
            //      SOLO dispara cuando trueMovingCenterX esté a menos de 35px de baseCenterX
            //      (0 <= trueMovingCenterX - baseCenterX <= 35px) y predictedCenterX <= baseCenterX.
            else if (vx <= -MIN_VALID_VELOCITY_PX_PER_MS) {
                float distanceFromRightPx = trueMovingCenterX - baseCenterX;

                if (distanceFromRightPx <= MAX_TRIGGER_APPROACH_DISTANCE_PX && distanceFromRightPx >= -6.0f) {
                    if (predictedCenterX <= baseCenterX) {
                        markTriggered(nowUptimeMs);
                        reusableDecision.shouldFire = true;
                        reusableDecision.subFrameWaitNanos = 0L;
                        reusableDecision.timeToImpactMs = 0.0f;
                        reusableDecision.state = TriggerState.IMMEDIATE_FIRED;
                        return reusableDecision;
                    }

                    // Si falta menos de un fotograma (< 12ms) y ya está dentro de los 35px finales
                    float remainingPx = baseCenterX - predictedCenterX; // negativo
                    float timeToImpactMs = remainingPx / vx; // negativo / negativo = positivo
                    reusableDecision.timeToImpactMs = timeToImpactMs;
                    if (waitAndSnapEnabled && timeToImpactMs > 0.0f && timeToImpactMs <= SUB_FRAME_MAX_WAIT_MS) {
                        long waitNanos = (long) (timeToImpactMs * 1_000_000.0f);
                        markTriggered(nowUptimeMs + Math.round(timeToImpactMs));
                        reusableDecision.shouldFire = true;
                        reusableDecision.subFrameWaitNanos = waitNanos;
                        reusableDecision.state = TriggerState.WAIT_AND_SNAP_FIRED;
                        return reusableDecision;
                    }
                }
            }

            lastPredictedCenterX = predictedCenterX;
            return reusableDecision;
        } catch (Throwable t) {
            reusableDecision.shouldFire = false;
            return reusableDecision;
        }
    }

    private float computeFilteredCenterVelocity() {
        if (historyCount < 2) {
            return 0.0f;
        }
        int last = historyCount - 1;
        float dtLast = (historyTimestampNs[last] - historyTimestampNs[last - 1]) / 1_000_000.0f;
        float vLast = (dtLast > 0.1f) ? (historyTrueCenterX[last] - historyTrueCenterX[last - 1]) / dtLast : 0.0f;

        if (historyCount < 3) {
            return vLast;
        }

        float dt1 = (historyTimestampNs[1] - historyTimestampNs[0]) / 1_000_000.0f;
        float dtTotal = (historyTimestampNs[2] - historyTimestampNs[0]) / 1_000_000.0f;
        float v1 = (dt1 > 0.1f) ? (historyTrueCenterX[1] - historyTrueCenterX[0]) / dt1 : vLast;
        float vAvg = (dtTotal > 0.2f) ? (historyTrueCenterX[2] - historyTrueCenterX[0]) / dtTotal : vLast;

        velocityScratch[0] = v1;
        velocityScratch[1] = vLast;
        velocityScratch[2] = vAvg;
        Arrays.sort(velocityScratch);
        return velocityScratch[1];
    }

    public static void executeSubFrameSleepIfNeeded(long waitNanos) {
        if (waitNanos <= 0L) {
            return;
        }
        try {
            long clampedNanos = Math.min(waitNanos, 14_000_000L);
            long deadlineNs = System.nanoTime() + clampedNanos;
            if (clampedNanos > 250_000L) {
                LockSupport.parkNanos(clampedNanos - 150_000L);
            }
            while (System.nanoTime() < deadlineNs) {
                Thread.onSpinWait();
            }
        } catch (Throwable ignored) {
        }
    }

    private void markTriggered(long triggerUptimeMs) {
        this.lastTriggerUptimeMs = triggerUptimeMs;
        this.totalShotsFired++;
        resetHistory();
    }

    public float getCurrentVelocityPxPerMs() {
        return currentVelocityPxPerMs;
    }

    private static float clamp(float val, float min, float max) {
        return Math.max(min, Math.min(max, val));
    }
}
