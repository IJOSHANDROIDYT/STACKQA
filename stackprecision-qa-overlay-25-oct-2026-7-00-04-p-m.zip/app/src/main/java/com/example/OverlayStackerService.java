package com.example;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;

/**
 * Servicio en Primer Plano de Superposición (Overlay) y Captura a 60 FPS (OverlayStackerService).
 * Visualiza en tiempo real:
 * 1. Dos líneas verticales láser verdes en baseMinX y baseMaxX (ancho exacto de la cima actual)
 *    y eje central en baseCenterX que sube automáticamente con cada piso en baseCrownY.
 * 2. Rectángulo/marcador cian dinámico alrededor de la losa en movimiento diagonal [movingMinX, movingMaxX]
 *    y punto amarillo en predictedCenterX.
 * 3. Re-captura automática de la nueva base 260ms después de cada disparo y auto-clic opcional en "Tap to play".
 */
public final class OverlayStackerService extends Service {

    public static final String ACTION_START_OVERLAY = "com.example.action.START_OVERLAY";
    public static final String ACTION_STOP_OVERLAY = "com.example.action.STOP_OVERLAY";
    public static final String EXTRA_RESULT_CODE = "extra_result_code";
    public static final String EXTRA_RESULT_DATA = "extra_result_data";

    public static final String PREFS_NAME = "qa_autostacker_prefs";
    public static final String KEY_BASE_SCAN_Y = "base_scan_y_norm";
    public static final String KEY_MOVING_SCAN_Y = "moving_scan_y_norm";
    public static final String KEY_TARGET_X = "target_x_norm";
    public static final String KEY_LEAD_TIME_MS = "lead_time_ms";
    public static final String KEY_CENTER_OFFSET_PX = "center_offset_px";
    public static final String KEY_AUTO_BASE_MODE = "auto_base_mode";
    public static final String KEY_PANEL_SCALE = "panel_scale";

    private static final String CHANNEL_ID = "qa_autostacker_overlay_channel";
    private static final int NOTIFICATION_ID = 1001;

    private static volatile OverlayStackerService runningInstance;

    private WindowManager windowManager;
    private MediaProjectionManager projectionManager;
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;

    private HandlerThread visionThread;
    private Handler visionHandler;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private final IsometricStackTracker stackTracker = new IsometricStackTracker();
    private final PredictiveTriggerEngine triggerEngine = new PredictiveTriggerEngine();

    private SharedPreferences prefs;
    private int screenWidth;
    private int screenHeight;
    private int screenDensityDpi;

    private volatile boolean autoStackEnabled = false;
    private volatile boolean calibrationMode = false;
    private volatile boolean isMinimizedToPill = false;
    private volatile boolean autoTapToPlayEnabled = true;
    private float panelScaleFactor = 1.0f;
    private long lastTapToPlayUptimeMs = -10_000L;

    // Estado visual sincronizado para el Lienzo Láser Dinámico
    private volatile int renderBaseCrownY = 0;
    private volatile boolean renderBaseDetected = false;
    private volatile float renderBaseMinX = 0.0f;
    private volatile float renderBaseMaxX = 0.0f;
    private volatile float renderTargetCenterX = 0.0f;

    private volatile int renderMovingCrownY = 0;
    private volatile boolean renderMovingDetected = false;
    private volatile float renderMovingMinX = 0.0f;
    private volatile float renderMovingMaxX = 0.0f;
    private volatile float renderMovingCenterX = 0.0f;
    private volatile float renderPredictedX = 0.0f;
    private volatile float renderVelocityPxPerMs = 0.0f;
    private volatile float renderAnalysisTimeMs = 0.0f;
    private volatile long lastShotFlashUptimeMs = 0L;
    private volatile String renderStatusText = "LISTO (60 FPS)";

    private LaserCalibrationView laserCalibrationView;
    private WindowManager.LayoutParams laserLayoutParams;

    private LinearLayout floatingRootContainer;
    private LinearLayout expandedPanelContent;
    private TextView miniPillButton;
    private WindowManager.LayoutParams panelLayoutParams;

    private Button btnToggleAutoStack;
    private Button btnToggleCalibrate;
    private Button btnToggleMode;
    private Button btnAutoAxes;
    private TextView txtLeadTimeValue;
    private TextView txtCenterOffsetValue;
    private TextView txtTelemetryLine;

    public static OverlayStackerService getRunningInstance() {
        return runningInstance;
    }

    public IsometricStackTracker getStackTracker() {
        return stackTracker;
    }

    public PredictiveTriggerEngine getTriggerEngine() {
        return triggerEngine;
    }

    public boolean isAutoStackEnabled() {
        return autoStackEnabled;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        runningInstance = this;
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        updateScreenMetrics();
        loadAndValidateSavedConfiguration();
        startVisionThread();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP_OVERLAY.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        int resultCode = Activity.RESULT_CANCELED;
        Intent resultData = null;
        if (intent != null) {
            resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
            resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
        }

        boolean hasProjectionPayload = (resultCode == Activity.RESULT_OK && resultData != null);
        promoteToForeground(hasProjectionPayload);

        if (Settings.canDrawOverlays(this)) {
            ensureOverlayViewsCreated();
        }

        if (hasProjectionPayload) {
            startMediaProjectionCapture(resultCode, resultData);
        }

        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        autoStackEnabled = false;
        stopMediaProjectionCapture();
        removeOverlayViews();
        stopVisionThread();
        if (runningInstance == this) {
            runningInstance = null;
        }
        super.onDestroy();
    }

    private void updateScreenMetrics() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        if (windowManager != null && windowManager.getDefaultDisplay() != null) {
            windowManager.getDefaultDisplay().getRealMetrics(dm);
        }
        screenWidth = Math.max(320, dm.widthPixels);
        screenHeight = Math.max(480, dm.heightPixels);
        screenDensityDpi = dm.densityDpi;
        renderTargetCenterX = stackTracker.getManualTargetXNorm() * screenWidth;
        renderPredictedX = renderTargetCenterX;
        renderBaseCrownY = Math.round(IsometricStackTracker.DEFAULT_BASE_Y_NORM * screenHeight);
        renderMovingCrownY = Math.round(IsometricStackTracker.DEFAULT_MOVING_Y_NORM * screenHeight);
    }

    private void loadAndValidateSavedConfiguration() {
        float savedMovingY = prefs.getFloat(KEY_MOVING_SCAN_Y, IsometricStackTracker.DEFAULT_MOVING_Y_NORM);
        float savedBaseY = prefs.getFloat(KEY_BASE_SCAN_Y, IsometricStackTracker.DEFAULT_BASE_Y_NORM);
        float savedTargetX = prefs.getFloat(KEY_TARGET_X, IsometricStackTracker.DEFAULT_FIXED_AXIS_X_NORM);
        float savedLeadMs = prefs.getFloat(KEY_LEAD_TIME_MS, PredictiveTriggerEngine.DEFAULT_LEAD_TIME_MS);
        float savedOffsetPx = prefs.getFloat(KEY_CENTER_OFFSET_PX, PredictiveTriggerEngine.DEFAULT_CENTER_OFFSET_PX);
        panelScaleFactor = prefs.getFloat(KEY_PANEL_SCALE, 1.0f);

        if (!IsometricStackTracker.areSavedAxesValid(savedMovingY, savedBaseY)) {
            savedMovingY = IsometricStackTracker.DEFAULT_MOVING_Y_NORM;
            savedBaseY = IsometricStackTracker.DEFAULT_BASE_Y_NORM;
            savedTargetX = IsometricStackTracker.DEFAULT_FIXED_AXIS_X_NORM;
            savedOffsetPx = 0.0f;
        }

        stackTracker.resetAxesToFactoryDefaults();
        stackTracker.setBaseScanYNorm(savedBaseY);
        stackTracker.setMovingScanYNorm(savedMovingY);
        stackTracker.setManualTargetXNorm(savedTargetX);
        stackTracker.setAutoBaseMode(true);

        triggerEngine.setLeadTimeMs(savedLeadMs);
        triggerEngine.setCenterOffsetPx(savedOffsetPx);

        renderBaseCrownY = Math.round(stackTracker.getBaseScanYNorm() * screenHeight);
        renderMovingCrownY = Math.round(stackTracker.getMovingScanYNorm() * screenHeight);
        renderTargetCenterX = stackTracker.getManualTargetXNorm() * screenWidth;
        renderPredictedX = renderTargetCenterX;

        saveConfigurationToPrefs();
    }

    public void applyFactoryAutoAxesReset() {
        stackTracker.resetAxesToFactoryDefaults();
        triggerEngine.setCenterOffsetPx(0.0f);
        triggerEngine.resetHistory();

        renderBaseCrownY = Math.round(stackTracker.getBaseScanYNorm() * screenHeight);
        renderMovingCrownY = Math.round(stackTracker.getMovingScanYNorm() * screenHeight);
        renderTargetCenterX = stackTracker.getManualTargetXNorm() * screenWidth;
        renderPredictedX = renderTargetCenterX;
        renderStatusText = "RE-ESCANEO CIMA ACTIVO";

        saveConfigurationToPrefs();
        updateControlButtonsAppearance();
        if (laserCalibrationView != null) {
            laserCalibrationView.invalidate();
        }
        refreshOverlayTelemetryOnMainThread();
    }

    public void saveConfigurationToPrefs() {
        stackTracker.enforceAntiInversionRule();
        prefs.edit()
                .putFloat(KEY_MOVING_SCAN_Y, stackTracker.getMovingScanYNorm())
                .putFloat(KEY_BASE_SCAN_Y, stackTracker.getBaseScanYNorm())
                .putFloat(KEY_TARGET_X, stackTracker.getManualTargetXNorm())
                .putFloat(KEY_LEAD_TIME_MS, triggerEngine.getLeadTimeMs())
                .putFloat(KEY_CENTER_OFFSET_PX, triggerEngine.getCenterOffsetPx())
                .putBoolean(KEY_AUTO_BASE_MODE, stackTracker.isAutoBaseMode())
                .putFloat(KEY_PANEL_SCALE, panelScaleFactor)
                .apply();
    }

    private void promoteToForeground(boolean withMediaProjectionType) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "QA Auto-Stacker 60FPS Service",
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Rastreo dinámico de cima y alineación de extremos [minX, maxX]");
            nm.createNotificationChannel(channel);
        }

        Intent openAppIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingOpen = PendingIntent.getActivity(
                this,
                0,
                openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        Notification notification = builder
                .setContentTitle("QA Auto-Stacker 60 FPS Activo")
                .setContentText("Rastreo Dinámico de Cima + Envolvente [minX, maxX]")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(pendingOpen)
                .setOngoing(true)
                .build();

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && withMediaProjectionType) {
                startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                startForeground(NOTIFICATION_ID, notification);
            }
        } catch (Exception e) {
            try {
                startForeground(NOTIFICATION_ID, notification);
            } catch (Exception ignored) {
            }
        }
    }

    private void startVisionThread() {
        if (visionThread != null) {
            return;
        }
        visionThread = new HandlerThread(
                "QAStackerByteBuffer60FPS",
                Process.THREAD_PRIORITY_URGENT_DISPLAY);
        visionThread.start();
        visionHandler = new Handler(visionThread.getLooper());
    }

    private void stopVisionThread() {
        if (visionThread != null) {
            visionThread.quitSafely();
            visionThread = null;
            visionHandler = null;
        }
    }

    private void startMediaProjectionCapture(int resultCode, Intent resultData) {
        stopMediaProjectionCapture();
        if (projectionManager == null) {
            return;
        }
        try {
            updateScreenMetrics();
            mediaProjection = projectionManager.getMediaProjection(resultCode, resultData);
            if (mediaProjection == null) {
                return;
            }

            mediaProjection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    mainHandler.post(() -> stopMediaProjectionCapture());
                }
            }, mainHandler);

            imageReader = ImageReader.newInstance(
                    screenWidth,
                    screenHeight,
                    PixelFormat.RGBA_8888,
                    2);

            imageReader.setOnImageAvailableListener(reader -> {
                Image image = null;
                try {
                    image = reader.acquireLatestImage();
                    if (image != null) {
                        processCapturedFrame(image);
                    }
                } catch (Exception ignored) {
                } finally {
                    if (image != null) {
                        image.close();
                    }
                }
            }, visionHandler);

            virtualDisplay = mediaProjection.createVirtualDisplay(
                    "QAStacker60FPSDisplay",
                    screenWidth,
                    screenHeight,
                    screenDensityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.getSurface(),
                    null,
                    visionHandler);

            renderStatusText = "CAPTURA 60FPS ACTIVA";
            refreshOverlayTelemetryOnMainThread();
        } catch (Exception e) {
            renderStatusText = "MODO SIMULADOR / CALIBRACIÓN";
            refreshOverlayTelemetryOnMainThread();
        }
    }

    private void stopMediaProjectionCapture() {
        if (virtualDisplay != null) {
            try {
                virtualDisplay.release();
            } catch (Exception ignored) {
            }
            virtualDisplay = null;
        }
        if (imageReader != null) {
            try {
                imageReader.setOnImageAvailableListener(null, null);
                imageReader.close();
            } catch (Exception ignored) {
            }
            imageReader = null;
        }
        if (mediaProjection != null) {
            try {
                mediaProjection.stop();
            } catch (Exception ignored) {
            }
            mediaProjection = null;
        }
    }

    private void processCapturedFrame(Image image) {
        IsometricStackTracker.ScanResult scan = stackTracker.processImage(image);
        handleScanAndPrediction(scan);
    }

    public void onExternalByteBufferFrameProcessed(IsometricStackTracker.ScanResult scan) {
        handleScanAndPrediction(scan);
    }

    private void handleScanAndPrediction(IsometricStackTracker.ScanResult scan) {
        if (scan == null || !scan.validFrame) {
            return;
        }

        PredictiveTriggerEngine.PredictionDecision decision = triggerEngine.evaluateFrame(
                scan.movingDetected,
                scan.movingCenterX,
                scan.effectiveTargetCenterX,
                scan.timestampNs,
                autoStackEnabled);

        if (decision.shouldFire && autoStackEnabled) {
            if (decision.subFrameWaitNanos > 0L) {
                PredictiveTriggerEngine.executeSubFrameSleepIfNeeded(decision.subFrameWaitNanos);
            }
            TapAccessibilityService.dispatchGlobalOrLocalSafeTap(scan.frameWidth, scan.frameHeight);
            // Esperar 260ms para que la losa se pose y re-calcular automáticamente la nueva cima baseCrownY
            stackTracker.notifyShotFired(260L);
            lastShotFlashUptimeMs = SystemClock.uptimeMillis();
        } else if (autoStackEnabled && autoTapToPlayEnabled && scan.tapToPlayButtonDetected) {
            long nowMs = SystemClock.uptimeMillis();
            if (nowMs - lastTapToPlayUptimeMs > 1500L) {
                lastTapToPlayUptimeMs = nowMs;
                TapAccessibilityService service = TapAccessibilityService.getInstance();
                if (service != null) {
                    service.performUltraFastTap(scan.tapToPlayCenterX, scan.tapToPlayCenterY);
                }
                stackTracker.notifyShotFired(320L);
            }
        }

        renderBaseCrownY = scan.baseCrownY;
        renderBaseDetected = scan.baseDetected;
        renderBaseMinX = scan.baseMinX;
        renderBaseMaxX = scan.baseMaxX;
        renderTargetCenterX = scan.effectiveTargetCenterX;

        renderMovingCrownY = scan.movingCrownY;
        renderMovingDetected = scan.movingDetected;
        renderMovingMinX = scan.movingMinX;
        renderMovingMaxX = scan.movingMaxX;
        renderMovingCenterX = scan.movingCenterX;
        renderPredictedX = decision.predictedX;
        renderVelocityPxPerMs = decision.velocityPxPerMs;
        renderAnalysisTimeMs = scan.processingTimeMs;

        switch (decision.state) {
            case IMMEDIATE_FIRED:
                renderStatusText = "PERFECT SNAP ⚡";
                break;
            case WAIT_AND_SNAP_FIRED:
                renderStatusText = "WAIT & SNAP 🎯";
                break;
            case COOLDOWN:
                renderStatusText = "RE-CAPTURA BASE (260ms)";
                break;
            case TRACKING:
                renderStatusText = String.format(Locale.US, "VX: %+.2f px/ms", decision.velocityPxPerMs);
                break;
            case SEARCHING:
            default:
                renderStatusText = "BUSCANDO LOSA";
                break;
        }

        if (laserCalibrationView != null) {
            laserCalibrationView.postInvalidateOnAnimation();
        }
        refreshOverlayTelemetryOnMainThread();
    }

    private void ensureOverlayViewsCreated() {
        if (windowManager == null) {
            return;
        }
        int overlayType = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        if (laserCalibrationView == null) {
            laserCalibrationView = new LaserCalibrationView(this);
            laserLayoutParams = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    overlayType,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            laserLayoutParams.gravity = Gravity.TOP | Gravity.START;
            try {
                windowManager.addView(laserCalibrationView, laserLayoutParams);
            } catch (Exception ignored) {
            }
        }

        if (floatingRootContainer == null) {
            buildFloatingControlPanel(overlayType);
        }
    }

    private void removeOverlayViews() {
        if (windowManager == null) {
            return;
        }
        if (laserCalibrationView != null) {
            try {
                windowManager.removeView(laserCalibrationView);
            } catch (Exception ignored) {
            }
            laserCalibrationView = null;
        }
        if (floatingRootContainer != null) {
            try {
                windowManager.removeView(floatingRootContainer);
            } catch (Exception ignored) {
            }
            floatingRootContainer = null;
        }
    }

    private void setCalibrationTouchMode(boolean interactive) {
        this.calibrationMode = interactive;
        if (laserCalibrationView != null && laserLayoutParams != null && windowManager != null) {
            if (interactive) {
                laserLayoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
            } else {
                stackTracker.enforceAntiInversionRule();
                laserLayoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
                saveConfigurationToPrefs();
            }
            try {
                windowManager.updateViewLayout(laserCalibrationView, laserLayoutParams);
            } catch (Exception ignored) {
            }
            laserCalibrationView.invalidate();
        }
        updateControlButtonsAppearance();
    }

    private void buildFloatingControlPanel(int overlayType) {
        floatingRootContainer = new LinearLayout(this);
        floatingRootContainer.setOrientation(LinearLayout.VERTICAL);

        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setColor(Color.argb(232, 15, 23, 42));
        panelBg.setCornerRadius(dpToPx(14));
        panelBg.setStroke(dpToPx(1), Color.argb(180, 56, 189, 248));
        floatingRootContainer.setBackground(panelBg);
        int pad = dpToPx(8);
        floatingRootContainer.setPadding(pad, pad, pad, pad);

        miniPillButton = new TextView(this);
        miniPillButton.setText("⚡ QA 60FPS [ABRIR]");
        miniPillButton.setTextColor(Color.parseColor("#38BDF8"));
        miniPillButton.setTypeface(Typeface.DEFAULT_BOLD);
        miniPillButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        miniPillButton.setPadding(dpToPx(10), dpToPx(6), dpToPx(10), dpToPx(6));
        miniPillButton.setVisibility(View.GONE);
        miniPillButton.setOnClickListener(v -> setMinimizedToPill(false));
        floatingRootContainer.addView(miniPillButton);

        expandedPanelContent = new LinearLayout(this);
        expandedPanelContent.setOrientation(LinearLayout.VERTICAL);
        floatingRootContainer.addView(expandedPanelContent);

        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView titleView = new TextView(this);
        titleView.setText("⋮⋮ QA STACKER 60FPS");
        titleView.setTextColor(Color.WHITE);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
        headerRow.addView(titleView, titleLp);

        Button btnSmaller = createMiniHeaderButton("[-]", v -> adjustPanelScale(-0.10f));
        Button btnLarger = createMiniHeaderButton("[+]", v -> adjustPanelScale(+0.10f));
        Button btnMinimize = createMiniHeaderButton("[_]", v -> setMinimizedToPill(true));
        Button btnClose = createMiniHeaderButton("[X]", v -> stopSelf());

        headerRow.addView(btnSmaller);
        headerRow.addView(btnLarger);
        headerRow.addView(btnMinimize);
        headerRow.addView(btnClose);
        expandedPanelContent.addView(headerRow);

        txtTelemetryLine = new TextView(this);
        txtTelemetryLine.setTextColor(Color.parseColor("#A7F3D0"));
        txtTelemetryLine.setTypeface(Typeface.MONOSPACE);
        txtTelemetryLine.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        txtTelemetryLine.setPadding(0, dpToPx(3), 0, dpToPx(4));
        expandedPanelContent.addView(txtTelemetryLine);

        LinearLayout primaryRow = new LinearLayout(this);
        primaryRow.setOrientation(LinearLayout.HORIZONTAL);

        btnToggleAutoStack = createActionPillButton("Auto-Stack: OFF", v -> {
            autoStackEnabled = !autoStackEnabled;
            triggerEngine.resetHistory();
            if (autoStackEnabled) {
                stackTracker.notifyShotFired(180L);
            }
            updateControlButtonsAppearance();
            if (laserCalibrationView != null) {
                laserCalibrationView.invalidate();
            }
        });
        btnToggleCalibrate = createActionPillButton("Calibrar Ejes", v -> {
            setCalibrationTouchMode(!calibrationMode);
        });

        LinearLayout.LayoutParams halfLp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
        halfLp.setMargins(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2));
        primaryRow.addView(btnToggleAutoStack, halfLp);
        primaryRow.addView(btnToggleCalibrate, halfLp);
        expandedPanelContent.addView(primaryRow);

        LinearLayout leadRow = new LinearLayout(this);
        leadRow.setOrientation(LinearLayout.HORIZONTAL);
        leadRow.setGravity(Gravity.CENTER_VERTICAL);

        Button btnLeadMinus = createStepButton("-2ms", v -> {
            triggerEngine.adjustLeadTimeMs(-2.0f);
            saveConfigurationToPrefs();
            updateControlButtonsAppearance();
        });
        txtLeadTimeValue = new TextView(this);
        txtLeadTimeValue.setGravity(Gravity.CENTER);
        txtLeadTimeValue.setTextColor(Color.WHITE);
        txtLeadTimeValue.setTypeface(Typeface.DEFAULT_BOLD);
        txtLeadTimeValue.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        Button btnLeadPlus = createStepButton("+2ms", v -> {
            triggerEngine.adjustLeadTimeMs(+2.0f);
            saveConfigurationToPrefs();
            updateControlButtonsAppearance();
        });

        leadRow.addView(btnLeadMinus);
        leadRow.addView(txtLeadTimeValue, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));
        leadRow.addView(btnLeadPlus);
        expandedPanelContent.addView(leadRow);

        LinearLayout offsetRow = new LinearLayout(this);
        offsetRow.setOrientation(LinearLayout.HORIZONTAL);
        offsetRow.setGravity(Gravity.CENTER_VERTICAL);

        Button btnOffsetLeft = createStepButton("◀ -2px", v -> {
            triggerEngine.adjustCenterOffsetPx(-2.0f);
            saveConfigurationToPrefs();
            updateControlButtonsAppearance();
            if (laserCalibrationView != null) {
                laserCalibrationView.invalidate();
            }
        });
        txtCenterOffsetValue = new TextView(this);
        txtCenterOffsetValue.setGravity(Gravity.CENTER);
        txtCenterOffsetValue.setTextColor(Color.WHITE);
        txtCenterOffsetValue.setTypeface(Typeface.DEFAULT_BOLD);
        txtCenterOffsetValue.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        Button btnOffsetRight = createStepButton("▶ +2px", v -> {
            triggerEngine.adjustCenterOffsetPx(+2.0f);
            saveConfigurationToPrefs();
            updateControlButtonsAppearance();
            if (laserCalibrationView != null) {
                laserCalibrationView.invalidate();
            }
        });

        offsetRow.addView(btnOffsetLeft);
        offsetRow.addView(txtCenterOffsetValue, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));
        offsetRow.addView(btnOffsetRight);
        expandedPanelContent.addView(offsetRow);

        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);

        btnToggleMode = createActionPillButton("Modo: Auto-Base", v -> {
            boolean nextMode = !stackTracker.isAutoBaseMode();
            stackTracker.setAutoBaseMode(nextMode);
            if (nextMode) {
                stackTracker.unlockReference();
            }
            saveConfigurationToPrefs();
            updateControlButtonsAppearance();
            if (laserCalibrationView != null) {
                laserCalibrationView.invalidate();
            }
        });

        btnAutoAxes = createActionPillButton("Auto-Ejes", v -> {
            applyFactoryAutoAxesReset();
        });

        LinearLayout.LayoutParams modeLp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.35f);
        modeLp.setMargins(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2));
        LinearLayout.LayoutParams autoAxesLp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.85f);
        autoAxesLp.setMargins(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2));

        modeRow.addView(btnToggleMode, modeLp);
        modeRow.addView(btnAutoAxes, autoAxesLp);
        expandedPanelContent.addView(modeRow);

        panelLayoutParams = new WindowManager.LayoutParams(
                dpToPx(Math.round(256 * panelScaleFactor)),
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        panelLayoutParams.gravity = Gravity.TOP | Gravity.START;
        panelLayoutParams.x = dpToPx(12);
        panelLayoutParams.y = dpToPx(56);

        attachDragListenerToView(headerRow);
        attachDragListenerToView(miniPillButton);

        updateControlButtonsAppearance();
        refreshOverlayTelemetryOnMainThread();

        try {
            windowManager.addView(floatingRootContainer, panelLayoutParams);
        } catch (Exception ignored) {
        }
    }

    private void attachDragListenerToView(View dragHandle) {
        dragHandle.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (panelLayoutParams == null || windowManager == null) {
                    return false;
                }
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = panelLayoutParams.x;
                        initialY = panelLayoutParams.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = Math.round(event.getRawX() - initialTouchX);
                        int dy = Math.round(event.getRawY() - initialTouchY);
                        if (Math.abs(dx) > 6 || Math.abs(dy) > 6) {
                            moved = true;
                        }
                        panelLayoutParams.x = Math.max(0, Math.min(screenWidth - dpToPx(80), initialX + dx));
                        panelLayoutParams.y = Math.max(0, Math.min(screenHeight - dpToPx(60), initialY + dy));
                        try {
                            windowManager.updateViewLayout(floatingRootContainer, panelLayoutParams);
                        } catch (Exception ignored) {
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            v.performClick();
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void adjustPanelScale(float delta) {
        panelScaleFactor = Math.max(0.80f, Math.min(1.30f, panelScaleFactor + delta));
        saveConfigurationToPrefs();
        if (floatingRootContainer != null && panelLayoutParams != null && !isMinimizedToPill) {
            panelLayoutParams.width = dpToPx(Math.round(256 * panelScaleFactor));
            floatingRootContainer.setScaleX(panelScaleFactor);
            floatingRootContainer.setScaleY(panelScaleFactor);
            try {
                windowManager.updateViewLayout(floatingRootContainer, panelLayoutParams);
            } catch (Exception ignored) {
            }
        }
    }

    private void setMinimizedToPill(boolean minimize) {
        this.isMinimizedToPill = minimize;
        if (expandedPanelContent == null || miniPillButton == null || panelLayoutParams == null) {
            return;
        }
        if (minimize) {
            expandedPanelContent.setVisibility(View.GONE);
            miniPillButton.setVisibility(View.VISIBLE);
            String stateTag = autoStackEnabled ? "ON" : "OFF";
            miniPillButton.setText("⚡ QA 60FPS [" + stateTag + "] ▾");
            panelLayoutParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
        } else {
            miniPillButton.setVisibility(View.GONE);
            expandedPanelContent.setVisibility(View.VISIBLE);
            panelLayoutParams.width = dpToPx(Math.round(256 * panelScaleFactor));
        }
        try {
            windowManager.updateViewLayout(floatingRootContainer, panelLayoutParams);
        } catch (Exception ignored) {
        }
    }

    private void updateControlButtonsAppearance() {
        if (btnToggleAutoStack != null) {
            btnToggleAutoStack.setText(autoStackEnabled ? "Auto-Stack: ON" : "Auto-Stack: OFF");
            styleButtonBackground(
                    btnToggleAutoStack,
                    autoStackEnabled ? Color.parseColor("#059669") : Color.parseColor("#334155"));
        }
        if (btnToggleCalibrate != null) {
            btnToggleCalibrate.setText(calibrationMode ? "Guardar Ejes ✓" : "Calibrar Ejes");
            styleButtonBackground(
                    btnToggleCalibrate,
                    calibrationMode ? Color.parseColor("#D97706") : Color.parseColor("#1E293B"));
        }
        if (txtLeadTimeValue != null) {
            txtLeadTimeValue.setText(String.format(
                    Locale.US,
                    "Anticipación: %.0fms",
                    triggerEngine.getLeadTimeMs()));
        }
        if (txtCenterOffsetValue != null) {
            float off = triggerEngine.getCenterOffsetPx();
            String sign = (off >= 0.0f) ? "+" : "";
            txtCenterOffsetValue.setText(String.format(
                    Locale.US,
                    "Eje X: %s%.0fpx",
                    sign,
                    off));
        }
        if (btnToggleMode != null) {
            boolean autoBase = stackTracker.isAutoBaseMode();
            btnToggleMode.setText(autoBase ? "Modo: Auto-Base" : "Modo: Eje Fijo");
            styleButtonBackground(
                    btnToggleMode,
                    autoBase ? Color.parseColor("#0284C7") : Color.parseColor("#7C3AED"));
        }
        if (btnAutoAxes != null) {
            btnAutoAxes.setText("Auto-Ejes");
            styleButtonBackground(btnAutoAxes, Color.parseColor("#0D9488"));
        }
        if (miniPillButton != null && isMinimizedToPill) {
            miniPillButton.setText("⚡ QA 60FPS [" + (autoStackEnabled ? "ON" : "OFF") + "] ▾");
        }
    }

    private void refreshOverlayTelemetryOnMainThread() {
        mainHandler.post(() -> {
            if (txtTelemetryLine != null) {
                txtTelemetryLine.setText(String.format(
                        Locale.US,
                        "ROI: %.2fms | Shots: %d | %s",
                        renderAnalysisTimeMs,
                        triggerEngine.getTotalShotsFired(),
                        renderStatusText));
            }
        });
    }

    private Button createMiniHeaderButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.parseColor("#E2E8F0"));
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        b.setPadding(dpToPx(6), dpToPx(2), dpToPx(6), dpToPx(2));
        b.setMinimumWidth(0);
        b.setMinWidth(0);
        b.setMinimumHeight(0);
        b.setMinHeight(0);
        styleButtonBackground(b, Color.parseColor("#1E293B"));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dpToPx(2), 0, 0, 0);
        b.setLayoutParams(lp);
        b.setOnClickListener(listener);
        return b;
    }

    private Button createActionPillButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        b.setPadding(dpToPx(6), dpToPx(5), dpToPx(6), dpToPx(5));
        b.setMinimumHeight(0);
        b.setMinHeight(0);
        styleButtonBackground(b, Color.parseColor("#334155"));
        b.setOnClickListener(listener);
        return b;
    }

    private Button createStepButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.parseColor("#38BDF8"));
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        b.setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));
        b.setMinimumWidth(0);
        b.setMinWidth(0);
        b.setMinimumHeight(0);
        b.setMinHeight(0);
        styleButtonBackground(b, Color.parseColor("#0F172A"));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2));
        b.setLayoutParams(lp);
        b.setOnClickListener(listener);
        return b;
    }

    private void styleButtonBackground(View button, int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dpToPx(8));
        bg.setStroke(dpToPx(1), Color.argb(90, 255, 255, 255));
        button.setBackground(bg);
    }

    private int dpToPx(int dp) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp,
                getResources().getDisplayMetrics()));
    }

    /**
     * Lienzo Transparente de Visualización Láser de Envolventes [minX, maxX]:
     * 1. Dos líneas verticales láser verdes en baseMinX y baseMaxX + eje central en baseCenterX
     *    que sube automáticamente con baseCrownY en cada piso.
     * 2. Rectángulo cian dinámico alrededor del bloque diagonal en movimiento [movingMinX, movingMaxX]
     *    y punto amarillo en predictedCenterX.
     */
    private final class LaserCalibrationView extends View {

        private final Paint baseLinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint baseBoundsVerticalPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint movingBoxPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint targetAxisPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint predictedDotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint labelBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint labelTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint safeTapZonePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF movingRect = new RectF();

        private int activeDragTarget = 0;

        LaserCalibrationView(Context context) {
            super(context);

            baseLinePaint.setColor(Color.parseColor("#00E676"));
            baseLinePaint.setStrokeWidth(dpToPx(2));
            baseLinePaint.setStyle(Paint.Style.STROKE);

            baseBoundsVerticalPaint.setColor(Color.argb(200, 0, 230, 118));
            baseBoundsVerticalPaint.setStrokeWidth(dpToPx(2));
            baseBoundsVerticalPaint.setStyle(Paint.Style.STROKE);

            movingBoxPaint.setColor(Color.parseColor("#00E5FF"));
            movingBoxPaint.setStrokeWidth(dpToPx(2));
            movingBoxPaint.setStyle(Paint.Style.STROKE);

            targetAxisPaint.setColor(Color.parseColor("#00E676"));
            targetAxisPaint.setStrokeWidth(dpToPx(2));
            targetAxisPaint.setStyle(Paint.Style.STROKE);
            targetAxisPaint.setPathEffect(new DashPathEffect(new float[]{14f, 8f}, 0f));

            predictedDotPaint.setColor(Color.parseColor("#FFEA00"));
            predictedDotPaint.setStyle(Paint.Style.FILL);

            labelBgPaint.setColor(Color.argb(190, 15, 23, 42));
            labelBgPaint.setStyle(Paint.Style.FILL);

            labelTextPaint.setColor(Color.WHITE);
            labelTextPaint.setTextSize(TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_SP, 10, getResources().getDisplayMetrics()));
            labelTextPaint.setTypeface(Typeface.MONOSPACE);

            safeTapZonePaint.setColor(Color.parseColor("#38BDF8"));
            safeTapZonePaint.setStyle(Paint.Style.STROKE);
            safeTapZonePaint.setStrokeWidth(dpToPx(2));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) {
                return;
            }

            float baseY = (renderBaseCrownY > 0)
                    ? renderBaseCrownY
                    : (stackTracker.getBaseScanYNorm() * h);
            float movingY = (renderMovingCrownY > 0)
                    ? renderMovingCrownY
                    : (stackTracker.getMovingScanYNorm() * h);

            float targetX = (renderTargetCenterX > 0.0f)
                    ? renderTargetCenterX
                    : (stackTracker.getManualTargetXNorm() * w);
            float effectiveTargetWithOffset = targetX - triggerEngine.getCenterOffsetPx();

            // 1. Dos líneas verticales láser verdes en baseMinX y baseMaxX + línea central en baseCenterX
            float guideTopY = Math.max(h * 0.32f, baseY - dpToPx(110));
            float guideBottomY = Math.min(h * 0.74f, baseY + dpToPx(40));

            canvas.drawLine(
                    effectiveTargetWithOffset,
                    guideTopY,
                    effectiveTargetWithOffset,
                    guideBottomY,
                    targetAxisPaint);

            if (renderBaseDetected && renderBaseMaxX > renderBaseMinX) {
                // Líneas verticales láser verdes en baseMinX y baseMaxX
                canvas.drawLine(renderBaseMinX, guideTopY, renderBaseMinX, guideBottomY, baseBoundsVerticalPaint);
                canvas.drawLine(renderBaseMaxX, guideTopY, renderBaseMaxX, guideBottomY, baseBoundsVerticalPaint);
                // Línea horizontal de coronación en baseCrownY
                canvas.drawLine(renderBaseMinX, baseY, renderBaseMaxX, baseY, baseLinePaint);
            } else {
                canvas.drawLine(0.16f * w, baseY, 0.84f * w, baseY, baseLinePaint);
            }
            canvas.drawCircle(targetX, baseY, dpToPx(5), baseLinePaint);

            // 2. Rectángulo/marcador cian dinámico alrededor del bloque móvil [movingMinX, movingMaxX]
            if (renderMovingDetected && renderMovingMaxX > renderMovingMinX) {
                float boxHalfH = dpToPx(18);
                movingRect.set(renderMovingMinX, movingY - boxHalfH, renderMovingMaxX, movingY + boxHalfH);
                canvas.drawRoundRect(movingRect, dpToPx(4), dpToPx(4), movingBoxPaint);

                // Centro móvil actual (círculo cian) y predicción cinemática (punto amarillo)
                canvas.drawCircle(renderMovingCenterX, movingY, dpToPx(6), movingBoxPaint);
                float clampedPredX = Math.max(0.08f * w, Math.min(0.92f * w, renderPredictedX));
                canvas.drawLine(renderMovingCenterX, movingY, clampedPredX, movingY, predictedDotPaint);
                canvas.drawCircle(clampedPredX, movingY, dpToPx(6), predictedDotPaint);
            }

            // 3. Indicador discreto del punto de tap de 45ms en (0.85f * W, 0.35f * H)
            float tapX = TapAccessibilityService.DEFAULT_SAFE_TAP_X_NORM * w;
            float tapY = TapAccessibilityService.DEFAULT_SAFE_TAP_Y_NORM * h;
            long sinceShotMs = SystemClock.uptimeMillis() - lastShotFlashUptimeMs;
            if (sinceShotMs >= 0L && sinceShotMs < 180L) {
                safeTapZonePaint.setColor(Color.parseColor("#00E676"));
                canvas.drawCircle(tapX, tapY, dpToPx(12), safeTapZonePaint);
            } else if (calibrationMode) {
                safeTapZonePaint.setColor(Color.argb(110, 56, 189, 248));
                canvas.drawCircle(tapX, tapY, dpToPx(6), safeTapZonePaint);
            }

            // 4. Etiquetas de altura dinámica
            String baseLabel = String.format(Locale.US, "CROWN Y: %.3f", baseY / h);
            canvas.drawText(baseLabel, 0.72f * w, baseY + dpToPx(15), labelTextPaint);

            if (calibrationMode) {
                float bannerTop = h * 0.86f;
                canvas.drawRect(
                        w * 0.08f,
                        bannerTop,
                        w * 0.92f,
                        bannerTop + dpToPx(44),
                        labelBgPaint);
                canvas.drawText(
                        "MODO CALIBRAR: Arrastra Eje Central X o pulsa 'Auto-Ejes' para Auto-Cima",
                        w * 0.10f,
                        bannerTop + dpToPx(26),
                        labelTextPaint);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (!calibrationMode) {
                return false;
            }
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) {
                return false;
            }
            float touchX = event.getX();
            float touchY = event.getY();

            float movingY = stackTracker.getMovingScanYNorm() * h;
            float baseY = stackTracker.getBaseScanYNorm() * h;
            float targetX = stackTracker.getManualTargetXNorm() * w;

            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (Math.abs(touchX - targetX) <= dpToPx(36)) {
                        activeDragTarget = 3;
                    } else if (Math.abs(touchY - movingY) <= Math.abs(touchY - baseY)) {
                        activeDragTarget = 1;
                    } else {
                        activeDragTarget = 2;
                    }
                    applyCalibrationTouch(touchX, touchY, w, h);
                    return true;

                case MotionEvent.ACTION_MOVE:
                    applyCalibrationTouch(touchX, touchY, w, h);
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    activeDragTarget = 0;
                    stackTracker.enforceAntiInversionRule();
                    saveConfigurationToPrefs();
                    invalidate();
                    return true;

                default:
                    return false;
            }
        }

        private void applyCalibrationTouch(float touchX, float touchY, int w, int h) {
            float normY = touchY / (float) h;
            if (activeDragTarget == 1) {
                stackTracker.setMovingScanYNorm(normY);
                renderMovingCrownY = Math.round(stackTracker.getMovingScanYNorm() * h);
            } else if (activeDragTarget == 2) {
                stackTracker.setBaseScanYNorm(normY);
                renderBaseCrownY = Math.round(stackTracker.getBaseScanYNorm() * h);
            } else if (activeDragTarget == 3) {
                stackTracker.setManualTargetXNorm(touchX / (float) w);
                stackTracker.setAutoBaseMode(false);
                renderTargetCenterX = touchX;
                updateControlButtonsAppearance();
            }
            invalidate();
        }
    }
}
