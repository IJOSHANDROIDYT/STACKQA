package com.example;

import android.os.SystemClock;
import java.util.concurrent.locks.LockSupport;

/**
 * Predictor Cinemático de Disparo Isométrico (Invariable a la Diagonal ↘ / ↙).
 * - Calcula la velocidad horizontal vx por regresión lineal de los últimos 3 fotogramas válidos.
 * - Predice predictedCenterX = movingCenterX + (vx * LEAD_TIME_MS) + CENTER_OFFSET_PX (por defecto LEAD_TIME_MS = 22ms).
 * - Detector de Cruce Direccional Exacto (Zero-Crossing Detector):
 *   * Izquierda (vx > +0.12f px/ms): dispara en predictedCenterX >= baseCenterX - 1.5f (o Wait & Snap 1..12ms).
 *   * Derecha (vx < -0.12f px/ms): dispara en predictedCenterX <= baseCenterX + 1.5f (o Wait & Snap 1..12ms).
 * - Cooldown de estabilización de 260ms tras el disparo para re-capturar la nueva cima de la torre.
 */
public final class PredictiveTriggerEngine {

    public static final float DEFAULT_LEAD_TIME_MS = 22.0f;
    public static final float DEFAULT_CENTER_OFFSET_PX = 0.0f;
    public static final float DEFAULT_TOLERANCE_PX = 1.5f;
    public static final long DEFAULT_COOLDOWN_MS = 260L;

    public static final float MIN_VALID_VELOCITY_PX_PER_MS = 0.12f;
    public static final float MAX_VALID_VELOCITY_PX_PER_MS = 3.80f;

    private static final int HISTORY_CAPACITY = 3;
    private static final float MAX_FRAME_GAP_MS = 110.0f;
    private static final float SUB_FRAME_MAX_WAIT_MS = 12.0f;

    private final long[] historyTimestampNs = new long[HISTORY_CAPACITY];
    private final float[] historyCenterX = new float[HISTORY_CAPACITY];
    private int historyCount = 0;

    private volatile float leadTimeMs = DEFAULT_LEAD_TIME_MS;
    private volatile float centerOffsetPx = DEFAULT_CENTER_OFFSET_PX;
    private volatile float tolerancePx = DEFAULT_TOLERANCE_PX;
    private volatile long cooldownMs = DEFAULT_COOLDOWN_MS;
    private volatile boolean waitAndSnapEnabled = true;

    private float lastPredictedX = -1.0f;
    private float currentVelocityPxPerMs = 0.0f;
    private long lastTriggerUptimeMs = -10_000L;
    private int totalShotsFired = 0;

    private final PredictionDecision reusableDecision = new PredictionDecision();

    public enum TriggerState {
        COOLDOWN,
        SEARCHING,
        TRACKING,
        WAIT_AND_SNAP_FIRED,
        IMMEDIATE_FIRED
    }

    public static final class PredictionDecision {
        public TriggerState state = TriggerState.SEARCHING;
        public boolean shouldFire = false;
        public long subFrameWaitNanos = 0L;
        public float velocityPxPerMs = 0.0f;
        public float predictedX = 0.0f;
        public float targetCenterX = 0.0f;
        public float timeToImpactMs = -1.0f;
    }

    public PredictiveTriggerEngine() {
    }

    public void setLeadTimeMs(float leadTimeMs) {
        this.leadTimeMs = clamp(leadTimeMs, 0.0f, 80.0f);
    }

    public float getLeadTimeMs() {
        return leadTimeMs;
    }

    public void adjustLeadTimeMs(float deltaMs) {
        setLeadTimeMs(this.leadTimeMs + deltaMs);
    }

    public void setCenterOffsetPx(float offsetPx) {
        this.centerOffsetPx = clamp(offsetPx, -40.0f, 40.0f);
    }

    public float getCenterOffsetPx() {
        return centerOffsetPx;
    }

    public void adjustCenterOffsetPx(float deltaPx) {
        setCenterOffsetPx(this.centerOffsetPx + deltaPx);
    }

    public void setTolerancePx(float tolerancePx) {
        this.tolerancePx = clamp(tolerancePx, 1.0f, 24.0f);
    }

    public float getTolerancePx() {
        return tolerancePx;
    }

    public void setCooldownMs(long cooldownMs) {
        this.cooldownMs = Math.max(120L, Math.min(1200L, cooldownMs));
    }

    public long getCooldownMs() {
        return cooldownMs;
    }

    public void setWaitAndSnapEnabled(boolean enabled) {
        this.waitAndSnapEnabled = enabled;
    }

    public boolean isWaitAndSnapEnabled() {
        return waitAndSnapEnabled;
    }

    public int getTotalShotsFired() {
        return totalShotsFired;
    }

    public void resetHistory() {
        historyCount = 0;
        lastPredictedX = -1.0f;
        currentVelocityPxPerMs = 0.0f;
    }

    public void resetStats() {
        resetHistory();
        totalShotsFired = 0;
        lastTriggerUptimeMs = -10_000L;
    }

    /**
     * Evalúa el fotograma actual mediante regresión lineal de 3 fotogramas y detector de cruce direccional
     * exacto (Zero-Crossing Detector) sobre baseCenterX.
     */
    public PredictionDecision evaluateFrame(
            boolean movingDetected,
            float movingCenterX,
            float baseCenterX,
            long frameTimestampNs,
            boolean autoStackEnabled) {

        reusableDecision.shouldFire = false;
        reusableDecision.subFrameWaitNanos = 0L;
        reusableDecision.targetCenterX = baseCenterX;
        reusableDecision.timeToImpactMs = -1.0f;

        long nowUptimeMs = SystemClock.uptimeMillis();
        if (nowUptimeMs - lastTriggerUptimeMs < cooldownMs) {
            reusableDecision.state = TriggerState.COOLDOWN;
            reusableDecision.velocityPxPerMs = 0.0f;
            reusableDecision.predictedX = baseCenterX;
            return reusableDecision;
        }

        if (!movingDetected || movingCenterX <= 0.0f) {
            resetHistory();
            reusableDecision.state = TriggerState.SEARCHING;
            reusableDecision.velocityPxPerMs = 0.0f;
            reusableDecision.predictedX = baseCenterX;
            return reusableDecision;
        }

        if (historyCount > 0) {
            long prevTimeNs = historyTimestampNs[historyCount - 1];
            float deltaMs = (frameTimestampNs - prevTimeNs) / 1_000_000.0f;
            if (deltaMs <= 0.1f || deltaMs > MAX_FRAME_GAP_MS) {
                resetHistory();
            } else {
                float jumpPx = Math.abs(movingCenterX - historyCenterX[historyCount - 1]);
                if (jumpPx > 220.0f) {
                    resetHistory();
                }
            }
        }

        if (historyCount < HISTORY_CAPACITY) {
            historyTimestampNs[historyCount] = frameTimestampNs;
            historyCenterX[historyCount] = movingCenterX;
            historyCount++;
        } else {
            historyTimestampNs[0] = historyTimestampNs[1];
            historyCenterX[0] = historyCenterX[1];
            historyTimestampNs[1] = historyTimestampNs[2];
            historyCenterX[1] = historyCenterX[2];
            historyTimestampNs[2] = frameTimestampNs;
            historyCenterX[2] = movingCenterX;
        }

        if (historyCount < 2) {
            reusableDecision.state = TriggerState.TRACKING;
            reusableDecision.velocityPxPerMs = 0.0f;
            reusableDecision.predictedX = movingCenterX + centerOffsetPx;
            lastPredictedX = reusableDecision.predictedX;
            return reusableDecision;
        }

        // Velocidad horizontal vx mediante regresión lineal sobre los últimos 3 fotogramas válidos
        float vx = computeLinearRegressionVelocity();
        this.currentVelocityPxPerMs = vx;

        float absVx = Math.abs(vx);
        float predictedCenterX = movingCenterX + (vx * leadTimeMs) + centerOffsetPx;

        reusableDecision.velocityPxPerMs = vx;
        reusableDecision.predictedX = predictedCenterX;
        reusableDecision.state = TriggerState.TRACKING;

        if (!autoStackEnabled
                || absVx < MIN_VALID_VELOCITY_PX_PER_MS
                || absVx > MAX_VALID_VELOCITY_PX_PER_MS) {
            lastPredictedX = predictedCenterX;
            return reusableDecision;
        }

        float adjustedBaseCenterX = baseCenterX - centerOffsetPx;
        float distanceToBaseCenterPx = adjustedBaseCenterX - movingCenterX;

        // 1. Losa aproximándose en diagonal desde la IZQUIERDA (vx > +0.12f px/ms)
        if (vx > MIN_VALID_VELOCITY_PX_PER_MS) {
            // Verificar que no haya pasado ya de largo el centro base
            if (movingCenterX <= adjustedBaseCenterX + 18.0f) {
                // Cruce direccional inmediato: predictedCenterX >= baseCenterX - 1.5f
                if (predictedCenterX >= (baseCenterX - tolerancePx)
                        && (lastPredictedX < 0.0f || lastPredictedX <= baseCenterX + 24.0f)) {
                    markTriggered(nowUptimeMs);
                    reusableDecision.shouldFire = true;
                    reusableDecision.subFrameWaitNanos = 0L;
                    reusableDecision.timeToImpactMs = 0.0f;
                    reusableDecision.state = TriggerState.IMMEDIATE_FIRED;
                    return reusableDecision;
                }

                // Wait & Snap Sub-Frame (cuando faltan entre 0.4ms y 12ms para predictedCenterX == baseCenterX)
                float timeToImpactMs = (distanceToBaseCenterPx / vx) - leadTimeMs;
                reusableDecision.timeToImpactMs = timeToImpactMs;
                if (waitAndSnapEnabled && timeToImpactMs >= 0.4f && timeToImpactMs <= SUB_FRAME_MAX_WAIT_MS) {
                    long waitNanos = (long) (timeToImpactMs * 1_000_000.0f);
                    markTriggered(nowUptimeMs + Math.round(timeToImpactMs));
                    reusableDecision.shouldFire = true;
                    reusableDecision.subFrameWaitNanos = waitNanos;
                    reusableDecision.state = TriggerState.WAIT_AND_SNAP_FIRED;
                    return reusableDecision;
                }
            }
        }
        // 2. Losa aproximándose en diagonal desde la DERECHA (vx < -0.12f px/ms)
        else if (vx < -MIN_VALID_VELOCITY_PX_PER_MS) {
            if (movingCenterX >= adjustedBaseCenterX - 18.0f) {
                // Cruce direccional inmediato: predictedCenterX <= baseCenterX + 1.5f
                if (predictedCenterX <= (baseCenterX + tolerancePx)
                        && (lastPredictedX < 0.0f || lastPredictedX >= baseCenterX - 24.0f)) {
                    markTriggered(nowUptimeMs);
                    reusableDecision.shouldFire = true;
                    reusableDecision.subFrameWaitNanos = 0L;
                    reusableDecision.timeToImpactMs = 0.0f;
                    reusableDecision.state = TriggerState.IMMEDIATE_FIRED;
                    return reusableDecision;
                }

                // Wait & Snap Sub-Frame (cuando faltan entre 0.4ms y 12ms para predictedCenterX == baseCenterX)
                float timeToImpactMs = (distanceToBaseCenterPx / vx) - leadTimeMs;
                reusableDecision.timeToImpactMs = timeToImpactMs;
                if (waitAndSnapEnabled && timeToImpactMs >= 0.4f && timeToImpactMs <= SUB_FRAME_MAX_WAIT_MS) {
                    long waitNanos = (long) (timeToImpactMs * 1_000_000.0f);
                    markTriggered(nowUptimeMs + Math.round(timeToImpactMs));
                    reusableDecision.shouldFire = true;
                    reusableDecision.subFrameWaitNanos = waitNanos;
                    reusableDecision.state = TriggerState.WAIT_AND_SNAP_FIRED;
                    return reusableDecision;
                }
            }
        }

        lastPredictedX = predictedCenterX;
        return reusableDecision;
    }

    /**
     * Calcula la pendiente vx (px/ms) por mínimos cuadrados sobre los últimos 2 o 3 fotogramas.
     */
    private float computeLinearRegressionVelocity() {
        if (historyCount == 2) {
            float dtMs = (historyTimestampNs[1] - historyTimestampNs[0]) / 1_000_000.0f;
            return (dtMs > 0.1f) ? ((historyCenterX[1] - historyCenterX[0]) / dtMs) : 0.0f;
        }
        long t0 = historyTimestampNs[0];
        float x0 = 0.0f;
        float x1 = (historyTimestampNs[1] - t0) / 1_000_000.0f;
        float x2 = (historyTimestampNs[2] - t0) / 1_000_000.0f;

        float y0 = historyCenterX[0];
        float y1 = historyCenterX[1];
        float y2 = historyCenterX[2];

        float meanX = (x0 + x1 + x2) / 3.0f;
        float meanY = (y0 + y1 + y2) / 3.0f;

        float num = ((x0 - meanX) * (y0 - meanY))
                + ((x1 - meanX) * (y1 - meanY))
                + ((x2 - meanX) * (y2 - meanY));
        float den = ((x0 - meanX) * (x0 - meanX))
                + ((x1 - meanX) * (x1 - meanX))
                + ((x2 - meanX) * (x2 - meanX));

        if (den <= 0.001f) {
            return 0.0f;
        }
        return num / den;
    }

    public static void executeSubFrameSleepIfNeeded(long waitNanos) {
        if (waitNanos <= 0L) {
            return;
        }
        long clampedNanos = Math.min(waitNanos, 14_000_000L);
        long deadlineNs = System.nanoTime() + clampedNanos;
        if (clampedNanos > 250_000L) {
            LockSupport.parkNanos(clampedNanos - 150_000L);
        }
        while (System.nanoTime() < deadlineNs) {
            Thread.onSpinWait();
        }
    }

    private void markTriggered(long triggerUptimeMs) {
        this.lastTriggerUptimeMs = triggerUptimeMs;
        this.totalShotsFired++;
        resetHistory();
    }

    public float getCurrentVelocityPxPerMs() {
        return currentVelocityPxPerMs;
    }

    private static float clamp(float val, float min, float max) {
        return Math.max(min, Math.min(max, val));
    }
}
