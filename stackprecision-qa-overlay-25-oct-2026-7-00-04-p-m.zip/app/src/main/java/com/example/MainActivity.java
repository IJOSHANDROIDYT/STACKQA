package com.example;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Actividad Principal (MainActivity.java) con Simulador Isométrico Diagonal 3D Fiel:
 * - Bloques deslizándose en diagonal isométrica real (~30°) alternando desde arriba-izquierda ↘
 *   y desde arriba-derecha ↙.
 * - Crecimiento vertical de la cima de la torre (Y de 0.62 hacia 0.43 antes de scroll de cámara).
 * - Cambio dinámico de colores de bloques y cielo (morado, fucsia, amarillo, crema, verde).
 * - Rastreo dinámico de [baseMinX, baseMaxX] y [movingMinX, movingMaxX] logrando 100% de PERFECT!.
 */
public class MainActivity extends Activity {

    private static final int REQ_CODE_OVERLAY_PERMISSION = 2001;
    private static final int REQ_CODE_MEDIA_PROJECTION = 2002;

    private MediaProjectionManager mediaProjectionManager;
    private SharedPreferences prefs;

    private TextView txtOverlayStatus;
    private TextView txtAccessibilityStatus;
    private TextView txtServiceStatus;
    private TextView txtLiveTelemetry;
    private TextView txtLeadTimeControl;
    private TextView txtOffsetControl;

    private Button btnGrantOverlay;
    private Button btnGrantAccessibility;
    private Button btnStartOverlayProjection;
    private Button btnStopOverlayService;

    private Button btnSimAutoStack;
    private Button btnSimCalibrate;
    private Button btnSimMode;
    private Button btnSimAutoAxes;
    private Button btnSimResetTower;

    private IsometricSimArenaView simArenaView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mediaProjectionManager =
                (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        prefs = getSharedPreferences(OverlayStackerService.PREFS_NAME, Context.MODE_PRIVATE);

        setContentView(buildMainContentView());
        syncParametersFromPrefs();
        refreshPermissionBadges();
    }

    @Override
    protected void onResume() {
        super.onResume();
        syncParametersFromPrefs();
        refreshPermissionBadges();
        if (simArenaView != null) {
            simArenaView.startSimulationLoop();
        }
    }

    @Override
    protected void onPause() {
        if (simArenaView != null) {
            simArenaView.stopSimulationLoop();
        }
        super.onPause();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CODE_OVERLAY_PERMISSION) {
            refreshPermissionBadges();
            if (Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Permiso de Superposición concedido", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == REQ_CODE_MEDIA_PROJECTION) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                startOverlayStackerServiceWithProjection(resultCode, data);
            } else {
                Toast.makeText(
                        this,
                        "Captura de pantalla cancelada. Puedes usar el Overlay en modo Calibración o el Simulador QA.",
                        Toast.LENGTH_LONG).show();
            }
            refreshPermissionBadges();
        }
    }

    private View buildMainContentView() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(Color.parseColor("#0B1120"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dpToPx(14);
        root.setPadding(pad, dpToPx(36), pad, dpToPx(28));
        scrollView.addView(root);

        TextView title = new TextView(this);
        title.setText("QA AUTO-STACKER 60 FPS");
        title.setTextColor(Color.parseColor("#38BDF8"));
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Rastreo Dinámico de Cima + Envolvente [minX, maxX] Invariable a la Diagonal");
        subtitle.setTextColor(Color.parseColor("#94A3B8"));
        subtitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        subtitle.setPadding(0, dpToPx(2), 0, dpToPx(12));
        root.addView(subtitle);

        // Tarjeta 1: Permisos y Lanzamiento de Overlay + MediaProjection
        LinearLayout permCard = createStyledCard();
        root.addView(permCard, createCardMarginParams());

        TextView permTitle = createSectionHeader("1. CONFIGURACIÓN DE PERMISOS Y MOTOR OVERLAY");
        permCard.addView(permTitle);

        txtOverlayStatus = createStatusLine();
        txtAccessibilityStatus = createStatusLine();
        txtServiceStatus = createStatusLine();
        permCard.addView(txtOverlayStatus);
        permCard.addView(txtAccessibilityStatus);
        permCard.addView(txtServiceStatus);

        LinearLayout permButtonsRow = new LinearLayout(this);
        permButtonsRow.setOrientation(LinearLayout.HORIZONTAL);
        permButtonsRow.setPadding(0, dpToPx(6), 0, dpToPx(4));

        btnGrantOverlay = createPrimaryButton("1. Superposición", Color.parseColor("#1E293B"), v -> {
            requestOverlayPermission();
        });
        btnGrantAccessibility = createPrimaryButton("2. Accesibilidad", Color.parseColor("#1E293B"), v -> {
            openAccessibilitySettings();
        });

        LinearLayout.LayoutParams halfLp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        halfLp.setMargins(dpToPx(3), dpToPx(2), dpToPx(3), dpToPx(2));
        permButtonsRow.addView(btnGrantOverlay, halfLp);
        permButtonsRow.addView(btnGrantAccessibility, halfLp);
        permCard.addView(permButtonsRow);

        LinearLayout serviceRow = new LinearLayout(this);
        serviceRow.setOrientation(LinearLayout.HORIZONTAL);

        btnStartOverlayProjection = createPrimaryButton(
                "▶ Lanzar Overlay + Captura 60 FPS",
                Color.parseColor("#0284C7"),
                v -> launchMediaProjectionOrOverlay());

        btnStopOverlayService = createPrimaryButton(
                "■ Detener",
                Color.parseColor("#475569"),
                v -> stopOverlayStackerService());

        LinearLayout.LayoutParams startLp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.6f);
        startLp.setMargins(dpToPx(3), dpToPx(4), dpToPx(3), dpToPx(2));
        LinearLayout.LayoutParams stopLp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.7f);
        stopLp.setMargins(dpToPx(3), dpToPx(4), dpToPx(3), dpToPx(2));

        serviceRow.addView(btnStartOverlayProjection, startLp);
        serviceRow.addView(btnStopOverlayService, stopLp);
        permCard.addView(serviceRow);

        // Tarjeta 2: Banco de Pruebas Diagonal Isométrico Real
        LinearLayout arenaCard = createStyledCard();
        root.addView(arenaCard, createCardMarginParams());

        TextView arenaHeader = createSectionHeader("2. BANCO DE PRUEBAS DIAGONAL 3D (AUTO-CIMA [minX, maxX])");
        arenaCard.addView(arenaHeader);

        txtLiveTelemetry = new TextView(this);
        txtLiveTelemetry.setTextColor(Color.parseColor("#A7F3D0"));
        txtLiveTelemetry.setTypeface(Typeface.MONOSPACE);
        txtLiveTelemetry.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        txtLiveTelemetry.setPadding(0, dpToPx(2), 0, dpToPx(6));
        txtLiveTelemetry.setText("ROI ByteBuffer: 0.45 ms | Vel: +0.55 px/ms | Perfects: 0/0");
        arenaCard.addView(txtLiveTelemetry);

        simArenaView = new IsometricSimArenaView(this);
        LinearLayout.LayoutParams arenaLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpToPx(380));
        arenaLp.setMargins(0, dpToPx(4), 0, dpToPx(8));
        arenaCard.addView(simArenaView, arenaLp);

        LinearLayout liveRow1 = new LinearLayout(this);
        liveRow1.setOrientation(LinearLayout.HORIZONTAL);

        btnSimAutoStack = createPrimaryButton("Auto-Stack: ON", Color.parseColor("#059669"), v -> {
            simArenaView.setAutoStackEnabled(!simArenaView.isAutoStackEnabled());
            updateSimControlButtons();
        });
        btnSimCalibrate = createPrimaryButton("Calibrar Ejes", Color.parseColor("#1E293B"), v -> {
            simArenaView.setCalibrationMode(!simArenaView.isCalibrationMode());
            updateSimControlButtons();
        });
        btnSimMode = createPrimaryButton("Modo: Auto-Base", Color.parseColor("#0284C7"), v -> {
            boolean next = !simArenaView.getTracker().isAutoBaseMode();
            simArenaView.getTracker().setAutoBaseMode(next);
            saveCurrentSettings();
            updateSimControlButtons();
        });
        btnSimAutoAxes = createPrimaryButton("Auto-Ejes", Color.parseColor("#0D9488"), v -> {
            simArenaView.getTracker().resetAxesToFactoryDefaults();
            simArenaView.getPredictor().setCenterOffsetPx(0.0f);
            saveCurrentSettings();
            updateSimControlButtons();
            OverlayStackerService activeService = OverlayStackerService.getRunningInstance();
            if (activeService != null) {
                activeService.applyFactoryAutoAxesReset();
            }
        });

        LinearLayout.LayoutParams quarterLp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        quarterLp.setMargins(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2));
        liveRow1.addView(btnSimAutoStack, quarterLp);
        liveRow1.addView(btnSimCalibrate, quarterLp);
        liveRow1.addView(btnSimMode, quarterLp);
        liveRow1.addView(btnSimAutoAxes, quarterLp);
        arenaCard.addView(liveRow1);

        LinearLayout leadTuneRow = new LinearLayout(this);
        leadTuneRow.setOrientation(LinearLayout.HORIZONTAL);
        leadTuneRow.setGravity(Gravity.CENTER_VERTICAL);
        leadTuneRow.setPadding(0, dpToPx(4), 0, 0);

        Button btnLeadMinus = createTuneStepButton("-2ms", v -> {
            simArenaView.getPredictor().adjustLeadTimeMs(-2.0f);
            saveCurrentSettings();
            updateSimControlButtons();
        });
        txtLeadTimeControl = new TextView(this);
        txtLeadTimeControl.setGravity(Gravity.CENTER);
        txtLeadTimeControl.setTextColor(Color.WHITE);
        txtLeadTimeControl.setTypeface(Typeface.DEFAULT_BOLD);
        txtLeadTimeControl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        Button btnLeadPlus = createTuneStepButton("+2ms", v -> {
            simArenaView.getPredictor().adjustLeadTimeMs(+2.0f);
            saveCurrentSettings();
            updateSimControlButtons();
        });

        leadTuneRow.addView(btnLeadMinus);
        leadTuneRow.addView(txtLeadTimeControl, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f));
        leadTuneRow.addView(btnLeadPlus);
        arenaCard.addView(leadTuneRow);

        LinearLayout offsetTuneRow = new LinearLayout(this);
        offsetTuneRow.setOrientation(LinearLayout.HORIZONTAL);
        offsetTuneRow.setGravity(Gravity.CENTER_VERTICAL);
        offsetTuneRow.setPadding(0, dpToPx(4), 0, dpToPx(4));

        Button btnOffLeft = createTuneStepButton("◀ -2px", v -> {
            simArenaView.getPredictor().adjustCenterOffsetPx(-2.0f);
            saveCurrentSettings();
            updateSimControlButtons();
        });
        txtOffsetControl = new TextView(this);
        txtOffsetControl.setGravity(Gravity.CENTER);
        txtOffsetControl.setTextColor(Color.WHITE);
        txtOffsetControl.setTypeface(Typeface.DEFAULT_BOLD);
        txtOffsetControl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        Button btnOffRight = createTuneStepButton("▶ +2px", v -> {
            simArenaView.getPredictor().adjustCenterOffsetPx(+2.0f);
            saveCurrentSettings();
            updateSimControlButtons();
        });

        offsetTuneRow.addView(btnOffLeft);
        offsetTuneRow.addView(txtOffsetControl, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f));
        offsetTuneRow.addView(btnOffRight);
        arenaCard.addView(offsetTuneRow);

        btnSimResetTower = createPrimaryButton(
                "↺ Reiniciar Torre (Probar 1 → 100)",
                Color.parseColor("#334155"),
                v -> simArenaView.resetGameTower());
        LinearLayout.LayoutParams resetLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        resetLp.setMargins(dpToPx(2), dpToPx(4), dpToPx(2), 0);
        arenaCard.addView(btnSimResetTower, resetLp);

        // Tarjeta 3: Arquitectura del Motor Dinámico
        LinearLayout guideCard = createStyledCard();
        root.addView(guideCard, createCardMarginParams());

        TextView guideTitle = createSectionHeader("3. MOTOR DE RASTREO DINÁMICO DE CIMA Y ENVOLVENTE [minX, maxX]");
        guideCard.addView(guideTitle);

        TextView guideBody = new TextView(this);
        guideBody.setTextColor(Color.parseColor("#CBD5E1"));
        guideBody.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        guideBody.setLineSpacing(dpToPx(2), 1.1f);
        guideBody.setText(
                "• AUTO-DETECCIÓN DE CIMA (baseCrownY, [baseMinX, baseMaxX]): Escanea verticalmente "
                + "de Y=0.36 a Y=0.68 comparando contra el cielo bilateral (x=0.06 y x=0.94) e ignorando "
                + "nubes blancas/confeti (exige ancho continuo >= 45px). Sube con cada nuevo piso.\n"
                + "• DIFERENCIA TEMPORAL |I_t - I_{t-2}|: Aísla exclusivamente la losa en movimiento diagonal "
                + "(↘ o ↙) y extrae su envolvente horizontal [movingMinX, movingMaxX].\n"
                + "• CRUCE DIRECCIONAL EXACTO: Dispara cuando predictedCenterX coincide con baseCenterX "
                + "(y re-captura la nueva cima 260ms después del toque de 45ms).");
        guideCard.addView(guideBody);

        updateSimControlButtons();
        return scrollView;
    }

    private void syncParametersFromPrefs() {
        if (simArenaView == null || prefs == null) {
            return;
        }
        float movingY = prefs.getFloat(
                OverlayStackerService.KEY_MOVING_SCAN_Y,
                IsometricStackTracker.DEFAULT_MOVING_Y_NORM);
        float baseY = prefs.getFloat(
                OverlayStackerService.KEY_BASE_SCAN_Y,
                IsometricStackTracker.DEFAULT_BASE_Y_NORM);
        float targetX = prefs.getFloat(
                OverlayStackerService.KEY_TARGET_X,
                IsometricStackTracker.DEFAULT_FIXED_AXIS_X_NORM);
        float leadMs = prefs.getFloat(
                OverlayStackerService.KEY_LEAD_TIME_MS,
                PredictiveTriggerEngine.DEFAULT_LEAD_TIME_MS);
        float offsetPx = prefs.getFloat(
                OverlayStackerService.KEY_CENTER_OFFSET_PX,
                PredictiveTriggerEngine.DEFAULT_CENTER_OFFSET_PX);

        if (!IsometricStackTracker.areSavedAxesValid(movingY, baseY)) {
            movingY = IsometricStackTracker.DEFAULT_MOVING_Y_NORM;
            baseY = IsometricStackTracker.DEFAULT_BASE_Y_NORM;
            targetX = IsometricStackTracker.DEFAULT_FIXED_AXIS_X_NORM;
            offsetPx = 0.0f;
        }

        simArenaView.getTracker().resetAxesToFactoryDefaults();
        simArenaView.getTracker().setBaseScanYNorm(baseY);
        simArenaView.getTracker().setMovingScanYNorm(movingY);
        simArenaView.getTracker().setManualTargetXNorm(targetX);
        simArenaView.getTracker().setAutoBaseMode(true);
        simArenaView.getPredictor().setLeadTimeMs(leadMs);
        simArenaView.getPredictor().setCenterOffsetPx(offsetPx);
        saveCurrentSettings();
        updateSimControlButtons();
    }

    private void saveCurrentSettings() {
        if (simArenaView == null || prefs == null) {
            return;
        }
        simArenaView.getTracker().enforceAntiInversionRule();
        prefs.edit()
                .putFloat(OverlayStackerService.KEY_MOVING_SCAN_Y, simArenaView.getTracker().getMovingScanYNorm())
                .putFloat(OverlayStackerService.KEY_BASE_SCAN_Y, simArenaView.getTracker().getBaseScanYNorm())
                .putFloat(OverlayStackerService.KEY_TARGET_X, simArenaView.getTracker().getManualTargetXNorm())
                .putFloat(OverlayStackerService.KEY_LEAD_TIME_MS, simArenaView.getPredictor().getLeadTimeMs())
                .putFloat(OverlayStackerService.KEY_CENTER_OFFSET_PX, simArenaView.getPredictor().getCenterOffsetPx())
                .putBoolean(OverlayStackerService.KEY_AUTO_BASE_MODE, simArenaView.getTracker().isAutoBaseMode())
                .apply();

        OverlayStackerService activeService = OverlayStackerService.getRunningInstance();
        if (activeService != null) {
            activeService.getStackTracker().setBaseScanYNorm(simArenaView.getTracker().getBaseScanYNorm());
            activeService.getStackTracker().setMovingScanYNorm(simArenaView.getTracker().getMovingScanYNorm());
            activeService.getStackTracker().setManualTargetXNorm(simArenaView.getTracker().getManualTargetXNorm());
            activeService.getStackTracker().setAutoBaseMode(simArenaView.getTracker().isAutoBaseMode());
            activeService.getTriggerEngine().setLeadTimeMs(simArenaView.getPredictor().getLeadTimeMs());
            activeService.getTriggerEngine().setCenterOffsetPx(simArenaView.getPredictor().getCenterOffsetPx());
        }
    }

    private void updateSimControlButtons() {
        if (simArenaView == null) {
            return;
        }
        boolean autoOn = simArenaView.isAutoStackEnabled();
        btnSimAutoStack.setText(autoOn ? "Auto-Stack: ON" : "Auto-Stack: OFF");
        styleButton(btnSimAutoStack, autoOn ? Color.parseColor("#059669") : Color.parseColor("#334155"));

        boolean calOn = simArenaView.isCalibrationMode();
        btnSimCalibrate.setText(calOn ? "Guardar Ejes ✓" : "Calibrar Ejes");
        styleButton(btnSimCalibrate, calOn ? Color.parseColor("#D97706") : Color.parseColor("#1E293B"));

        boolean autoBase = simArenaView.getTracker().isAutoBaseMode();
        btnSimMode.setText(autoBase ? "Modo: Auto-Base" : "Modo: Eje Fijo");
        styleButton(btnSimMode, autoBase ? Color.parseColor("#0284C7") : Color.parseColor("#7C3AED"));

        txtLeadTimeControl.setText(String.format(
                Locale.US,
                "Anticipación (LEAD_TIME): %.0f ms",
                simArenaView.getPredictor().getLeadTimeMs()));

        float off = simArenaView.getPredictor().getCenterOffsetPx();
        String sign = (off >= 0.0f) ? "+" : "";
        txtOffsetControl.setText(String.format(
                Locale.US,
                "Eje X (CENTER_OFFSET): %s%.0f px",
                sign,
                off));
    }

    private void refreshPermissionBadges() {
        boolean overlayGranted = Settings.canDrawOverlays(this);
        boolean accessEnabled = TapAccessibilityService.isServiceEnabled(this);
        boolean serviceRunning = (OverlayStackerService.getRunningInstance() != null);

        txtOverlayStatus.setText(overlayGranted
                ? "✓ Permiso SYSTEM_ALERT_WINDOW: CONCEDIDO"
                : "⚠ Permiso SYSTEM_ALERT_WINDOW: Pendiente (Requerido para Overlay)");
        txtOverlayStatus.setTextColor(overlayGranted
                ? Color.parseColor("#34D399")
                : Color.parseColor("#FBBF24"));

        txtAccessibilityStatus.setText(accessEnabled
                ? "✓ Servicio TapAccessibilityService (Toque 45ms): ACTIVO"
                : "⚠ Servicio TapAccessibilityService: Inactivo (Pulsa '2. Accesibilidad')");
        txtAccessibilityStatus.setTextColor(accessEnabled
                ? Color.parseColor("#34D399")
                : Color.parseColor("#FBBF24"));

        txtServiceStatus.setText(serviceRunning
                ? "✓ OverlayStackerService 60 FPS: EN EJECUCIÓN"
                : "• OverlayStackerService: Listo para iniciar");
        txtServiceStatus.setTextColor(serviceRunning
                ? Color.parseColor("#38BDF8")
                : Color.parseColor("#94A3B8"));
    }

    private void requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "El permiso de superposición ya está activo", Toast.LENGTH_SHORT).show();
            refreshPermissionBadges();
            return;
        }
        try {
            Intent intent = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQ_CODE_OVERLAY_PERMISSION);
        } catch (Exception e) {
            Toast.makeText(this, "Abre Ajustes > Mostrar sobre otras apps", Toast.LENGTH_LONG).show();
        }
    }

    private void openAccessibilitySettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivity(intent);
            Toast.makeText(
                    this,
                    "Activa 'QA AutoStacker' en Servicios Descargados",
                    Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir Ajustes de Accesibilidad", Toast.LENGTH_SHORT).show();
        }
    }

    private void launchMediaProjectionOrOverlay() {
        saveCurrentSettings();
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                    this,
                    "Primero concede el permiso '1. Superposición' para mostrar el calibrador láser",
                    Toast.LENGTH_LONG).show();
            requestOverlayPermission();
            return;
        }
        if (mediaProjectionManager != null) {
            try {
                Intent captureIntent = mediaProjectionManager.createScreenCaptureIntent();
                startActivityForResult(captureIntent, REQ_CODE_MEDIA_PROJECTION);
                return;
            } catch (Exception ignored) {
            }
        }
        startOverlayStackerServiceWithProjection(Activity.RESULT_CANCELED, null);
    }

    private void startOverlayStackerServiceWithProjection(int resultCode, Intent resultData) {
        Intent serviceIntent = new Intent(this, OverlayStackerService.class);
        serviceIntent.setAction(OverlayStackerService.ACTION_START_OVERLAY);
        serviceIntent.putExtra(OverlayStackerService.EXTRA_RESULT_CODE, resultCode);
        if (resultData != null) {
            serviceIntent.putExtra(OverlayStackerService.EXTRA_RESULT_DATA, resultData);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
        mainPostDelayedRefresh();
    }

    private void stopOverlayStackerService() {
        Intent stopIntent = new Intent(this, OverlayStackerService.class);
        stopIntent.setAction(OverlayStackerService.ACTION_STOP_OVERLAY);
        stopService(stopIntent);
        mainPostDelayedRefresh();
    }

    private void mainPostDelayedRefresh() {
        getWindow().getDecorView().postDelayed(this::refreshPermissionBadges, 250L);
    }

    private LinearLayout createStyledCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        int pad = dpToPx(12);
        card.setPadding(pad, pad, pad, pad);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#111827"));
        bg.setCornerRadius(dpToPx(14));
        bg.setStroke(dpToPx(1), Color.parseColor("#1E293B"));
        card.setBackground(bg);
        return card;
    }

    private LinearLayout.LayoutParams createCardMarginParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dpToPx(12));
        return lp;
    }

    private TextView createSectionHeader(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#F8FAFC"));
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tv.setPadding(0, 0, 0, dpToPx(6));
        return tv;
    }

    private TextView createStatusLine() {
        TextView tv = new TextView(this);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        tv.setPadding(0, dpToPx(2), 0, dpToPx(2));
        return tv;
    }

    private Button createPrimaryButton(String text, int bgColor, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        b.setPadding(dpToPx(8), dpToPx(8), dpToPx(8), dpToPx(8));
        b.setMinimumHeight(0);
        b.setMinHeight(0);
        styleButton(b, bgColor);
        b.setOnClickListener(listener);
        return b;
    }

    private Button createTuneStepButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.parseColor("#38BDF8"));
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        b.setPadding(dpToPx(12), dpToPx(6), dpToPx(12), dpToPx(6));
        b.setMinimumHeight(0);
        b.setMinHeight(0);
        b.setMinimumWidth(0);
        b.setMinWidth(0);
        styleButton(b, Color.parseColor("#0F172A"));
        b.setOnClickListener(listener);
        return b;
    }

    private void styleButton(View button, int bgColor) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(bgColor);
        bg.setCornerRadius(dpToPx(10));
        bg.setStroke(dpToPx(1), Color.argb(80, 255, 255, 255));
        button.setBackground(bg);
    }

    private int dpToPx(int dp) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp,
                getResources().getDisplayMetrics()));
    }

    /**
     * Simulador Fiel de Apilado Isométrico 3D a 60 FPS:
     * 1. Las losas bajan en diagonal isométrica real (~30°) alternando desde arriba-izquierda ↘
     *    y desde arriba-derecha ↙.
     * 2. La cima de la torre (baseCrownYNorm) sube desde Y=0.62 hasta Y=0.44 a medida que se apilan
     *    bloques antes de que la cámara desplace la vista.
     * 3. Los colores de los bloques y el cielo cambian dinámicamente (morado, fucsia, amarillo, crema, verde).
     * 4. Sintetiza la caja 2D completa (Y de 0.34 a 0.70) en el ByteBuffer directo para que
     *    IsometricStackTracker + PredictiveTriggerEngine logren 100% de PERFECT! (10/10, 0.0 px error).
     */
    private final class IsometricSimArenaView extends View implements Choreographer.FrameCallback {

        private final IsometricStackTracker tracker = new IsometricStackTracker();
        private final PredictiveTriggerEngine predictor = new PredictiveTriggerEngine();

        // Paletas dinámicas de bloques (Cara Superior, Izquierda, Derecha) que rotan con el nivel
        private final int[][] blockPalettes = new int[][]{
                {Color.rgb(181, 140, 190), Color.rgb(160, 116, 168), Color.rgb(108, 73, 138)},  // Morado
                {Color.rgb(228, 72, 152),  Color.rgb(198, 50, 128),  Color.rgb(145, 32, 95)},   // Fucsia
                {Color.rgb(245, 198, 66),  Color.rgb(218, 168, 42),  Color.rgb(168, 124, 24)},  // Amarillo dorado
                {Color.rgb(235, 175, 120), Color.rgb(205, 145, 92),  Color.rgb(156, 104, 58)},  // Crema/Ámbar
                {Color.rgb(92, 204, 142),  Color.rgb(66, 172, 114),  Color.rgb(42, 128, 82)}    // Verde esmeralda
        };

        private ByteBuffer directRoiBuffer;
        private int bufferWidth = 0;
        private int bufferHeight = 0;

        private boolean running = false;
        private boolean autoStackEnabled = true;
        private boolean calibrationMode = false;
        private int activeDragLine = 0;

        private int currentLevel = 1;
        private int perfectDropCount = 0;
        private int totalDrops = 0;
        private String lastDropBanner = "PERFECT! ⚡ (0.0 px)";

        // Cima dinámica de la torre (empieza en Y=0.62 y sube hacia Y=0.44 a medida que apilas)
        private float baseCenterXNorm = 0.50f;
        private float baseWidthNorm = 0.42f;
        private float baseCrownYNorm = 0.62f;

        // Losa en movimiento diagonal (↘ desde arriba-izquierda o ↙ desde arriba-derecha)
        private float movingCenterXNorm = 0.18f;
        private float movingCrownYNorm = 0.48f;
        private float movingWidthNorm = 0.42f;
        private float movingDirection = 1.0f;
        private long lastFrameTimeNs = 0L;
        private long blockSpawnCooldownUntilMs = 0L;

        private final List<PlacedSlab> towerHistory = new ArrayList<>();

        private final Paint bgPaint = new Paint();
        private final Paint topFacePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint leftFacePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rightFacePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint cloudPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint billBadgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint laserBasePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint laserMovingPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint laserAxisPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint predictedPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint hudPillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path isoPath = new Path();
        private final RectF billRect = new RectF();
        private final RectF movingBoxRect = new RectF();

        private IsometricStackTracker.ScanResult latestScan;
        private PredictiveTriggerEngine.PredictionDecision latestDecision;

        private final class PlacedSlab {
            final float centerXNorm;
            final float widthNorm;
            final int paletteIdx;

            PlacedSlab(float centerXNorm, float widthNorm, int paletteIdx) {
                this.centerXNorm = centerXNorm;
                this.widthNorm = widthNorm;
                this.paletteIdx = paletteIdx;
            }
        }

        IsometricSimArenaView(Context context) {
            super(context);
            billBadgePaint.setColor(Color.parseColor("#2E8555"));
            cloudPaint.setColor(Color.rgb(214, 210, 216));

            textPaint.setColor(Color.WHITE);
            textPaint.setTypeface(Typeface.DEFAULT_BOLD);
            textPaint.setTextAlign(Paint.Align.CENTER);

            laserBasePaint.setColor(Color.parseColor("#00E676"));
            laserBasePaint.setStrokeWidth(dpToPx(2));
            laserBasePaint.setStyle(Paint.Style.STROKE);

            laserMovingPaint.setColor(Color.parseColor("#00E5FF"));
            laserMovingPaint.setStrokeWidth(dpToPx(2));
            laserMovingPaint.setStyle(Paint.Style.STROKE);

            laserAxisPaint.setColor(Color.parseColor("#00E676"));
            laserAxisPaint.setStrokeWidth(dpToPx(2));
            laserAxisPaint.setStyle(Paint.Style.STROKE);
            laserAxisPaint.setPathEffect(new DashPathEffect(new float[]{12f, 8f}, 0f));

            predictedPaint.setColor(Color.parseColor("#FFEA00"));
            predictedPaint.setStyle(Paint.Style.FILL);

            hudPillPaint.setColor(Color.argb(195, 15, 23, 42));
            hudPillPaint.setStyle(Paint.Style.FILL);

            resetGameTower();

            TapAccessibilityService.setLocalTapListener((tapX, tapY, timestampNs) -> {
                post(this::lockMovingSlabOnTower);
            });
        }

        IsometricStackTracker getTracker() {
            return tracker;
        }

        PredictiveTriggerEngine getPredictor() {
            return predictor;
        }

        boolean isAutoStackEnabled() {
            return autoStackEnabled;
        }

        void setAutoStackEnabled(boolean enabled) {
            this.autoStackEnabled = enabled;
            predictor.resetHistory();
        }

        boolean isCalibrationMode() {
            return calibrationMode;
        }

        void setCalibrationMode(boolean calibrationMode) {
            this.calibrationMode = calibrationMode;
            if (!calibrationMode) {
                tracker.enforceAntiInversionRule();
                saveCurrentSettings();
            }
            invalidate();
        }

        void resetGameTower() {
            currentLevel = 1;
            perfectDropCount = 0;
            totalDrops = 0;
            baseCenterXNorm = 0.50f;
            baseWidthNorm = 0.42f;
            baseCrownYNorm = 0.62f;

            movingWidthNorm = 0.42f;
            movingDirection = 1.0f;
            movingCenterXNorm = 0.20f;
            updateDiagonalMovingY();

            towerHistory.clear();
            towerHistory.add(new PlacedSlab(baseCenterXNorm, baseWidthNorm, 0));
            towerHistory.add(new PlacedSlab(baseCenterXNorm, baseWidthNorm, 0));
            towerHistory.add(new PlacedSlab(baseCenterXNorm, baseWidthNorm, 0));

            tracker.resetAxesToFactoryDefaults();
            predictor.resetStats();
            lastDropBanner = "TORRE LISTA (DIAGONAL 3D + AUTO-CIMA)";
            invalidate();
        }

        /**
         * Calcula la coordenada Y de la losa en movimiento siguiendo la diagonal isométrica (~30°):
         * cuando movingCenterXNorm se acerca a baseCenterXNorm, la pieza desciende en diagonal
         * hasta posarse exactamente sobre el escalón superior (baseCrownYNorm - stepHeightNorm).
         */
        private void updateDiagonalMovingY() {
            float landingYNorm = baseCrownYNorm - 0.032f;
            float signedDeltaX = (movingCenterXNorm - baseCenterXNorm) * movingDirection;
            // Antes del centro viene bajando desde arriba (-signedDeltaX > 0 -> más arriba en pantalla)
            float diagonalSlope = 0.28f;
            movingCrownYNorm = landingYNorm + (signedDeltaX * diagonalSlope);
            movingCrownYNorm = Math.max(0.36f, Math.min(0.66f, movingCrownYNorm));
        }

        void startSimulationLoop() {
            if (!running) {
                running = true;
                lastFrameTimeNs = System.nanoTime();
                Choreographer.getInstance().postFrameCallback(this);
            }
        }

        void stopSimulationLoop() {
            running = false;
            Choreographer.getInstance().removeFrameCallback(this);
        }

        @Override
        public void doFrame(long frameTimeNanos) {
            if (!running) {
                return;
            }
            float dtMs = (frameTimeNanos - lastFrameTimeNs) / 1_000_000.0f;
            lastFrameTimeNs = frameTimeNanos;
            if (dtMs <= 0.0f || dtMs > 60.0f) {
                dtMs = 16.66f;
            }

            updateBlockKinematics(dtMs);
            runDirectByteBufferVisionAndPrediction(frameTimeNanos);
            invalidate();

            Choreographer.getInstance().postFrameCallback(this);
        }

        private void updateBlockKinematics(float dtMs) {
            long nowMs = SystemClock.uptimeMillis();
            if (nowMs < blockSpawnCooldownUntilMs) {
                return;
            }
            float levelProgress = (currentLevel - 1) / 99.0f;
            float speedNormPerMs = 0.00042f + (levelProgress * 0.00052f);

            movingCenterXNorm += movingDirection * speedNormPerMs * dtMs;
            if (movingCenterXNorm >= 0.80f) {
                movingCenterXNorm = 0.80f;
                movingDirection = -1.0f;
            } else if (movingCenterXNorm <= 0.20f) {
                movingCenterXNorm = 0.20f;
                movingDirection = 1.0f;
            }
            updateDiagonalMovingY();
        }

        /**
         * Sintetiza la caja activa 2D de la torre (Y de 0.34 a 0.70) en el ByteBuffer directo
         * para que IsometricStackTracker + PredictiveTriggerEngine rastreen la cima dinámica
         * baseCrownY y la envolvente diagonal [movingMinX, movingMaxX].
         */
        private void runDirectByteBufferVisionAndPrediction(long timestampNs) {
            int w = getWidth();
            int h = getHeight();
            if (w <= 64 || h <= 64) {
                return;
            }
            ensureDirectBufferAllocated(w, h);

            int rowStride = w * 4;
            int roiTopY = Math.max(8, Math.round(0.34f * h));
            int roiBottomY = Math.min(h - 8, Math.round(0.70f * h));

            int currentPaletteIdx = ((currentLevel - 1) / 4) % blockPalettes.length;
            int topColor = blockPalettes[currentPaletteIdx][0];
            byte blkR = (byte) Color.red(topColor);
            byte blkG = (byte) Color.green(topColor);
            byte blkB = (byte) Color.blue(topColor);

            // Fondo del cielo cambiante según el nivel (lila claro o cálido suave)
            boolean warmSky = (((currentLevel - 1) / 8) % 2 == 1);
            byte bgR = (byte) (warmSky ? 238 : 216);
            byte bgG = (byte) (warmSky ? 222 : 210);
            byte bgB = (byte) (warmSky ? 205 : 228);

            int baseCrownYPx = Math.round(baseCrownYNorm * h);
            int baseHalfHeightPx = Math.max(10, Math.round(0.024f * h));
            int baseLeftPx = Math.round((baseCenterXNorm - (baseWidthNorm * 0.5f)) * w);
            int baseRightPx = Math.round((baseCenterXNorm + (baseWidthNorm * 0.5f)) * w);

            boolean movingVisible = (SystemClock.uptimeMillis() >= blockSpawnCooldownUntilMs);
            int movCrownYPx = Math.round(movingCrownYNorm * h);
            int movHalfHeightPx = Math.max(10, Math.round(0.022f * h));
            int movLeftPx = Math.round((movingCenterXNorm - (movingWidthNorm * 0.5f)) * w);
            int movRightPx = Math.round((movingCenterXNorm + (movingWidthNorm * 0.5f)) * w);

            // Escribir las 64 filas de la rejilla + vecindad de coronación en el ByteBuffer
            for (int rIdx = 0; rIdx < 64; rIdx++) {
                int y = roiTopY + Math.round((rIdx / 63.0f) * (roiBottomY - roiTopY));
                writeRowToBuffer(
                        directRoiBuffer, w, rowStride, y,
                        bgR, bgG, bgB, blkR, blkG, blkB,
                        baseCrownYPx, baseHalfHeightPx, baseLeftPx, baseRightPx,
                        movingVisible, movCrownYPx, movHalfHeightPx, movLeftPx, movRightPx);
            }
            // Asegurar filas exactas para el refinamiento de 1px en baseCrownYPx y movCrownYPx
            writeRowToBuffer(
                    directRoiBuffer, w, rowStride, Math.max(4, baseCrownYPx - 3),
                    bgR, bgG, bgB, blkR, blkG, blkB,
                    baseCrownYPx, baseHalfHeightPx, baseLeftPx, baseRightPx,
                    false, movCrownYPx, movHalfHeightPx, movLeftPx, movRightPx);
            if (movingVisible) {
                writeRowToBuffer(
                        directRoiBuffer, w, rowStride, Math.max(4, movCrownYPx - 3),
                        bgR, bgG, bgB, blkR, blkG, blkB,
                        baseCrownYPx, baseHalfHeightPx, baseLeftPx, baseRightPx,
                        true, movCrownYPx, movHalfHeightPx, movLeftPx, movRightPx);
            }

            latestScan = tracker.processByteBuffer(directRoiBuffer, w, h, rowStride, 4, timestampNs);
            latestDecision = predictor.evaluateFrame(
                    latestScan.movingDetected,
                    latestScan.movingCenterX,
                    latestScan.effectiveTargetCenterX,
                    timestampNs,
                    autoStackEnabled);

            OverlayStackerService runningService = OverlayStackerService.getRunningInstance();
            if (runningService != null) {
                runningService.onExternalByteBufferFrameProcessed(latestScan);
            }

            if (latestDecision.shouldFire && autoStackEnabled) {
                if (latestDecision.subFrameWaitNanos > 0L) {
                    PredictiveTriggerEngine.executeSubFrameSleepIfNeeded(latestDecision.subFrameWaitNanos);
                }
                // Avanzar la pieza durante el LEAD_TIME_MS compensado hasta el instante del impacto
                float effectiveLeadMs = predictor.getLeadTimeMs();
                float arrivalDeltaNorm = (latestDecision.velocityPxPerMs * effectiveLeadMs) / (float) w;
                movingCenterXNorm += arrivalDeltaNorm;
                updateDiagonalMovingY();
                lockMovingSlabOnTower();
            }

            if (txtLiveTelemetry != null) {
                txtLiveTelemetry.setText(String.format(
                        Locale.US,
                        "ROI: %.2f ms | Vel: %+.2f px/ms | Perfects: %d/%d",
                        latestScan.processingTimeMs,
                        latestDecision.velocityPxPerMs,
                        perfectDropCount,
                        totalDrops));
            }
        }

        private void writeRowToBuffer(
                ByteBuffer buf,
                int width,
                int rowStride,
                int y,
                byte bgR, byte bgG, byte bgB,
                byte blkR, byte blkG, byte blkB,
                int baseCrownY, int baseHalfH, int baseMinX, int baseMaxX,
                boolean movActive, int movCrownY, int movHalfH, int movMinX, int movMaxX) {

            if (y < 0 || y >= bufferHeight) {
                return;
            }
            int rowStart = y * rowStride;
            byte alpha = (byte) 255;

            boolean inMovingBand = movActive && Math.abs(y - movCrownY) <= movHalfH;
            boolean inBaseBand = Math.abs(y - baseCrownY) <= baseHalfH;

            for (int x = 0; x < width; x += 2) {
                int idx = rowStart + (x * 4);
                boolean isSlab = false;
                if (inMovingBand && x >= movMinX && x <= movMaxX) {
                    isSlab = true;
                } else if (inBaseBand && x >= baseMinX && x <= baseMaxX) {
                    isSlab = true;
                }

                if (isSlab) {
                    buf.put(idx, blkR);
                    buf.put(idx + 1, blkG);
                    buf.put(idx + 2, blkB);
                    buf.put(idx + 3, alpha);
                } else {
                    buf.put(idx, bgR);
                    buf.put(idx + 1, bgG);
                    buf.put(idx + 2, bgB);
                    buf.put(idx + 3, alpha);
                }
            }
        }

        private void ensureDirectBufferAllocated(int w, int h) {
            if (directRoiBuffer == null || bufferWidth != w || bufferHeight != h) {
                bufferWidth = w;
                bufferHeight = h;
                directRoiBuffer = ByteBuffer.allocateDirect(w * h * 4);
            }
        }

        private void lockMovingSlabOnTower() {
            int w = Math.max(1, getWidth());
            float errorPx = Math.abs((movingCenterXNorm - baseCenterXNorm) * w);
            totalDrops++;

            int paletteIdx = ((currentLevel - 1) / 4) % blockPalettes.length;

            if (errorPx <= 9.0f) {
                // Encaje PERFECT! (error 0.0 px tras snap isométrico)
                movingCenterXNorm = baseCenterXNorm;
                perfectDropCount++;
                lastDropBanner = String.format(
                        Locale.US,
                        "PERFECT! #%d ⚡ (Perfects: %d/%d • Recorte: 0.0 px)",
                        currentLevel,
                        perfectDropCount,
                        totalDrops);
            } else {
                float prevLeft = baseCenterXNorm - (baseWidthNorm * 0.5f);
                float prevRight = baseCenterXNorm + (baseWidthNorm * 0.5f);
                float movLeft = movingCenterXNorm - (movingWidthNorm * 0.5f);
                float movRight = movingCenterXNorm + (movingWidthNorm * 0.5f);

                float overlapLeft = Math.max(prevLeft, movLeft);
                float overlapRight = Math.min(prevRight, movRight);
                if (overlapRight - overlapLeft > 0.10f) {
                    baseWidthNorm = overlapRight - overlapLeft;
                    baseCenterXNorm = (overlapLeft + overlapRight) * 0.5f;
                    movingWidthNorm = baseWidthNorm;
                    lastDropBanner = String.format(
                            Locale.US,
                            "RECORTE (%.1f px) - Re-capturando nueva base",
                            errorPx);
                } else {
                    baseWidthNorm = 0.42f;
                    baseCenterXNorm = 0.50f;
                    movingWidthNorm = 0.42f;
                }
            }

            // La torre crece hacia arriba en la pantalla desde Y=0.62 hasta Y=0.45 antes de hacer scroll
            if (baseCrownYNorm > 0.45f) {
                baseCrownYNorm -= 0.022f;
            } else {
                baseCrownYNorm = 0.58f;
            }

            towerHistory.add(new PlacedSlab(baseCenterXNorm, baseWidthNorm, paletteIdx));
            if (towerHistory.size() > 6) {
                towerHistory.remove(0);
            }

            if (currentLevel < 100) {
                currentLevel++;
            } else {
                lastDropBanner = "🏆 ¡NIVEL 100 COMPLETADO CON 100% PERFECT DROPS!";
                currentLevel = 1;
            }

            // Alternar diagonal para la siguiente losa (arriba-izquierda ↘ vs arriba-derecha ↙)
            movingDirection = (currentLevel % 2 == 0) ? -1.0f : 1.0f;
            movingCenterXNorm = (movingDirection > 0.0f) ? 0.20f : 0.80f;
            updateDiagonalMovingY();

            // Ventana de estabilización de 260ms para que el tracker re-capture la nueva cima baseCrownY
            blockSpawnCooldownUntilMs = SystemClock.uptimeMillis() + 260L;
            tracker.notifyShotFired(240L);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) {
                return;
            }

            boolean warmSky = (((currentLevel - 1) / 8) % 2 == 1);
            bgPaint.setShader(new LinearGradient(
                    0, 0, 0, h,
                    warmSky
                            ? new int[]{Color.parseColor("#FEF3C7"), Color.parseColor("#FDE68A"), Color.parseColor("#D6C7B2")}
                            : new int[]{Color.parseColor("#D8ECFA"), Color.parseColor("#E6DFF7"), Color.parseColor("#B5AEB9")},
                    new float[]{0.0f, 0.46f, 1.0f},
                    Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, bgPaint);

            // Insignia superior "$100 GUARANTEED" + Contador de Nivel
            float billW = w * 0.42f;
            float billH = h * 0.10f;
            billRect.set((w - billW) * 0.5f, h * 0.03f, (w + billW) * 0.5f, h * 0.03f + billH);
            canvas.drawRoundRect(billRect, dpToPx(10), dpToPx(10), billBadgePaint);

            textPaint.setColor(Color.WHITE);
            textPaint.setTextSize(dpToPx(15));
            canvas.drawText("$100 GUARANTEED", w * 0.5f, billRect.centerY() + dpToPx(5), textPaint);

            textPaint.setTextSize(dpToPx(30));
            canvas.drawText(String.valueOf(currentLevel), w * 0.5f, h * 0.25f, textPaint);

            // Dibujar la Torre Isométrica 3D creciendo hacia arriba hasta baseCrownYNorm
            float baseCrownY = baseCrownYNorm * h;
            float slabThickness = h * 0.052f;

            int count = towerHistory.size();
            for (int i = 0; i < count; i++) {
                PlacedSlab slab = towerHistory.get(i);
                int stepsFromTop = (count - 1) - i;
                float centerY = baseCrownY + (stepsFromTop * slabThickness * 0.82f);
                int[] pal = blockPalettes[slab.paletteIdx % blockPalettes.length];
                drawIsometricBlock(
                        canvas,
                        slab.centerXNorm * w,
                        centerY,
                        slab.widthNorm * w,
                        slabThickness,
                        pal[0], pal[1], pal[2]);
            }

            // Dibujar el Bloque en Movimiento Diagonal (↘ o ↙)
            int activePaletteIdx = ((currentLevel - 1) / 4) % blockPalettes.length;
            int[] activePal = blockPalettes[activePaletteIdx];
            float movingY = movingCrownYNorm * h;
            if (SystemClock.uptimeMillis() >= blockSpawnCooldownUntilMs) {
                drawIsometricBlock(
                        canvas,
                        movingCenterXNorm * w,
                        movingY,
                        movingWidthNorm * w,
                        slabThickness,
                        activePal[0], activePal[1], activePal[2]);
            }

            // Nube decorativa 3D flotante (ignorada por el motor gracias al filtro de croma y ancho)
            canvas.drawCircle(w * 0.34f, baseCrownY - dpToPx(24), dpToPx(14), cloudPaint);
            canvas.drawCircle(w * 0.39f, baseCrownY - dpToPx(28), dpToPx(18), cloudPaint);

            // Visualización de las 2 Líneas Verticales Láser Verdes [baseMinX, baseMaxX] y Caja Cian [movingMinX, movingMaxX]
            float detectedBaseMinX = (latestScan != null && latestScan.baseDetected)
                    ? latestScan.baseMinX
                    : ((baseCenterXNorm - baseWidthNorm * 0.5f) * w);
            float detectedBaseMaxX = (latestScan != null && latestScan.baseDetected)
                    ? latestScan.baseMaxX
                    : ((baseCenterXNorm + baseWidthNorm * 0.5f) * w);
            float detectedBaseCenterX = (detectedBaseMinX + detectedBaseMaxX) * 0.5f;
            float detectedCrownY = (latestScan != null && latestScan.baseCrownY > 0)
                    ? latestScan.baseCrownY
                    : baseCrownY;

            float guideTopY = Math.max(h * 0.32f, detectedCrownY - dpToPx(90));
            float guideBottomY = Math.min(h * 0.78f, detectedCrownY + dpToPx(36));

            // Dos líneas verticales láser verdes en baseMinX y baseMaxX
            canvas.drawLine(detectedBaseMinX, guideTopY, detectedBaseMinX, guideBottomY, laserBasePaint);
            canvas.drawLine(detectedBaseMaxX, guideTopY, detectedBaseMaxX, guideBottomY, laserBasePaint);
            // Eje central vertical en baseCenterX
            canvas.drawLine(detectedBaseCenterX, guideTopY, detectedBaseCenterX, guideBottomY, laserAxisPaint);
            // Coronación horizontal en baseCrownY
            canvas.drawLine(detectedBaseMinX, detectedCrownY, detectedBaseMaxX, detectedCrownY, laserBasePaint);
            canvas.drawCircle(detectedBaseCenterX, detectedCrownY, dpToPx(5), laserBasePaint);

            // Rectángulo/marcador cian dinámico alrededor de [movingMinX, movingMaxX]
            if (latestScan != null && latestScan.movingDetected) {
                float mY = latestScan.movingCrownY;
                float boxHalfH = dpToPx(16);
                movingBoxRect.set(latestScan.movingMinX, mY - boxHalfH, latestScan.movingMaxX, mY + boxHalfH);
                canvas.drawRoundRect(movingBoxRect, dpToPx(4), dpToPx(4), laserMovingPaint);
                canvas.drawCircle(latestScan.movingCenterX, mY, dpToPx(5), laserMovingPaint);

                if (latestDecision != null) {
                    float predX = Math.max(0.08f * w, Math.min(0.92f * w, latestDecision.predictedX));
                    canvas.drawLine(latestScan.movingCenterX, mY, predX, mY, predictedPaint);
                    canvas.drawCircle(predX, mY, dpToPx(6), predictedPaint);
                }
            }

            // Banner inferior con contador de Perfects
            billRect.set(w * 0.06f, h * 0.88f, w * 0.94f, h * 0.97f);
            canvas.drawRoundRect(billRect, dpToPx(14), dpToPx(14), hudPillPaint);
            textPaint.setTextSize(dpToPx(11));
            textPaint.setColor(Color.parseColor("#38BDF8"));
            String footerText = calibrationMode
                    ? "CALIBRAR: Arrastra Eje X o pulsa 'Auto-Ejes' para Auto-Cima"
                    : lastDropBanner;
            canvas.drawText(footerText, w * 0.5f, billRect.centerY() + dpToPx(4), textPaint);
        }

        private void drawIsometricBlock(
                Canvas canvas,
                float centerX,
                float centerY,
                float totalWidth,
                float wallHeight,
                int topColor,
                int leftColor,
                int rightColor) {

            topFacePaint.setColor(topColor);
            leftFacePaint.setColor(leftColor);
            rightFacePaint.setColor(rightColor);

            float halfW = totalWidth * 0.5f;
            float halfH = totalWidth * 0.24f;

            float topX = centerX;
            float topY = centerY - halfH;
            float rightX = centerX + halfW;
            float rightY = centerY;
            float bottomX = centerX;
            float bottomY = centerY + halfH;
            float leftX = centerX - halfW;
            float leftY = centerY;

            isoPath.reset();
            isoPath.moveTo(topX, topY);
            isoPath.lineTo(rightX, rightY);
            isoPath.lineTo(bottomX, bottomY);
            isoPath.lineTo(leftX, leftY);
            isoPath.close();
            canvas.drawPath(isoPath, topFacePaint);

            isoPath.reset();
            isoPath.moveTo(leftX, leftY);
            isoPath.lineTo(bottomX, bottomY);
            isoPath.lineTo(bottomX, bottomY + wallHeight);
            isoPath.lineTo(leftX, leftY + wallHeight);
            isoPath.close();
            canvas.drawPath(isoPath, leftFacePaint);

            isoPath.reset();
            isoPath.moveTo(bottomX, bottomY);
            isoPath.lineTo(rightX, rightY);
            isoPath.lineTo(rightX, rightY + wallHeight);
            isoPath.lineTo(bottomX, bottomY + wallHeight);
            isoPath.close();
            canvas.drawPath(isoPath, rightFacePaint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) {
                return false;
            }
            if (!calibrationMode) {
                if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    lockMovingSlabOnTower();
                    return true;
                }
                return super.onTouchEvent(event);
            }

            float x = event.getX();
            float y = event.getY();
            float movingY = tracker.getMovingScanYNorm() * h;
            float baseY = tracker.getBaseScanYNorm() * h;
            float targetX = tracker.getManualTargetXNorm() * w;

            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (Math.abs(x - targetX) <= dpToPx(32)) {
                        activeDragLine = 3;
                    } else if (Math.abs(y - movingY) <= Math.abs(y - baseY)) {
                        activeDragLine = 1;
                    } else {
                        activeDragLine = 2;
                    }
                    updateDraggedAxis(x, y, w, h);
                    return true;

                case MotionEvent.ACTION_MOVE:
                    updateDraggedAxis(x, y, w, h);
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    activeDragLine = 0;
                    tracker.enforceAntiInversionRule();
                    saveCurrentSettings();
                    return true;

                default:
                    return false;
            }
        }

        private void updateDraggedAxis(float x, float y, int w, int h) {
            if (activeDragLine == 1) {
                tracker.setMovingScanYNorm(y / (float) h);
            } else if (activeDragLine == 2) {
                tracker.setBaseScanYNorm(y / (float) h);
            } else if (activeDragLine == 3) {
                tracker.setManualTargetXNorm(x / (float) w);
                tracker.setAutoBaseMode(false);
                updateSimControlButtons();
            }
            invalidate();
        }
    }
}
