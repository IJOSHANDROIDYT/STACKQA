package com.example;

import android.media.Image;
import android.os.SystemClock;
import java.nio.ByteBuffer;
import java.util.Arrays;

/**
 * Motor de Visión por Computadora en Tiempo Real (60 FPS) con:
 * 1. Rastreo Dinámico de la Cima de la Torre (towerTopY, baseCrownY, [baseMinX, baseMaxX], baseCenterX)
 *    adaptándose al crecimiento vertical de la torre (Y de 0.68 a 0.36) y a cambios de color de bloques/cielo.
 * 2. Detección del Bloque Móvil Diagonal por Diferencia Temporal de Fotogramas (|I_t - I_{t-2}|) y
 *    envolvente horizontal [movingMinX, movingMaxX] inmune a nubes blancas y confeti.
 */
public final class IsometricStackTracker {

    public static final float DEFAULT_MOVING_Y_NORM = 0.545f;
    public static final float DEFAULT_BASE_Y_NORM = 0.590f;
    public static final float DEFAULT_FIXED_AXIS_X_NORM = 0.500f;

    public static final float DEFAULT_MOVING_SCAN_Y_NORM = DEFAULT_MOVING_Y_NORM;
    public static final float DEFAULT_BASE_SCAN_Y_NORM = DEFAULT_BASE_Y_NORM;
    public static final float DEFAULT_TARGET_X_NORM = DEFAULT_FIXED_AXIS_X_NORM;

    public static final float MIN_VALID_SCAN_Y_NORM = 0.34f;
    public static final float MAX_VALID_SCAN_Y_NORM = 0.72f;
    public static final float MIN_SCANLINE_SEPARATION_NORM = 0.02f;

    // Caja activa vertical donde crece la torre y bajan las losas diagonales
    private static final float TOWER_SEARCH_TOP_Y_NORM = 0.34f;
    private static final float TOWER_SEARCH_BOTTOM_Y_NORM = 0.70f;
    private static final float SCAN_START_X_NORM = 0.08f;
    private static final float SCAN_END_X_NORM = 0.92f;
    private static final float SKY_LEFT_X_NORM = 0.06f;
    private static final float SKY_RIGHT_X_NORM = 0.94f;

    // Rejilla de sub-muestreo rápido en ByteBuffer para diferencia temporal |I_t - I_{t-2}|
    private static final int GRID_COLS = 96;
    private static final int GRID_ROWS = 64;
    private static final int GRID_CELLS = GRID_COLS * GRID_ROWS;

    // Umbral de diferencia cromática contra el fondo del cielo (|R-Rbg| + |G-Gbg| + |B-Bbg| > 38)
    private static final int DEFAULT_BG_DIFF_THRESHOLD = 38;
    // Umbral de diferencia temporal entre el fotograma actual t y t-2
    private static final int TEMPORAL_DIFF_THRESHOLD = 24;
    // Ancho mínimo continuo de losa (45px en pantalla de 1080p, escalado proporcionalmente)
    private static final int MIN_SLAB_WIDTH_PX_REF = 45;

    private int colorDiffThreshold = DEFAULT_BG_DIFF_THRESHOLD;

    private volatile float movingScanYNorm = DEFAULT_MOVING_Y_NORM;
    private volatile float baseScanYNorm = DEFAULT_BASE_Y_NORM;
    private volatile float manualTargetXNorm = DEFAULT_FIXED_AXIS_X_NORM;
    private volatile boolean autoBaseMode = true;
    private volatile boolean referenceLockActive = false;
    private volatile float lockedTargetCenterX = -1.0f;

    // Estado dinámico de la cima de la torre (se re-adquiere automáticamente tras cada bloque)
    private volatile float trackedBaseMinX = -1.0f;
    private volatile float trackedBaseMaxX = -1.0f;
    private volatile float trackedBaseCenterX = -1.0f;
    private volatile float trackedBaseWidth = -1.0f;
    private volatile int trackedBaseCrownY = -1;
    private volatile int trackedTowerTopY = -1;
    private volatile boolean needsBaseRecapture = true;
    private volatile long settleUntilUptimeMs = -10_000L;

    // Historial circular de 3 fotogramas en rejilla para |I_t - I_{t-2}| sin usar Bitmaps ni GC
    private final short[] gridRgbT0 = new short[GRID_CELLS * 3];
    private final short[] gridRgbT1 = new short[GRID_CELLS * 3];
    private final short[] gridRgbT2 = new short[GRID_CELLS * 3];
    private final short[] gridRgbSettled = new short[GRID_CELLS * 3];
    private final boolean[] rowIsMovingMask = new boolean[GRID_ROWS];
    private final float[] rowMinX = new float[GRID_ROWS];
    private final float[] rowMaxX = new float[GRID_ROWS];
    private final int[] rowMeanR = new int[GRID_ROWS];
    private final int[] rowMeanG = new int[GRID_ROWS];
    private final int[] rowMeanB = new int[GRID_ROWS];

    private int capturedGridFrames = 0;
    private boolean hasSettledReference = false;
    private int lastFrameWidth = 0;
    private int lastFrameHeight = 0;

    private final ScanResult reusableResult = new ScanResult();

    public static final class ScanResult {
        public boolean validFrame;
        public int frameWidth;
        public int frameHeight;
        public long timestampNs;
        public float processingTimeMs;

        // Geometría dinámica de la cima estacionaria de la torre
        public int towerTopY;
        public int baseScanY; // Coincide con baseCrownY
        public int baseCrownY;
        public boolean baseDetected;
        public float baseLeftX;  // baseMinX
        public float baseRightX; // baseMaxX
        public float baseMinX;
        public float baseMaxX;
        public float detectedBaseCenterX;
        public float baseCenterX;
        public float baseWidth;

        // Envolvente horizontal dinámica del bloque en movimiento diagonal
        public int movingScanY; // Coincide con movingCrownY
        public int movingCrownY;
        public boolean movingDetected;
        public float movingLeftX;  // movingMinX
        public float movingRightX; // movingMaxX
        public float movingMinX;
        public float movingMaxX;
        public float movingCenterX;
        public float movingWidth;

        public float leftEdgeDeltaPx;
        public float rightEdgeDeltaPx;
        public float edgeAlignmentCenterX;

        public float effectiveTargetCenterX;
        public boolean isReferenceLocked;
        public boolean tapToPlayButtonDetected;
        public float tapToPlayCenterX;
        public float tapToPlayCenterY;

        public void reset() {
            validFrame = false;
            baseDetected = false;
            movingDetected = false;
            tapToPlayButtonDetected = false;
            leftEdgeDeltaPx = 0.0f;
            rightEdgeDeltaPx = 0.0f;
            edgeAlignmentCenterX = 0.0f;
            processingTimeMs = 0.0f;
        }
    }

    public IsometricStackTracker() {
        resetAxesToFactoryDefaults();
    }

    public synchronized void resetAxesToFactoryDefaults() {
        this.movingScanYNorm = DEFAULT_MOVING_Y_NORM;
        this.baseScanYNorm = DEFAULT_BASE_Y_NORM;
        this.manualTargetXNorm = DEFAULT_FIXED_AXIS_X_NORM;
        this.autoBaseMode = true;
        this.referenceLockActive = false;
        this.lockedTargetCenterX = -1.0f;
        this.trackedBaseMinX = -1.0f;
        this.trackedBaseMaxX = -1.0f;
        this.trackedBaseCenterX = -1.0f;
        this.trackedBaseWidth = -1.0f;
        this.trackedBaseCrownY = -1;
        this.trackedTowerTopY = -1;
        this.needsBaseRecapture = true;
        this.capturedGridFrames = 0;
        this.hasSettledReference = false;
    }

    /**
     * Llamado inmediatamente después de ejecutar un disparo para que tras 260ms
     * re-calcule la nueva altura baseCrownY y los nuevos bordes [baseMinX, baseMaxX].
     */
    public void notifyShotFired(long settleDelayMs) {
        this.settleUntilUptimeMs = SystemClock.uptimeMillis() + Math.max(180L, settleDelayMs);
        this.needsBaseRecapture = true;
    }

    public static boolean areSavedAxesValid(float savedMovingY, float savedBaseY) {
        if (Float.isNaN(savedMovingY) || Float.isNaN(savedBaseY)) {
            return false;
        }
        if (savedMovingY < MIN_VALID_SCAN_Y_NORM || savedMovingY > MAX_VALID_SCAN_Y_NORM) {
            return false;
        }
        if (savedBaseY < MIN_VALID_SCAN_Y_NORM || savedBaseY > MAX_VALID_SCAN_Y_NORM) {
            return false;
        }
        return savedMovingY <= (savedBaseY - MIN_SCANLINE_SEPARATION_NORM);
    }

    public synchronized void enforceAntiInversionRule() {
        float mov = clamp(this.movingScanYNorm, MIN_VALID_SCAN_Y_NORM, MAX_VALID_SCAN_Y_NORM - 0.03f);
        float base = clamp(this.baseScanYNorm, MIN_VALID_SCAN_Y_NORM + 0.03f, MAX_VALID_SCAN_Y_NORM);
        if (mov >= base - MIN_SCANLINE_SEPARATION_NORM) {
            this.movingScanYNorm = Math.max(MIN_VALID_SCAN_Y_NORM, base - 0.045f);
            this.baseScanYNorm = base;
        } else {
            this.movingScanYNorm = mov;
            this.baseScanYNorm = base;
        }
    }

    public synchronized void setMovingScanYNorm(float normY) {
        float clampedY = clamp(normY, MIN_VALID_SCAN_Y_NORM, MAX_VALID_SCAN_Y_NORM - 0.03f);
        float maxAllowed = this.baseScanYNorm - MIN_SCANLINE_SEPARATION_NORM;
        this.movingScanYNorm = Math.min(clampedY, maxAllowed);
    }

    public float getMovingScanYNorm() {
        return movingScanYNorm;
    }

    public synchronized void setBaseScanYNorm(float normY) {
        float clampedY = clamp(normY, MIN_VALID_SCAN_Y_NORM + 0.03f, MAX_VALID_SCAN_Y_NORM);
        float minAllowed = this.movingScanYNorm + MIN_SCANLINE_SEPARATION_NORM;
        this.baseScanYNorm = Math.max(clampedY, minAllowed);
    }

    public float getBaseScanYNorm() {
        return baseScanYNorm;
    }

    public void setManualTargetXNorm(float normX) {
        this.manualTargetXNorm = clamp(normX, 0.20f, 0.80f);
        this.lockedTargetCenterX = -1.0f;
    }

    public float getManualTargetXNorm() {
        return manualTargetXNorm;
    }

    public void setAutoBaseMode(boolean autoBase) {
        this.autoBaseMode = autoBase;
    }

    public boolean isAutoBaseMode() {
        return autoBaseMode;
    }

    public void setColorDiffThreshold(int threshold) {
        this.colorDiffThreshold = Math.max(20, Math.min(110, threshold));
    }

    public int getColorDiffThreshold() {
        return colorDiffThreshold;
    }

    public void lockCurrentReference(float currentTargetX) {
        if (currentTargetX > 0.0f) {
            this.lockedTargetCenterX = currentTargetX;
            this.referenceLockActive = true;
        }
    }

    public void unlockReference() {
        this.referenceLockActive = false;
        this.lockedTargetCenterX = -1.0f;
        this.needsBaseRecapture = true;
    }

    public boolean isReferenceLockActive() {
        return referenceLockActive;
    }

    public ScanResult processImage(Image image) {
        if (image == null) {
            reusableResult.reset();
            return reusableResult;
        }
        Image.Plane[] planes = image.getPlanes();
        if (planes == null || planes.length == 0 || planes[0].getBuffer() == null) {
            reusableResult.reset();
            return reusableResult;
        }
        Image.Plane plane = planes[0];
        ByteBuffer buffer = plane.getBuffer();
        int width = image.getWidth();
        int height = image.getHeight();
        int rowStride = plane.getRowStride();
        int pixelStride = plane.getPixelStride();
        long timestampNs = image.getTimestamp();
        if (timestampNs <= 0L) {
            timestampNs = System.nanoTime();
        }
        return processByteBuffer(buffer, width, height, rowStride, pixelStride, timestampNs);
    }

    /**
     * Escaneo híbrido de ultra-baja latencia:
     * 1. Extrae la rejilla ROI (Y de 0.34 a 0.70) y compara con el cielo bilateral (x=0.06 y x=0.94)
     *    y con el historial temporal (|I_t - I_{t-2}|).
     * 2. Localiza automáticamente la cima estacionaria de la torre [baseMinX, baseMaxX] y baseCrownY.
     * 3. Localiza la envolvente horizontal del bloque diagonal en movimiento [movingMinX, movingMaxX].
     */
    public ScanResult processByteBuffer(
            ByteBuffer buffer,
            int width,
            int height,
            int rowStride,
            int pixelStride,
            long timestampNs) {

        long startNs = System.nanoTime();
        reusableResult.reset();

        if (buffer == null || width <= 64 || height <= 64 || pixelStride < 4) {
            return reusableResult;
        }

        if (width != lastFrameWidth || height != lastFrameHeight) {
            lastFrameWidth = width;
            lastFrameHeight = height;
            capturedGridFrames = 0;
            hasSettledReference = false;
            needsBaseRecapture = true;
        }

        int bufferLimit = buffer.limit();
        reusableResult.validFrame = true;
        reusableResult.frameWidth = width;
        reusableResult.frameHeight = height;
        reusableResult.timestampNs = timestampNs;

        // Rotar buffers temporales: T2 <- T1 <- T0
        if (capturedGridFrames >= 2) {
            System.arraycopy(gridRgbT1, 0, gridRgbT2, 0, gridRgbT0.length);
        }
        if (capturedGridFrames >= 1) {
            System.arraycopy(gridRgbT0, 0, gridRgbT1, 0, gridRgbT0.length);
        }

        int roiTopY = clampInt(Math.round(TOWER_SEARCH_TOP_Y_NORM * height), 8, height - 16);
        int roiBottomY = clampInt(Math.round(TOWER_SEARCH_BOTTOM_Y_NORM * height), roiTopY + 32, height - 8);
        int scanStartX = clampInt(Math.round(SCAN_START_X_NORM * width), 6, width - 12);
        int scanEndX = clampInt(Math.round(SCAN_END_X_NORM * width), scanStartX + 32, width - 6);
        int skyLeftX = clampInt(Math.round(SKY_LEFT_X_NORM * width), 2, scanStartX - 1);
        int skyRightX = clampInt(Math.round(SKY_RIGHT_X_NORM * width), scanEndX + 1, width - 3);

        float minSlabWidthPx = Math.max(28.0f, (MIN_SLAB_WIDTH_PX_REF / 1080.0f) * width);
        boolean hasTemporalHistory = (capturedGridFrames >= 2);

        Arrays.fill(rowIsMovingMask, false);
        Arrays.fill(rowMinX, -1.0f);
        Arrays.fill(rowMaxX, -1.0f);

        // Paso 1: Escaneo de las 64 filas de la caja activa de la torre
        for (int rIdx = 0; rIdx < GRID_ROWS; rIdx++) {
            float normRow = rIdx / (float) (GRID_ROWS - 1);
            int y = roiTopY + Math.round(normRow * (roiBottomY - roiTopY));
            int rowOffset = y * rowStride;
            if (rowOffset < 0 || rowOffset + (skyRightX * pixelStride) + 3 >= bufferLimit) {
                continue;
            }

            // Muestrear el color del cielo a la izquierda (x = 0.06f) y derecha (x = 0.94f) en esta misma altura Y
            int skyLIdx = rowOffset + (skyLeftX * pixelStride);
            int skyRIdx = rowOffset + (skyRightX * pixelStride);
            int bgLR = buffer.get(skyLIdx) & 0xFF;
            int bgLG = buffer.get(skyLIdx + 1) & 0xFF;
            int bgLB = buffer.get(skyLIdx + 2) & 0xFF;

            int bgRR = buffer.get(skyRIdx) & 0xFF;
            int bgRG = buffer.get(skyRIdx + 1) & 0xFF;
            int bgRB = buffer.get(skyRIdx + 2) & 0xFF;

            int bestSegStartCol = -1;
            int bestSegEndCol = -1;
            int curSegStartCol = -1;
            int movingCellsInBestSeg = 0;
            int curMovingCells = 0;
            int sumR = 0;
            int sumG = 0;
            int sumB = 0;
            int bestSumR = 0;
            int bestSumG = 0;
            int bestSumB = 0;

            for (int cIdx = 0; cIdx < GRID_COLS; cIdx++) {
                float normCol = cIdx / (float) (GRID_COLS - 1);
                int x = scanStartX + Math.round(normCol * (scanEndX - scanStartX));
                int pxIdx = rowOffset + (x * pixelStride);

                int r = buffer.get(pxIdx) & 0xFF;
                int g = buffer.get(pxIdx + 1) & 0xFF;
                int b = buffer.get(pxIdx + 2) & 0xFF;

                int cellBase = ((rIdx * GRID_COLS) + cIdx) * 3;
                gridRgbT0[cellBase] = (short) r;
                gridRgbT0[cellBase + 1] = (short) g;
                gridRgbT0[cellBase + 2] = (short) b;

                boolean isSlabPixel = isNonCloudBlockPixel(
                        r, g, b, bgLR, bgLG, bgLB, bgRR, bgRG, bgRB, colorDiffThreshold);

                boolean cellMoved = false;
                if (hasTemporalHistory) {
                    int prevR = gridRgbT2[cellBase];
                    int prevG = gridRgbT2[cellBase + 1];
                    int prevB = gridRgbT2[cellBase + 2];
                    int tempDiff = Math.abs(r - prevR) + Math.abs(g - prevG) + Math.abs(b - prevB);
                    if (tempDiff >= TEMPORAL_DIFF_THRESHOLD) {
                        cellMoved = true;
                    }
                }
                if (!cellMoved && hasSettledReference) {
                    int refR = gridRgbSettled[cellBase];
                    int refG = gridRgbSettled[cellBase + 1];
                    int refB = gridRgbSettled[cellBase + 2];
                    int refDiff = Math.abs(r - refR) + Math.abs(g - refG) + Math.abs(b - refB);
                    if (refDiff >= TEMPORAL_DIFF_THRESHOLD + 6) {
                        cellMoved = true;
                    }
                }

                if (isSlabPixel) {
                    if (curSegStartCol < 0) {
                        curSegStartCol = cIdx;
                        curMovingCells = 0;
                        sumR = 0;
                        sumG = 0;
                        sumB = 0;
                    }
                    if (cellMoved) {
                        curMovingCells++;
                    }
                    sumR += r;
                    sumG += g;
                    sumB += b;

                    int curLen = cIdx - curSegStartCol + 1;
                    int bestLen = (bestSegStartCol >= 0) ? (bestSegEndCol - bestSegStartCol + 1) : 0;
                    if (curLen > bestLen) {
                        bestSegStartCol = curSegStartCol;
                        bestSegEndCol = cIdx;
                        movingCellsInBestSeg = curMovingCells;
                        bestSumR = sumR;
                        bestSumG = sumG;
                        bestSumB = sumB;
                    }
                } else {
                    curSegStartCol = -1;
                }
            }

            if (bestSegStartCol >= 0) {
                float segMinX = scanStartX + ((bestSegStartCol / (float) (GRID_COLS - 1)) * (scanEndX - scanStartX));
                float segMaxX = scanStartX + ((bestSegEndCol / (float) (GRID_COLS - 1)) * (scanEndX - scanStartX));
                float segWidth = segMaxX - segMinX;

                // Ignorar nubes pequeñas, monedas y confeti exigiendo ancho continuo >= minSlabWidthPx
                if (segWidth >= minSlabWidthPx) {
                    int segCount = Math.max(1, bestSegEndCol - bestSegStartCol + 1);
                    rowMinX[rIdx] = segMinX;
                    rowMaxX[rIdx] = segMaxX;
                    rowMeanR[rIdx] = bestSumR / segCount;
                    rowMeanG[rIdx] = bestSumG / segCount;
                    rowMeanB[rIdx] = bestSumB / segCount;
                    // Una fila pertenece al bloque móvil si presenta diferencia temporal significativa
                    rowIsMovingMask[rIdx] = (movingCellsInBestSeg >= 2);
                }
            }
        }

        capturedGridFrames++;

        long nowUptime = SystemClock.uptimeMillis();
        boolean inSettleWindow = (nowUptime < settleUntilUptimeMs);

        // Paso 2: Localizar la Cima Estacionaria de la Torre (towerTopY, baseCrownY, [baseMinX, baseMaxX])
        int stationaryTopRow = -1;
        for (int rIdx = 0; rIdx < GRID_ROWS; rIdx++) {
            if (rowMinX[rIdx] > 0.0f && !rowIsMovingMask[rIdx]) {
                // Verificar continuidad vertical de al menos 2 filas estacionarias para descartar ruido
                if (rIdx + 1 < GRID_ROWS && rowMinX[rIdx + 1] > 0.0f && !rowIsMovingMask[rIdx + 1]) {
                    stationaryTopRow = rIdx;
                    break;
                }
            }
        }

        // Si es el primer fotograma (sin historial t-2 aún) o tras estabilización, buscamos desde abajo
        // el escalón estacionario superior de la torre
        if (stationaryTopRow >= 0 && (!inSettleWindow || trackedBaseCenterX < 0.0f)) {
            // Buscar dentro de las primeras 12 filas desde stationaryTopRow la fila con máxima anchura
            // de la cara superior iluminada (los vértices izquierdo y derecho del rombo base: baseCrownY)
            int crownRow = stationaryTopRow;
            float maxCrownSpan = rowMaxX[stationaryTopRow] - rowMinX[stationaryTopRow];
            int topR = rowMeanR[stationaryTopRow];
            int topG = rowMeanG[stationaryTopRow];
            int topB = rowMeanB[stationaryTopRow];

            int searchLimitRow = Math.min(GRID_ROWS - 1, stationaryTopRow + 11);
            for (int rIdx = stationaryTopRow + 1; rIdx <= searchLimitRow; rIdx++) {
                if (rowMinX[rIdx] <= 0.0f || rowIsMovingMask[rIdx]) {
                    continue;
                }
                // Que mantenga color uniforme con la cara superior de la cima
                int colorDelta = Math.abs(rowMeanR[rIdx] - topR)
                        + Math.abs(rowMeanG[rIdx] - topG)
                        + Math.abs(rowMeanB[rIdx] - topB);
                if (colorDelta > 75) {
                    break;
                }
                float span = rowMaxX[rIdx] - rowMinX[rIdx];
                if (span >= maxCrownSpan - 4.0f) {
                    maxCrownSpan = span;
                    crownRow = rIdx;
                }
            }

            int crownY = roiTopY + Math.round((crownRow / (float) (GRID_ROWS - 1)) * (roiBottomY - roiTopY));
            int topY = roiTopY + Math.round((stationaryTopRow / (float) (GRID_ROWS - 1)) * (roiBottomY - roiTopY));

            // Refinamiento a precisión de 1 píxel en la fila baseCrownY
            float[] refinedBase = refineExactRowEdges(
                    buffer, bufferLimit, rowStride, pixelStride,
                    crownY, scanStartX, scanEndX, skyLeftX, skyRightX);

            float exactBaseMinX = (refinedBase != null) ? refinedBase[0] : rowMinX[crownRow];
            float exactBaseMaxX = (refinedBase != null) ? refinedBase[1] : rowMaxX[crownRow];
            float exactBaseWidth = exactBaseMaxX - exactBaseMinX;
            float exactBaseCenter = (exactBaseMinX + exactBaseMaxX) * 0.5f;

            if (exactBaseWidth >= minSlabWidthPx) {
                if (needsBaseRecapture || trackedBaseCenterX < 0.0f) {
                    trackedBaseMinX = exactBaseMinX;
                    trackedBaseMaxX = exactBaseMaxX;
                    trackedBaseCenterX = exactBaseCenter;
                    trackedBaseWidth = exactBaseWidth;
                    trackedBaseCrownY = crownY;
                    trackedTowerTopY = topY;
                    baseScanYNorm = clamp(crownY / (float) height, MIN_VALID_SCAN_Y_NORM + 0.03f, MAX_VALID_SCAN_Y_NORM);
                    movingScanYNorm = clamp(baseScanYNorm - 0.045f, MIN_VALID_SCAN_Y_NORM, baseScanYNorm - 0.02f);

                    if (!inSettleWindow) {
                        System.arraycopy(gridRgbT0, 0, gridRgbSettled, 0, gridRgbT0.length);
                        hasSettledReference = true;
                        needsBaseRecapture = false;
                    }
                } else if (!referenceLockActive) {
                    // Seguimiento suave de la cima cuando no hay solapamiento del bloque móvil
                    trackedBaseMinX = (trackedBaseMinX * 0.70f) + (exactBaseMinX * 0.30f);
                    trackedBaseMaxX = (trackedBaseMaxX * 0.70f) + (exactBaseMaxX * 0.30f);
                    trackedBaseCenterX = (trackedBaseMinX + trackedBaseMaxX) * 0.5f;
                    trackedBaseWidth = trackedBaseMaxX - trackedBaseMinX;
                    trackedBaseCrownY = Math.round((trackedBaseCrownY * 0.70f) + (crownY * 0.30f));
                    trackedTowerTopY = Math.round((trackedTowerTopY * 0.70f) + (topY * 0.30f));
                    baseScanYNorm = clamp(trackedBaseCrownY / (float) height, MIN_VALID_SCAN_Y_NORM + 0.03f, MAX_VALID_SCAN_Y_NORM);
                    movingScanYNorm = clamp(baseScanYNorm - 0.045f, MIN_VALID_SCAN_Y_NORM, baseScanYNorm - 0.02f);
                }
            }
        }

        // Si el usuario o un test unitario proporcionó datos únicamente en las 2 líneas (baseScanYNorm / movingScanYNorm),
        // garantizamos compatibilidad total leyendo también esas dos filas directamente:
        int fallbackBaseY = clampInt(Math.round(baseScanYNorm * height), 8, height - 9);
        int fallbackMovingY = clampInt(Math.round(movingScanYNorm * height), 8, fallbackBaseY - 4);

        if (trackedBaseCenterX < 0.0f) {
            float[] directBase = refineExactRowEdges(
                    buffer, bufferLimit, rowStride, pixelStride,
                    fallbackBaseY, scanStartX, scanEndX, skyLeftX, skyRightX);
            if (directBase != null && (directBase[1] - directBase[0]) >= minSlabWidthPx) {
                trackedBaseMinX = directBase[0];
                trackedBaseMaxX = directBase[1];
                trackedBaseCenterX = (directBase[0] + directBase[1]) * 0.5f;
                trackedBaseWidth = directBase[1] - directBase[0];
                trackedBaseCrownY = fallbackBaseY;
                trackedTowerTopY = fallbackBaseY;
            }
        }

        if (trackedBaseCenterX > 0.0f) {
            reusableResult.baseDetected = true;
            reusableResult.towerTopY = (trackedTowerTopY > 0) ? trackedTowerTopY : fallbackBaseY;
            reusableResult.baseCrownY = (trackedBaseCrownY > 0) ? trackedBaseCrownY : fallbackBaseY;
            reusableResult.baseScanY = reusableResult.baseCrownY;
            reusableResult.baseMinX = trackedBaseMinX;
            reusableResult.baseMaxX = trackedBaseMaxX;
            reusableResult.baseLeftX = trackedBaseMinX;
            reusableResult.baseRightX = trackedBaseMaxX;
            reusableResult.baseWidth = trackedBaseWidth;
            reusableResult.baseCenterX = trackedBaseCenterX;
            reusableResult.detectedBaseCenterX = trackedBaseCenterX;
        } else {
            reusableResult.baseCrownY = fallbackBaseY;
            reusableResult.baseScanY = fallbackBaseY;
        }

        // Paso 3: Detectar la Envolvente Horizontal [movingMinX, movingMaxX] del Bloque en Movimiento Diagonal
        // Buscamos en la región desde (baseCrownY - 0.14f * height) hasta (baseCrownY + 0.02f * height)
        int refCrownY = reusableResult.baseCrownY;
        int movSearchTopY = Math.max(roiTopY, refCrownY - Math.round(0.14f * height));
        int movSearchBottomY = Math.min(roiBottomY, refCrownY + Math.round(0.02f * height));

        float envMovingMinX = Float.MAX_VALUE;
        float envMovingMaxX = -1.0f;
        int envMovingRowSum = 0;
        int envMovingRowCount = 0;

        for (int rIdx = 0; rIdx < GRID_ROWS; rIdx++) {
            float normRow = rIdx / (float) (GRID_ROWS - 1);
            int y = roiTopY + Math.round(normRow * (roiBottomY - roiTopY));
            if (y < movSearchTopY || y > movSearchBottomY) {
                continue;
            }
            if (rowMinX[rIdx] <= 0.0f) {
                continue;
            }

            // Es parte de la losa móvil si:
            // a) Fue marcada por diferencia temporal |I_t - I_{t-2}|, o
            // b) Está por encima de towerTopY, o
            // c) Su centro horizontal difiere del centro estacionario de la base (> 6px)
            float rowCenter = (rowMinX[rIdx] + rowMaxX[rIdx]) * 0.5f;
            boolean aboveStationaryTop = (trackedTowerTopY > 0 && y < trackedTowerTopY - 4);
            boolean horizontallyShifted = (trackedBaseCenterX > 0.0f && Math.abs(rowCenter - trackedBaseCenterX) > 5.0f);

            if (rowIsMovingMask[rIdx] || aboveStationaryTop || (y < refCrownY - 4 && horizontallyShifted)) {
                if (rowMinX[rIdx] < envMovingMinX) {
                    envMovingMinX = rowMinX[rIdx];
                }
                if (rowMaxX[rIdx] > envMovingMaxX) {
                    envMovingMaxX = rowMaxX[rIdx];
                }
                envMovingRowSum += y;
                envMovingRowCount++;
            }
        }

        if (envMovingRowCount > 0 && (envMovingMaxX - envMovingMinX) >= minSlabWidthPx) {
            int movCrownY = envMovingRowSum / envMovingRowCount;
            float[] refinedMov = refineExactRowEdges(
                    buffer, bufferLimit, rowStride, pixelStride,
                    movCrownY, scanStartX, scanEndX, skyLeftX, skyRightX);
            if (refinedMov != null && (refinedMov[1] - refinedMov[0]) >= minSlabWidthPx) {
                envMovingMinX = Math.min(envMovingMinX, refinedMov[0]);
                envMovingMaxX = Math.max(envMovingMaxX, refinedMov[1]);
            }

            // Si la losa móvil está solapando parcialmente la torre en Y, ajustamos el ancho a trackedBaseWidth
            // usando el borde exterior líder para que la proyección [movingMinX, movingMaxX] sea 100% exacta
            float rawSpan = envMovingMaxX - envMovingMinX;
            if (trackedBaseWidth > minSlabWidthPx && rawSpan > trackedBaseWidth * 1.12f) {
                float rawCenter = (envMovingMinX + envMovingMaxX) * 0.5f;
                if (rawCenter < trackedBaseCenterX) {
                    envMovingMaxX = envMovingMinX + trackedBaseWidth;
                } else {
                    envMovingMinX = envMovingMaxX - trackedBaseWidth;
                }
            }

            reusableResult.movingDetected = true;
            reusableResult.movingCrownY = movCrownY;
            reusableResult.movingScanY = movCrownY;
            reusableResult.movingMinX = envMovingMinX;
            reusableResult.movingMaxX = envMovingMaxX;
            reusableResult.movingLeftX = envMovingMinX;
            reusableResult.movingRightX = envMovingMaxX;
            reusableResult.movingWidth = envMovingMaxX - envMovingMinX;
            reusableResult.movingCenterX = (envMovingMinX + envMovingMaxX) * 0.5f;
        } else {
            // Fallback directo sobre fallbackMovingY (para tests sintéticos de 2 filas)
            float[] directMov = refineExactRowEdges(
                    buffer, bufferLimit, rowStride, pixelStride,
                    fallbackMovingY, scanStartX, scanEndX, skyLeftX, skyRightX);
            if (directMov != null && (directMov[1] - directMov[0]) >= minSlabWidthPx) {
                reusableResult.movingDetected = true;
                reusableResult.movingCrownY = fallbackMovingY;
                reusableResult.movingScanY = fallbackMovingY;
                reusableResult.movingMinX = directMov[0];
                reusableResult.movingMaxX = directMov[1];
                reusableResult.movingLeftX = directMov[0];
                reusableResult.movingRightX = directMov[1];
                reusableResult.movingWidth = directMov[1] - directMov[0];
                reusableResult.movingCenterX = (directMov[0] + directMov[1]) * 0.5f;
            } else {
                reusableResult.movingCrownY = fallbackMovingY;
                reusableResult.movingScanY = fallbackMovingY;
            }
        }

        // Paso 4: Resolver centro objetivo y deltas de bordes [movingMinX vs baseMinX] y [movingMaxX vs baseMaxX]
        float fallbackCenter = manualTargetXNorm * width;
        if (!autoBaseMode) {
            reusableResult.effectiveTargetCenterX = fallbackCenter;
            reusableResult.isReferenceLocked = true;
        } else if (referenceLockActive && lockedTargetCenterX > 0.0f) {
            reusableResult.effectiveTargetCenterX = lockedTargetCenterX;
            reusableResult.isReferenceLocked = true;
        } else if (reusableResult.baseDetected) {
            reusableResult.effectiveTargetCenterX = reusableResult.baseCenterX;
            reusableResult.isReferenceLocked = false;
        } else {
            reusableResult.effectiveTargetCenterX = fallbackCenter;
            reusableResult.isReferenceLocked = false;
        }

        if (reusableResult.movingDetected && reusableResult.baseDetected) {
            reusableResult.leftEdgeDeltaPx = reusableResult.movingMinX - reusableResult.baseMinX;
            reusableResult.rightEdgeDeltaPx = reusableResult.movingMaxX - reusableResult.baseMaxX;
            reusableResult.edgeAlignmentCenterX = reusableResult.baseCenterX;
        }

        // Paso 5: Detectar botón morado "Tap to play" en la zona inferior si no hay pieza móvil
        if (!reusableResult.movingDetected) {
            detectTapToPlayButton(buffer, bufferLimit, width, height, rowStride, pixelStride, reusableResult);
        }

        long elapsedNs = System.nanoTime() - startNs;
        reusableResult.processingTimeMs = elapsedNs / 1_000_000.0f;
        return reusableResult;
    }

    /**
     * Refina a resolución de 2px/1px los bordes izquierdo y derecho de una losa en una fila Y.
     */
    private float[] refineExactRowEdges(
            ByteBuffer buffer,
            int bufferLimit,
            int rowStride,
            int pixelStride,
            int y,
            int startX,
            int endX,
            int skyLeftX,
            int skyRightX) {

        int sampleY = Math.max(4, y - 3);
        int rowOffset = sampleY * rowStride;
        if (rowOffset < 0 || rowOffset + (skyRightX * pixelStride) + 3 >= bufferLimit) {
            return null;
        }

        int bgLIdx = rowOffset + (skyLeftX * pixelStride);
        int bgRIdx = rowOffset + (skyRightX * pixelStride);
        int bgLR = buffer.get(bgLIdx) & 0xFF;
        int bgLG = buffer.get(bgLIdx + 1) & 0xFF;
        int bgLB = buffer.get(bgLIdx + 2) & 0xFF;

        int bgRR = buffer.get(bgRIdx) & 0xFF;
        int bgRG = buffer.get(bgRIdx + 1) & 0xFF;
        int bgRB = buffer.get(bgRIdx + 2) & 0xFF;

        int foundLeft = -1;
        int runLeft = 0;
        for (int x = startX; x <= endX; x += 2) {
            int idx = rowOffset + (x * pixelStride);
            int r = buffer.get(idx) & 0xFF;
            int g = buffer.get(idx + 1) & 0xFF;
            int b = buffer.get(idx + 2) & 0xFF;
            if (isNonCloudBlockPixel(r, g, b, bgLR, bgLG, bgLB, bgRR, bgRG, bgRB, colorDiffThreshold)) {
                runLeft += 2;
                if (runLeft >= 8) {
                    foundLeft = x - runLeft + 2;
                    break;
                }
            } else {
                runLeft = 0;
            }
        }
        if (foundLeft < 0) {
            return null;
        }

        int foundRight = -1;
        int runRight = 0;
        for (int x = endX; x >= foundLeft; x -= 2) {
            int idx = rowOffset + (x * pixelStride);
            int r = buffer.get(idx) & 0xFF;
            int g = buffer.get(idx + 1) & 0xFF;
            int b = buffer.get(idx + 2) & 0xFF;
            if (isNonCloudBlockPixel(r, g, b, bgLR, bgLG, bgLB, bgRR, bgRG, bgRB, colorDiffThreshold)) {
                runRight += 2;
                if (runRight >= 8) {
                    foundRight = x + runRight - 2;
                    break;
                }
            } else {
                runRight = 0;
            }
        }
        if (foundRight <= foundLeft) {
            return null;
        }
        return new float[]{foundLeft, foundRight};
    }

    /**
     * Evalúa si un píxel pertenece a un bloque (de cualquier color: morado, fucsia, amarillo,
     * crema, verde) diferenciándolo del cielo lateral (Delta RGB > 38), de las nubes blancas
     * redondas y del suelo gris neutro.
     */
    private static boolean isNonCloudBlockPixel(
            int r, int g, int b,
            int bgLR, int bgLG, int bgLB,
            int bgRR, int bgRG, int bgRB,
            int threshold) {

        // 1. Ignorar colores neón puros dibujados por el propio overlay láser
        if (g > 215 && r < 35 && (b < 135 || b > 230)) {
            return false;
        }
        if (r > 235 && g > 215 && b < 45) {
            return false;
        }

        int max = Math.max(r, Math.max(g, b));
        int min = Math.min(r, Math.min(g, b));
        int chroma = max - min;

        // 2. Ignorar nubes blancas/grises y suelo gris neutro (baja saturación / croma < 22)
        if (chroma < 22) {
            return false;
        }

        // 3. Ignorar la cara lateral derecha oscura (donde max < 142 y r < 130) para medir solo la geometría superior
        if (max < 142 && r < 130) {
            return false;
        }

        // 4. Comparar diferencia cromática contra el fondo del cielo a izquierda y derecha
        int diffL = Math.abs(r - bgLR) + Math.abs(g - bgLG) + Math.abs(b - bgLB);
        int diffR = Math.abs(r - bgRR) + Math.abs(g - bgRG) + Math.abs(b - bgRB);
        int minDiff = Math.min(diffL, diffR);

        return minDiff >= threshold || chroma >= 38;
    }

    /**
     * Detecta si en la zona inferior central (Y ≈ 0.80f) está visible el botón morado "Tap to play".
     */
    private void detectTapToPlayButton(
            ByteBuffer buffer,
            int bufferLimit,
            int width,
            int height,
            int rowStride,
            int pixelStride,
            ScanResult outResult) {

        int btnY = Math.round(0.81f * height);
        int rowOffset = btnY * rowStride;
        int centerX = width / 2;
        if (rowOffset < 0 || rowOffset + ((centerX + 40) * pixelStride) + 3 >= bufferLimit) {
            return;
        }

        int purpleCount = 0;
        for (int dx = -40; dx <= 40; dx += 10) {
            int idx = rowOffset + ((centerX + dx) * pixelStride);
            int r = buffer.get(idx) & 0xFF;
            int g = buffer.get(idx + 1) & 0xFF;
            int b = buffer.get(idx + 2) & 0xFF;
            // Botón morado saturado característico de "Tap to play"
            if (b > 140 && r > 90 && g < 110 && (b - g) > 45) {
                purpleCount++;
            }
        }
        if (purpleCount >= 6) {
            outResult.tapToPlayButtonDetected = true;
            outResult.tapToPlayCenterX = centerX;
            outResult.tapToPlayCenterY = btnY;
        }
    }

    private static float clamp(float val, float min, float max) {
        return Math.max(min, Math.min(max, val));
    }

    private static int clampInt(int val, int min, int max) {
        return Math.max(min, Math.min(max, val));
    }
}
